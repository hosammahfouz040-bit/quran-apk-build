import { BrowserRouter, HashRouter, Route, Routes } from "react-router-dom";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import Menu from "@/pages/Menu";
import ComingSoon from "@/pages/ComingSoon";
import QuranHome from "@/pages/QuranHome";
import QuranReader from "@/pages/QuranReader";
import RecitersList from "@/pages/RecitersList";
import Azkar from "@/pages/Azkar";
import AzkarCategory from "@/pages/AzkarCategory";
import Tafsir from "@/pages/Tafsir";
import PrayerTimes from "@/pages/PrayerTimes";
import Tasbih from "@/pages/Tasbih";
import MuezzinPage from "@/pages/MuezzinPage";
import Memorization from "@/pages/Memorization";
import CompletionPlanPage from "@/pages/CompletionPlan";
import Qibla from "@/pages/Qibla";
import EnhancedReciterPlayer from "@/pages/EnhancedReciterPlayer";
import HijriCalendar from "@/pages/HijriCalendar";
import DownloadManager from "@/pages/DownloadManager";
import DownloadApp from "@/pages/DownloadApp";
import { sections } from "@/data/sections";

// نستخدم HashRouter عندما يُفتح التطبيق كملف واحد (file://) لأنه يعمل بدون خادم.
// وBrowserRouter للتطوير العادي. هذا يضمن عمل التنقل في البيئتين.
const Router =
  typeof window !== "undefined" && window.location.protocol === "file:"
    ? HashRouter
    : BrowserRouter;

export default function App() {
  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={
            <Layout variant="home">
              <Home />
            </Layout>
          }
        />
        <Route
          path="/menu"
          element={
            <Layout variant="inner">
              <Menu />
            </Layout>
          }
        />
        {/* قسم القرآن الكريم */}
        <Route
          path="/quran"
          element={
            <Layout variant="inner">
              <QuranHome />
            </Layout>
          }
        />
        <Route
          path="/quran/:number"
          element={
            <Layout variant="inner">
              <QuranReader />
            </Layout>
          }
        />
        {/* قسم القراء والتلاوات */}
        <Route
          path="/reciters"
          element={
            <Layout variant="inner">
              <RecitersList />
            </Layout>
          }
        />
        <Route
          path="/reciters/:reciterId"
          element={
            <Layout variant="inner">
              <EnhancedReciterPlayer />
            </Layout>
          }
        />
        {/* قسم الأذكار */}
        <Route
          path="/azkar"
          element={
            <Layout variant="inner">
              <Azkar />
            </Layout>
          }
        />
        <Route
          path="/azkar/:id"
          element={
            <Layout variant="inner">
              <AzkarCategory />
            </Layout>
          }
        />
        {/* قسم التفسير */}
        <Route
          path="/tafsir"
          element={
            <Layout variant="inner">
              <Tafsir />
            </Layout>
          }
        />
        {/* قسم مواقيت الصلاة */}
        <Route
          path="/prayer"
          element={
            <Layout variant="inner">
              <PrayerTimes />
            </Layout>
          }
        />
        {/* قسم المسبحة الإلكترونية */}
        <Route
          path="/tasbih"
          element={
            <Layout variant="inner">
              <Tasbih />
            </Layout>
          }
        />
        {/* قسم المؤذن والأذان */}
        <Route
          path="/adhan"
          element={
            <Layout variant="inner">
              <MuezzinPage />
            </Layout>
          }
        />
        {/* قسم الحفظ والمراجعة */}
        <Route
          path="/memorization"
          element={
            <Layout variant="inner">
              <Memorization />
            </Layout>
          }
        />
        {/* قسم خطة ختم القرآن */}
        <Route
          path="/completion"
          element={
            <Layout variant="inner">
              <CompletionPlanPage />
            </Layout>
          }
        />
        {/* قسم القبلة */}
        <Route
          path="/qibla"
          element={
            <Layout variant="inner">
              <Qibla />
            </Layout>
          }
        />
        {/* قسم التقويم الهجري */}
        <Route
          path="/calendar"
          element={
            <Layout variant="inner">
              <HijriCalendar />
            </Layout>
          }
        />
        {/* قسم إدارة التنزيلات */}
        <Route
          path="/downloads"
          element={
            <Layout variant="inner">
              <DownloadManager />
            </Layout>
          }
        />
        {/* صفحة تنزيل التطبيق */}
        <Route
          path="/download-app"
          element={
            <Layout variant="inner">
              <DownloadApp />
            </Layout>
          }
        />
        {/* بقية الأقسام (placeholder للمراحل القادمة) */}
        {sections
          .filter((s) => s.id !== "quran" && s.id !== "reciters" && s.id !== "azkar" && s.id !== "tafsir" && s.id !== "prayer" && s.id !== "tasbih")
          .map((section) => (
            <Route
              key={section.id}
              path={`${section.path}/*`}
              element={
                <Layout variant="inner">
                  <ComingSoon section={section} />
                </Layout>
              }
            />
          ))}
        <Route
          path="*"
          element={
            <Layout variant="inner">
              <NotFound />
            </Layout>
          }
        />
      </Routes>
    </Router>
  );
}

function NotFound() {
  return (
    <div className="px-4 pt-6 pb-4 text-center">
      <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-brand-50 text-brand-700">
        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10" />
          <path d="M12 8v4M12 16h.01" />
        </svg>
      </div>
      <h2 className="mt-4 text-xl font-extrabold text-brand-900">
        الصفحة غير موجودة
      </h2>
      <p className="mt-1 text-sm text-slate-500">
        تعذّر العثور على الصفحة المطلوبة
      </p>
      <a
        href="#/"
        className="tap-highlight mt-5 inline-flex items-center justify-center rounded-2xl bg-brand-900 px-5 py-2.5 text-sm font-bold text-gold-300 shadow-md"
      >
        العودة للرئيسية
      </a>
    </div>
  );
}
