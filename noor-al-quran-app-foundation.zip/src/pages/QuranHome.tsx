import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import type { QuranData, Surah } from "@/types/quran";
import { loadQuran, revelationInArabic } from "@/services/quranApi";
import { useSettings } from "@/hooks/useSettings";

/**
 * صفحة قائمة السور + البحث + استكمال القراءة.
 */
export default function QuranHome() {
  const [data, setData] = useState<QuranData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | "meccan" | "medinan">("all");
  const { settings } = useSettings();
  const navigate = useNavigate();

  useEffect(() => {
    let cancelled = false;
    loadQuran()
      .then((d) => {
        if (!cancelled) setData(d);
      })
      .catch((e: Error) => {
        if (!cancelled) setError(e.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const filteredSurahs = useMemo(() => {
    if (!data) return [];
    let list = data.surahs;
    if (filter === "meccan") list = list.filter((s) => s.revelationType === "Meccan");
    else if (filter === "medinan") list = list.filter((s) => s.revelationType === "Medinan");
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (s) =>
          s.simpleName?.toLowerCase().includes(q) ||
          s.englishName.toLowerCase().includes(q) ||
          String(s.number).includes(q)
      );
    }
    return list;
  }, [data, query, filter]);

  const lastReadSurah = useMemo(() => {
    if (!data || !settings.lastSurah) return null;
    return data.surahs.find((s) => s.number === settings.lastSurah) ?? null;
  }, [data, settings.lastSurah]);

  if (loading) {
    return <LoadingState />;
  }

  if (error || !data) {
    return <ErrorState message={error ?? "تعذّر تحميل البيانات"} onRetry={() => location.reload()} />;
  }

  return (
    <div className="px-4 pt-4 pb-4">
      {/* بطاقة استكمال القراءة */}
      {lastReadSurah && (
        <Link
          to={`/quran/${lastReadSurah.number}#ayah-${settings.lastAyah ?? 1}`}
          className="tap-highlight mb-4 block overflow-hidden rounded-2xl border border-gold-200 bg-gradient-to-l from-gold-50 to-white p-4 shadow-sm"
        >
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-gold-400 to-gold-600 text-brand-900 shadow-sm">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H19v17H6.5A2.5 2.5 0 0 0 4 21.5v-17Z" />
                <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H19v2.5A2.5 2.5 0 0 1 16.5 22H6.5A2.5 2.5 0 0 1 4 19.5Z" />
              </svg>
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[11px] font-bold text-gold-700">متابعة القراءة</p>
              <p className="mt-0.5 truncate text-sm font-extrabold text-brand-900">
                {lastReadSurah.simpleName}
              </p>
              <p className="text-[11px] text-slate-500">
                الآية {settings.lastAyah ?? 1}
              </p>
            </div>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 text-brand-600">
              <path d="M15 6l-6 6 6 6" />
            </svg>
          </div>
        </Link>
      )}

      {/* حقل البحث */}
      <div className="relative mb-3">
        <svg
          className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
          width="20"
          height="20"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="11" cy="11" r="8" />
          <path d="m21 21-4.3-4.3" />
        </svg>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="ابحث عن سورة بالاسم أو الرقم..."
          className="w-full rounded-2xl border border-brand-100 bg-white py-3 pr-11 pl-4 text-sm font-medium text-brand-900 shadow-sm outline-none placeholder:text-slate-400 focus:border-brand-400 focus:ring-2 focus:ring-brand-200"
        />
      </div>

      {/* فلاتر */}
      <div className="mb-3 flex gap-2">
        <FilterChip active={filter === "all"} onClick={() => setFilter("all")}>
          الكل ({data.surahs.length})
        </FilterChip>
        <FilterChip
          active={filter === "meccan"}
          onClick={() => setFilter("meccan")}
        >
          مكية ({data.surahs.filter((s) => s.revelationType === "Meccan").length})
        </FilterChip>
        <FilterChip
          active={filter === "medinan"}
          onClick={() => setFilter("medinan")}
        >
          مدنية ({data.surahs.filter((s) => s.revelationType === "Medinan").length})
        </FilterChip>
      </div>

      {/* معلومات صغيرة */}
      <p className="mb-2 text-[11px] text-slate-500">
        {filteredSurahs.length === 114
          ? "١١٤ سورة · ٦٢٣٦ آية"
          : `${filteredSurahs.length} سورة`}
      </p>

      {/* قائمة السور */}
      <ul className="space-y-2">
        {filteredSurahs.map((surah) => (
          <SurahRow
            key={surah.number}
            surah={surah}
            onOpen={() => navigate(`/quran/${surah.number}`)}
          />
        ))}
      </ul>

      {filteredSurahs.length === 0 && (
        <div className="mt-10 rounded-2xl border border-brand-100 bg-white p-6 text-center">
          <p className="text-sm font-bold text-brand-900">لا توجد نتائج</p>
          <p className="mt-1 text-xs text-slate-500">
            جرّب كلمة بحث مختلفة
          </p>
        </div>
      )}
    </div>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`tap-highlight rounded-full px-3.5 py-1.5 text-xs font-bold transition-colors ${
        active
          ? "bg-brand-900 text-gold-300 shadow-sm"
          : "bg-white text-brand-700 border border-brand-100"
      }`}
    >
      {children}
    </button>
  );
}

function SurahRow({ surah, onOpen }: { surah: Surah; onOpen: () => void }) {
  return (
    <li>
      <button
        onClick={onOpen}
        className="tap-highlight flex w-full items-center gap-3 rounded-2xl border border-brand-100 bg-white p-3 text-right shadow-sm hover:border-brand-300 hover:shadow-md"
      >
        {/* رقم السورة */}
        <div className="relative flex h-11 w-11 shrink-0 items-center justify-center">
          <svg width="44" height="44" viewBox="0 0 44 44" className="absolute inset-0 text-brand-800">
            <path
              d="M22 2 L27 17 L42 22 L27 27 L22 42 L17 27 L2 22 L17 17 Z"
              fill="currentColor"
              fillOpacity="0.08"
              stroke="currentColor"
              strokeWidth="1.2"
            />
          </svg>
          <span className="relative text-sm font-extrabold text-brand-800">
            {toArabicDigits(surah.number)}
          </span>
        </div>

        {/* المعلومات */}
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline gap-2">
            <h3 className="truncate text-base font-extrabold text-brand-900">
              {surah.simpleName}
            </h3>
            <span className="text-[10px] font-bold uppercase text-slate-400">
              {surah.englishName}
            </span>
          </div>
          <div className="mt-0.5 flex items-center gap-3 text-[11px] text-slate-500">
            <span>{revelationInArabic(surah.revelationType)}</span>
            <span className="h-1 w-1 rounded-full bg-slate-300" />
            <span>{toArabicDigits(surah.numberOfAyahs)} آية</span>
          </div>
        </div>

        {/* سهم */}
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 text-brand-400">
          <path d="M15 6l-6 6 6 6" />
        </svg>
      </button>
    </li>
  );
}

function LoadingState() {
  return (
    <div className="px-4 pt-6 pb-4">
      <div className="rounded-3xl border border-brand-100 bg-white p-6 text-center shadow-sm">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-brand-50">
          <svg
            className="animate-spin text-brand-700"
            width="32"
            height="32"
            viewBox="0 0 24 24"
            fill="none"
          >
            <circle cx="12" cy="12" r="10" stroke="currentColor" strokeOpacity="0.2" strokeWidth="3" />
            <path
              d="M22 12a10 10 0 0 0-10-10"
              stroke="currentColor"
              strokeWidth="3"
              strokeLinecap="round"
            />
          </svg>
        </div>
        <h2 className="text-base font-extrabold text-brand-900">
          تحميل القرآن الكريم
        </h2>
        <p className="mt-1 text-xs text-slate-500">
          يتم تحميل النص من مصدر موثوق وحفظه للاستخدام دون إنترنت...
        </p>
        <p className="mt-3 text-[11px] text-slate-400">
          المصدر: AlQuran.cloud · رسم عثماني
        </p>
      </div>
    </div>
  );
}

function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="px-4 pt-6 pb-4">
      <div className="rounded-3xl border border-red-200 bg-white p-6 text-center shadow-sm">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-red-50 text-red-600">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10" />
            <path d="M12 8v4M12 16h.01" />
          </svg>
        </div>
        <h2 className="text-base font-extrabold text-brand-900">
          تعذّر تحميل القرآن
        </h2>
        <p className="mt-2 text-xs leading-relaxed text-slate-600">
          {message}
        </p>
        <button
          onClick={onRetry}
          className="tap-highlight mt-5 inline-flex items-center justify-center rounded-2xl bg-brand-900 px-5 py-2.5 text-sm font-bold text-gold-300 shadow-md"
        >
          إعادة المحاولة
        </button>
        <p className="mt-3 text-[11px] text-slate-400">
          يتطلب الاتصال بالإنترنت للتحميل الأول فقط
        </p>
      </div>
    </div>
  );
}

/** تحويل الأرقام الإنجليزية إلى عربية (للعرض فقط) */
export function toArabicDigits(n: number | string): string {
  const map: Record<string, string> = {
    "0": "٠", "1": "١", "2": "٢", "3": "٣", "4": "٤",
    "5": "٥", "6": "٦", "7": "٧", "8": "٨", "9": "٩",
  };
  return String(n).replace(/[0-9]/g, (d) => map[d] ?? d);
}
