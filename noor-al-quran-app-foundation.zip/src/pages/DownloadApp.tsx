import { useState } from "react";

export default function DownloadApp() {
  const [showSteps, setShowSteps] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-6 max-w-2xl">
        {/* الرأس */}
        <div className="mb-6 text-center">
          <div className="inline-flex h-24 w-24 items-center justify-center rounded-3xl bg-gradient-to-br from-purple-600 to-purple-700 shadow-2xl mb-4">
            <svg
              width="48"
              height="48"
              viewBox="0 0 24 24"
              fill="none"
              stroke="white"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="7 10 12 15 17 10" />
              <line x1="12" y1="15" x2="12" y2="3" />
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-purple-700 dark:text-purple-400 mb-2">
            تنزيل تطبيق نور القرآن
          </h1>
          <p className="text-slate-600 dark:text-slate-300">
            احصل على ملف APK جاهز للتثبيت في 10 دقائق
          </p>
        </div>

        {/* البطاقة الرئيسية */}
        <div className="mb-6 p-6 bg-gradient-to-br from-purple-600 to-purple-700 text-white rounded-3xl shadow-2xl">
          <div className="flex items-center gap-4 mb-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-sm">
              <svg
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="12" cy="12" r="10" />
                <path d="M12 6v6l4 2" />
              </svg>
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold mb-1">طريقة سريعة وسهلة</h2>
              <p className="text-purple-200">بدون تثبيت برامج معقدة</p>
            </div>
          </div>

          <div className="p-4 bg-white/10 rounded-xl mb-4">
            <p className="text-sm mb-2">
              <strong>⏱️ الوقت المطلوب:</strong> 10 دقائق
            </p>
            <p className="text-sm mb-2">
              <strong>💰 التكلفة:</strong> مجاني 100%
            </p>
            <p className="text-sm">
              <strong>🛠️ البرامج المطلوبة:</strong> متصفح ويب فقط
            </p>
          </div>

          <button
            onClick={() => setShowSteps(!showSteps)}
            className="w-full p-4 bg-white/20 hover:bg-white/30 rounded-xl transition-colors text-right font-bold"
          >
            <div className="flex items-center justify-between">
              <span>📖 عرض الخطوات التفصيلية</span>
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className={`transition-transform ${showSteps ? "rotate-180" : ""}`}
              >
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </div>
          </button>
        </div>

        {/* الخطوات التفصيلية */}
        {showSteps && (
          <div className="mb-6 space-y-4">
            {/* الخطوة 1 */}
            <div className="p-5 bg-white dark:bg-slate-800 rounded-2xl shadow-lg border-2 border-purple-200 dark:border-purple-800">
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-purple-600 text-white font-bold shrink-0">
                  1
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-900 dark:text-white mb-2">
                    رفع التطبيق على Netlify
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                    Netlify خدمة مجانية لرفع مواقع الويب
                  </p>
                  <ol className="space-y-2 text-sm text-slate-700 dark:text-slate-300 list-decimal list-inside mb-3">
                    <li>اذهب إلى: <a href="https://app.netlify.com/drop" target="_blank" rel="noopener noreferrer" className="text-purple-600 dark:text-purple-400 font-bold underline">https://app.netlify.com/drop</a></li>
                    <li>اسحب مجلد <code className="bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded">dist</code> إلى المنطقة المخصصة</li>
                    <li>انتظر حتى ينتهي الرفع (30 ثانية)</li>
                    <li>انسخ الرابط الذي يظهر (مثل: https://your-app.netlify.app)</li>
                  </ol>
                  <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <p className="text-xs text-purple-700 dark:text-purple-400">
                      💡 <strong>نصيحة:</strong> احتفظ بالرابط، ستحتاجه في الخطوة التالية
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* الخطوة 2 */}
            <div className="p-5 bg-white dark:bg-slate-800 rounded-2xl shadow-lg border-2 border-purple-200 dark:border-purple-800">
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-purple-600 text-white font-bold shrink-0">
                  2
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-900 dark:text-white mb-2">
                    تحويل إلى APK باستخدام PWABuilder
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                    PWABuilder أداة مجانية من Microsoft
                  </p>
                  <ol className="space-y-2 text-sm text-slate-700 dark:text-slate-300 list-decimal list-inside mb-3">
                    <li>اذهب إلى: <a href="https://www.pwabuilder.com/" target="_blank" rel="noopener noreferrer" className="text-purple-600 dark:text-purple-400 font-bold underline">https://www.pwabuilder.com/</a></li>
                    <li>الصق رابط Netlify في المربع</li>
                    <li>اضغط على <strong>Start</strong></li>
                    <li>انتظر حتى ينتهي التحليل (1-2 دقيقة)</li>
                    <li>اضغط على <strong>Package for Stores</strong></li>
                    <li>اختر <strong>Android</strong></li>
                    <li>اضغط على <strong>Download Package</strong></li>
                    <li>انتظر حتى يتم إنشاء APK (2-3 دقائق)</li>
                    <li>اضغط على <strong>Download</strong> لتنزيل APK</li>
                  </ol>
                  <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <p className="text-xs text-green-700 dark:text-green-400">
                      ✅ <strong>تهانينا!</strong> ستحصل على ملف APK جاهز للتثبيت
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* الخطوة 3 */}
            <div className="p-5 bg-white dark:bg-slate-800 rounded-2xl shadow-lg border-2 border-purple-200 dark:border-purple-800">
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-purple-600 text-white font-bold shrink-0">
                  3
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-900 dark:text-white mb-2">
                    تثبيت APK على هاتفك
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                    ثبّت التطبيق مثل أي تطبيق آخر
                  </p>
                  <ol className="space-y-2 text-sm text-slate-700 dark:text-slate-300 list-decimal list-inside mb-3">
                    <li>انقل ملف APK إلى هاتفك (USB, Email, أو أي طريقة)</li>
                    <li>على هاتفك: الإعدادات → الأمان → مصادر غير معروفة (تفعيل)</li>
                    <li>افتح ملف APK واضغط على <strong>تثبيت</strong></li>
                    <li>انتظر حتى ينتهي التثبيت (30 ثانية)</li>
                    <li>اضغط على <strong>فتح</strong></li>
                  </ol>
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <p className="text-xs text-blue-700 dark:text-blue-400">
                      🎉 <strong>تم!</strong> التطبيق الآن على هاتفك
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* روابط سريعة */}
        <div className="mb-6 p-6 bg-white dark:bg-slate-800 rounded-2xl shadow-lg">
          <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-4">
            🔗 روابط سريعة
          </h2>
          <div className="space-y-3">
            <a
              href="https://app.netlify.com/drop"
              target="_blank"
              rel="noopener noreferrer"
              className="block p-4 bg-gradient-to-l from-teal-50 to-teal-100 dark:from-teal-900/20 dark:to-teal-900/30 rounded-xl border-2 border-teal-200 dark:border-teal-800 hover:border-teal-400 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-teal-600 text-white">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                    <polyline points="17 8 12 3 7 8" />
                    <line x1="12" y1="3" x2="12" y2="15" />
                  </svg>
                </div>
                <div className="flex-1">
                  <p className="font-bold text-teal-700 dark:text-teal-400">
                    Netlify Drop
                  </p>
                  <p className="text-xs text-teal-600 dark:text-teal-300">
                    ارفع التطبيق هنا (الخطوة 1)
                  </p>
                </div>
              </div>
            </a>

            <a
              href="https://www.pwabuilder.com/"
              target="_blank"
              rel="noopener noreferrer"
              className="block p-4 bg-gradient-to-l from-indigo-50 to-indigo-100 dark:from-indigo-900/20 dark:to-indigo-900/30 rounded-xl border-2 border-indigo-200 dark:border-indigo-800 hover:border-indigo-400 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-600 text-white">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
                    <line x1="8" y1="21" x2="16" y2="21" />
                    <line x1="12" y1="17" x2="12" y2="21" />
                  </svg>
                </div>
                <div className="flex-1">
                  <p className="font-bold text-indigo-700 dark:text-indigo-400">
                    PWABuilder
                  </p>
                  <p className="text-xs text-indigo-600 dark:text-indigo-300">
                    حول التطبيق إلى APK (الخطوة 2)
                  </p>
                </div>
              </div>
            </a>
          </div>
        </div>

        {/* معلومات مهمة */}
        <div className="mb-6 p-6 bg-amber-50 dark:bg-amber-900/20 rounded-2xl border-2 border-amber-200 dark:border-amber-800">
          <h3 className="font-bold text-amber-700 dark:text-amber-400 mb-3">
            ⚠️ معلومات مهمة
          </h3>
          <ul className="space-y-2 text-sm text-amber-700 dark:text-amber-300">
            <li>• هذه الطريقة <strong>مجانية 100%</strong> ولا تتطلب بطاقة ائتمان</li>
            <li>• PWABuilder أداة رسمية من <strong>Microsoft</strong></li>
            <li>• Netlify خدمة موثوقة ومستخدمة من ملايين المواقع</li>
            <li>• ملف APK الناتج <strong>آمن</strong> ويمكن تثبيته على أي جهاز Android</li>
            <li>• لا حاجة لتثبيت أي برامج على جهازك</li>
            <li>• العملية تستغرق <strong>10 دقائق</strong> فقط</li>
          </ul>
        </div>

        {/* الأسئلة الشائعة */}
        <div className="mb-6 p-6 bg-white dark:bg-slate-800 rounded-2xl shadow-lg">
          <h3 className="font-bold text-slate-900 dark:text-white mb-4">
            ❓ الأسئلة الشائعة
          </h3>
          <div className="space-y-3">
            <div>
              <p className="font-bold text-slate-900 dark:text-white text-sm">
                س: هل هذه الطريقة آمنة؟
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                ج: نعم، PWABuilder أداة رسمية من Microsoft وNetlify خدمة موثوقة
              </p>
            </div>
            <div>
              <p className="font-bold text-slate-900 dark:text-white text-sm">
                س: هل أحتاج لحساب؟
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                ج: لا، يمكنك استخدام Netlify Drop بدون حساب
              </p>
            </div>
            <div>
              <p className="font-bold text-slate-900 dark:text-white text-sm">
                س: هل APK الناتج يعمل على جميع الأجهزة؟
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                ج: نعم، يعمل على Android 5.0 (API 21) وأحدث
              </p>
            </div>
            <div>
              <p className="font-bold text-slate-900 dark:text-white text-sm">
                س: هل يمكنني نشر APK على Google Play؟
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                ج: نعم، يمكنك ذلك بعد التوقيع عليه
              </p>
            </div>
          </div>
        </div>

        {/* ملخص سريع */}
        <div className="p-6 bg-gradient-to-br from-green-600 to-green-700 text-white rounded-2xl shadow-xl">
          <h3 className="font-bold text-xl mb-4">🎯 ملخص سريع</h3>
          <div className="space-y-2 text-sm">
            <p>✅ <strong>الخطوة 1:</strong> ارفع مجلد <code className="bg-black/30 px-2 py-1 rounded">dist</code> على Netlify</p>
            <p>✅ <strong>الخطوة 2:</strong> استخدم PWABuilder لتحويل الرابط إلى APK</p>
            <p>✅ <strong>الخطوة 3:</strong> ثبّت APK على هاتفك</p>
          </div>
          <div className="mt-4 p-3 bg-white/20 rounded-xl">
            <p className="text-center font-bold">
              ⏱️ الوقت الإجمالي: 10 دقائق
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
