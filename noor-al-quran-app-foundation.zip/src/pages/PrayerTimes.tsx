import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  getPrayerTimesByCity,
  getPrayerTimesByCoordinates,
  getCurrentLocation,
  savePreferredLocation,
  getPreferredLocation,
  savePreferredMethod,
  getPreferredMethod,
  PRAYER_NAMES,
  CALCULATION_METHODS,
  POPULAR_CITIES,
  getNextPrayer,
  type PrayerTimesData,
  type LocationInfo,
} from "@/services/prayerTimesApi";

/**
 * صفحة مواقيت الصلاة - واجهة احترافية.
 * Features:
 * - بطاقة كبيرة للصلاة القادمة
 * - عداد تنازلي حقيقي يتحدث تلقائياً
 * - عرض الصلوات الخمس + الشروق
 * - اختيار المدينة وطريقة الحساب
 * - خيارات تنبيه مستقلة
 * - حالة الموقع وآخر تحديث
 */

interface NotificationSettings {
  [key: string]: {
    enabled: boolean;
    minutesBefore: number;
  };
}

function formatTime12(time24: string): string {
  const [hours, minutes] = time24.split(":").map((n) => parseInt(n, 10));
  const period = hours >= 12 ? "م" : "ص";
  const hours12 = hours % 12 || 12;
  return `${hours12}:${String(minutes).padStart(2, "0")} ${period}`;
}

function calculateCountdown(targetTime: string): string {
  const now = new Date();
  const [hours, minutes] = targetTime.split(":").map((n) => parseInt(n, 10));
  const target = new Date();
  target.setHours(hours, minutes, 0, 0);

  // إذا كانت الصلاة في اليوم التالي
  if (target <= now) {
    target.setDate(target.getDate() + 1);
  }

  const diff = target.getTime() - now.getTime();
  const h = Math.floor(diff / (1000 * 60 * 60));
  const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const s = Math.floor((diff % (1000 * 60)) / 1000);

  if (h > 0) {
    return `${h} ساعة ${m} دقيقة ${s} ثانية`;
  } else if (m > 0) {
    return `${m} دقيقة ${s} ثانية`;
  } else {
    return `${s} ثانية`;
  }
}

export default function PrayerTimes() {
  const navigate = useNavigate();
  const [prayerData, setPrayerData] = useState<PrayerTimesData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentLocation, setCurrentLocation] = useState<LocationInfo | null>(null);
  const [selectedMethod, setSelectedMethod] = useState(5);
  const [showCityPicker, setShowCityPicker] = useState(false);
  const [showMethodPicker, setShowMethodPicker] = useState(false);
  const [showNotificationSettings, setShowNotificationSettings] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [countdown, setCountdown] = useState("");
  const [currentTime, setCurrentTime] = useState(new Date());
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [locationStatus, setLocationStatus] = useState<"unknown" | "granted" | "denied" | "prompt">("unknown");
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>({
    Fajr: { enabled: false, minutesBefore: 10 },
    Dhuhr: { enabled: false, minutesBefore: 10 },
    Asr: { enabled: false, minutesBefore: 10 },
    Maghrib: { enabled: false, minutesBefore: 10 },
    Isha: { enabled: false, minutesBefore: 10 },
  });

  const countdownRef = useRef<number | null>(null);

  // تحميل الموقع المحفوظ أو القاهرة افتراضياً
  useEffect(() => {
    const savedLocation = getPreferredLocation();
    const savedMethod = getPreferredMethod();
    setSelectedMethod(savedMethod);

    // تحميل إعدادات التنبيهات
    try {
      const savedNotifications = localStorage.getItem("prayer-notifications");
      if (savedNotifications) {
        setNotificationSettings(JSON.parse(savedNotifications));
      }
    } catch (e) {
      console.warn("فشل تحميل إعدادات التنبيهات:", e);
    }

    if (savedLocation) {
      setCurrentLocation(savedLocation);
      setLocationStatus("granted");
    } else {
      const cairo = POPULAR_CITIES.find((c) => c.city === "القاهرة")!;
      setCurrentLocation(cairo);
    }
  }, []);

  // جلب المواقيت عند تغير الموقع أو الطريقة
  useEffect(() => {
    if (currentLocation) {
      loadPrayerTimes();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentLocation, selectedMethod]);

  // تحديث الوقت والعد التنازلي كل ثانية
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
      if (prayerData) {
        const next = getNextPrayer(prayerData.timings);
        if (next) {
          setCountdown(calculateCountdown(next.time));
        }
      }
    }, 1000);
    
    countdownRef.current = interval as any;
    return () => {
      if (countdownRef.current) {
        clearInterval(countdownRef.current);
      }
    };
  }, [prayerData]);

  const loadPrayerTimes = async () => {
    if (!currentLocation) return;
    try {
      setLoading(true);
      setError(null);
      const data = await getPrayerTimesByCity(
        currentLocation.city,
        currentLocation.country,
        selectedMethod
      );
      setPrayerData(data);
      setLastUpdate(new Date());
    } catch (e: any) {
      if (e.message.includes("Failed to fetch") || e.message.includes("NetworkError")) {
        setError("لا يوجد اتصال بالإنترنت. يرجى التحقق من الاتصال والمحاولة مرة أخرى.");
      } else {
        setError(e.message || "فشل في تحميل المواقيت");
      }
    } finally {
      setLoading(false);
    }
  };

  const detectMyLocation = async () => {
    try {
      setLoading(true);
      setError(null);
      setLocationStatus("prompt");
      
      const position = await getCurrentLocation();
      setLocationStatus("granted");
      
      const data = await getPrayerTimesByCoordinates(
        position.coords.latitude,
        position.coords.longitude,
        selectedMethod
      );

      const location: LocationInfo = {
        city: "موقعي الحالي",
        country: "",
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      };
      setCurrentLocation(location);
      savePreferredLocation(location);
      setPrayerData(data);
      setLastUpdate(new Date());
      setShowCityPicker(false);
    } catch (e: any) {
      setLocationStatus("denied");
      if (e.code === 1) {
        setError("تم رفض إذن الموقع. يرجى السماح بالوصول من إعدادات المتصفح أو اختيار مدينة يدوياً.");
      } else if (e.code === 2) {
        setError("تعذر الحصول على الموقع. يرجى المحاولة مرة أخرى أو اختيار مدينة يدوياً.");
      } else if (e.code === 3) {
        setError("انتهت مهلة الحصول على الموقع. يرجى المحاولة مرة أخرى.");
      } else {
        setError(e.message || "فشل في الحصول على الموقع");
      }
    } finally {
      setLoading(false);
    }
  };

  const selectCity = (city: LocationInfo) => {
    setCurrentLocation(city);
    savePreferredLocation(city);
    setLocationStatus("granted");
    setShowCityPicker(false);
    setSearchQuery("");
  };

  const changeMethod = (method: number) => {
    setSelectedMethod(method);
    savePreferredMethod(method);
    setShowMethodPicker(false);
  };

  const toggleNotification = (prayer: string) => {
    const newSettings = {
      ...notificationSettings,
      [prayer]: {
        ...notificationSettings[prayer],
        enabled: !notificationSettings[prayer].enabled,
      },
    };
    setNotificationSettings(newSettings);
    localStorage.setItem("prayer-notifications", JSON.stringify(newSettings));

    // طلب إذن الإشعارات إذا تم تفعيل أول إشعار
    if (!notificationSettings[prayer].enabled && "Notification" in window) {
      Notification.requestPermission();
    }
  };

  const updateNotificationMinutes = (prayer: string, minutes: number) => {
    const newSettings = {
      ...notificationSettings,
      [prayer]: {
        ...notificationSettings[prayer],
        minutesBefore: minutes,
      },
    };
    setNotificationSettings(newSettings);
    localStorage.setItem("prayer-notifications", JSON.stringify(newSettings));
  };

  const filteredCities = POPULAR_CITIES.filter(
    (city) =>
      city.city.includes(searchQuery) ||
      city.country.includes(searchQuery)
  );

  const nextPrayer = prayerData ? getNextPrayer(prayerData.timings) : null;
  const mainPrayers = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"] as const;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
      <div className="container mx-auto px-4 py-6 max-w-2xl">
        {/* الرأس */}
        <div className="mb-6 flex items-start justify-between gap-4">
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-white mb-2">مواقيت الصلاة</h1>
            <p className="text-blue-100">أوقات الصلوات بدقة عالية</p>
          </div>
          <button
            onClick={() => navigate("/adhan")}
            className="flex flex-col items-center gap-1 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl transition-colors"
            title="إعدادات المؤذن"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
              <path d="M12 2a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
              <path d="M19 10v1a7 7 0 0 1-14 0v-1M12 18v4M8 22h8" />
            </svg>
            <span className="text-xs text-white font-medium">المؤذن</span>
          </button>
        </div>

        {/* بطاقة الموقع والوقت */}
        {currentLocation && (
          <div className="mb-6 p-5 bg-gradient-to-br from-blue-600 to-blue-700 text-white rounded-2xl shadow-2xl">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                    <circle cx="12" cy="10" r="3" />
                  </svg>
                  <p className="text-sm opacity-90">الموقع</p>
                </div>
                <p className="text-xl font-bold">
                  {currentLocation.city}
                  {currentLocation.country && `، ${currentLocation.country}`}
                </p>
              </div>
              <div className="flex gap-2 flex-wrap">
                <button
                  onClick={() => setShowCityPicker(true)}
                  className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-medium transition-colors"
                >
                  تغيير
                </button>
                <button
                  onClick={detectMyLocation}
                  className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10" />
                    <line x1="12" y1="8" x2="12" y2="16" />
                    <line x1="8" y1="12" x2="16" y2="12" />
                  </svg>
                  موقعي
                </button>
              </div>
            </div>

            {/* حالة الموقع */}
            {locationStatus === "denied" && (
              <div className="mb-3 p-2 bg-red-500/20 border border-red-500/30 rounded-lg text-xs text-red-200">
                ⚠️ إذن الموقع مرفوض - استخدم اختيار المدينة يدوياً
              </div>
            )}

            <div className="flex items-center justify-between pt-4 border-t border-white/20 flex-wrap gap-3">
              <div>
                <p className="text-sm opacity-90">الوقت الحالي</p>
                <p className="text-2xl font-bold" dir="ltr">
                  {formatTime12(`${currentTime.getHours()}:${String(currentTime.getMinutes()).padStart(2, "0")}`)}
                </p>
              </div>
              {prayerData && (
                <div className="text-right">
                  <p className="text-sm opacity-90">التاريخ الهجري</p>
                  <p className="text-lg font-bold">
                    {prayerData.date.hijri.day} {prayerData.date.hijri.month.ar} {prayerData.date.hijri.year}
                  </p>
                </div>
              )}
            </div>

            {/* آخر تحديث */}
            {lastUpdate && (
              <div className="mt-3 pt-3 border-t border-white/20 text-xs opacity-75">
                آخر تحديث: {lastUpdate.toLocaleTimeString("ar-EG")}
              </div>
            )}
          </div>
        )}

        {/* الصلاة التالية */}
        {nextPrayer && countdown && (
          <div className="mb-6 p-6 bg-gradient-to-br from-emerald-500 to-emerald-600 text-white rounded-2xl shadow-2xl">
            <div className="text-center mb-4">
              <p className="text-sm opacity-90 mb-1">الصلاة التالية</p>
              <h2 className="text-4xl font-bold mb-2">{nextPrayer.nameAr}</h2>
              <p className="text-2xl font-bold opacity-90" dir="ltr">
                {formatTime12(nextPrayer.time)}
              </p>
            </div>
            
            <div className="text-center p-4 bg-white/20 rounded-xl backdrop-blur-sm">
              <p className="text-sm opacity-90 mb-1">الوقت المتبقي</p>
              <p className="text-3xl font-bold">{countdown}</p>
            </div>
          </div>
        )}

        {/* حالة التحميل */}
        {loading && (
          <div className="text-center py-12">
            <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-white border-t-transparent" />
            <p className="mt-4 text-white">جاري تحميل المواقيت...</p>
          </div>
        )}

        {/* حالة الخطأ */}
        {error && !loading && (
          <div className="mb-6 p-5 bg-red-500/20 border-2 border-red-500/30 rounded-2xl text-center">
            <p className="text-red-200 mb-4">{error}</p>
            <div className="flex gap-2 justify-center">
              <button
                onClick={loadPrayerTimes}
                className="px-6 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
              >
                إعادة المحاولة
              </button>
              <button
                onClick={() => setShowCityPicker(true)}
                className="px-6 py-2 bg-white/20 text-white rounded-lg hover:bg-white/30 transition-colors"
              >
                اختيار مدينة
              </button>
            </div>
          </div>
        )}

        {/* المواقيت */}
        {prayerData && !loading && !error && (
          <>
            {/* الصلوات الخمس */}
            <div className="mb-6 space-y-3">
              {mainPrayers.map((prayer) => {
                const time = prayerData.timings[prayer];
                const isNext = nextPrayer?.name === prayer;
                
                return (
                  <div
                    key={prayer}
                    className={`
                      p-5 rounded-xl border-2 transition-all
                      ${
                        isNext
                          ? "bg-emerald-500/20 border-emerald-400 shadow-lg scale-[1.02]"
                          : "bg-white/10 border-white/20 hover:border-blue-400/50"
                      }
                    `}
                  >
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-center gap-4">
                        <PrayerIcon prayer={prayer} isHighlighted={isNext} />
                        <div>
                          <h3 className={`text-xl font-bold ${isNext ? "text-emerald-300" : "text-white"}`}>
                            {PRAYER_NAMES[prayer]}
                          </h3>
                          {isNext && (
                            <p className="text-xs text-emerald-300 font-bold mt-1">
                              ← الصلاة التالية
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p
                          className={`text-2xl font-bold ${
                            isNext ? "text-emerald-300" : "text-white"
                          }`}
                          dir="ltr"
                        >
                          {formatTime12(time)}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* الشروق (منفصل) */}
            <div className="mb-6 p-4 bg-white/5 border border-white/10 rounded-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="text-orange-300">
                    <path d="M12 2v8M4.93 10.93l2.83 2.83M2 18h4M18 18h4M19.07 13.76l2.83-2.83" />
                    <path d="M2 18h20M12 18v-4" />
                  </svg>
                  <div>
                    <p className="text-orange-300 font-bold">الشروق</p>
                    <p className="text-xs text-white/70">وقت الشروق (ليس صلاة)</p>
                  </div>
                </div>
                <p className="text-xl font-bold text-orange-300" dir="ltr">
                  {formatTime12(prayerData.timings.Sunrise)}
                </p>
              </div>
            </div>

            {/* أزرار الإعدادات */}
            <div className="mb-6 grid grid-cols-2 gap-3">
              <button
                onClick={() => setShowMethodPicker(true)}
                className="p-4 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl text-white transition-colors"
              >
                <p className="text-sm opacity-90 mb-1">طريقة الحساب</p>
                <p className="font-bold text-sm truncate">
                  {CALCULATION_METHODS.find((m) => m.id === selectedMethod)?.name}
                </p>
              </button>
              
              <button
                onClick={() => setShowNotificationSettings(!showNotificationSettings)}
                className="p-4 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl text-white transition-colors"
              >
                <p className="text-sm opacity-90 mb-1">التنبيهات</p>
                <p className="font-bold text-sm">
                  {Object.values(notificationSettings).filter(n => n.enabled).length} مفعّل
                </p>
              </button>
            </div>

            {/* إعدادات التنبيهات */}
            {showNotificationSettings && (
              <div className="mb-6 p-5 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20">
                <h3 className="text-lg font-bold text-white mb-4">إعدادات التنبيهات</h3>
                
                {!("Notification" in window) && (
                  <div className="mb-4 p-3 bg-yellow-500/20 border border-yellow-500/30 rounded-lg text-yellow-200 text-sm">
                    ⚠️ التنبيهات غير مدعومة في هذا المتصفح
                  </div>
                )}

                {"Notification" in window && Notification.permission === "denied" && (
                  <div className="mb-4 p-3 bg-red-500/20 border border-red-500/30 rounded-lg text-red-200 text-sm">
                    ⚠️ تم رفض إذن الإشعارات. يرجى تفعيلها من إعدادات المتصفح.
                  </div>
                )}

                <div className="space-y-3">
                  {mainPrayers.map((prayer) => {
                    const notification = notificationSettings[prayer];
                    return (
                      <div key={prayer} className="p-3 bg-white/5 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-white font-medium">{PRAYER_NAMES[prayer]}</span>
                          <label className="flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={notification.enabled}
                              onChange={() => toggleNotification(prayer)}
                              className="w-5 h-5 accent-emerald-500"
                            />
                          </label>
                        </div>
                        {notification.enabled && (
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-white/70">قبل</span>
                            <input
                              type="number"
                              value={notification.minutesBefore}
                              onChange={(e) => updateNotificationMinutes(prayer, parseInt(e.target.value) || 0)}
                              className="w-20 px-2 py-1 bg-white/10 border border-white/20 rounded text-white text-sm"
                              min="1"
                              max="60"
                            />
                            <span className="text-xs text-white/70">دقيقة</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}

        {/* معلومات المصدر */}
        <div className="p-4 bg-white/5 backdrop-blur-sm rounded-xl text-sm text-white/70">
          <p className="font-semibold mb-2 text-white">المصدر:</p>
          <p>AlAdhan API - مواقيت دقيقة لجميع أنحاء العالم</p>
          <p className="mt-2 text-xs">
            قد تختلف المواقيت قليلاً عن التوقيت المحلي. يُفضل التأكد من مسجد الحي.
          </p>
        </div>

        {/* نافذة اختيار المدينة */}
        {showCityPicker && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
            onClick={() => setShowCityPicker(false)}
          >
            <div
              className="bg-blue-900 border-2 border-white/20 rounded-2xl max-w-md w-full max-h-[80vh] overflow-hidden shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-5 border-b border-white/20">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold text-white">اختر المدينة</h2>
                  <button
                    onClick={() => setShowCityPicker(false)}
                    className="p-2 hover:bg-white/10 rounded-lg transition-colors text-white"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M18 6 6 18" />
                      <path d="m6 6 12 12" />
                    </svg>
                  </button>
                </div>
                <input
                  type="text"
                  placeholder="ابحث عن مدينة..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
                  autoFocus
                />
              </div>
              <div className="p-3 overflow-y-auto max-h-[60vh]">
                <div className="space-y-2">
                  {filteredCities.map((city) => (
                    <button
                      key={`${city.city}-${city.country}`}
                      onClick={() => selectCity(city)}
                      className="w-full p-4 text-right bg-white/5 border border-white/10 rounded-lg hover:border-blue-400 hover:bg-white/10 transition-all"
                    >
                      <p className="font-bold text-white">{city.city}</p>
                      <p className="text-sm text-white/70">{city.country}</p>
                    </button>
                  ))}
                  {filteredCities.length === 0 && (
                    <p className="text-center py-12 text-white/50">
                      لا توجد نتائج
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* نافذة اختيار طريقة الحساب */}
        {showMethodPicker && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
            onClick={() => setShowMethodPicker(false)}
          >
            <div
              className="bg-blue-900 border-2 border-white/20 rounded-2xl max-w-md w-full max-h-[80vh] overflow-hidden shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-5 border-b border-white/20">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-white">طريقة الحساب</h2>
                  <button
                    onClick={() => setShowMethodPicker(false)}
                    className="p-2 hover:bg-white/10 rounded-lg transition-colors text-white"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M18 6 6 18" />
                      <path d="m6 6 12 12" />
                    </svg>
                  </button>
                </div>
              </div>
              <div className="p-3 overflow-y-auto max-h-[60vh]">
                <div className="space-y-2">
                  {CALCULATION_METHODS.map((method) => (
                    <button
                      key={method.id}
                      onClick={() => changeMethod(method.id)}
                      className={`
                        w-full p-4 text-right rounded-lg transition-all border-2
                        ${
                          selectedMethod === method.id
                            ? "bg-blue-500/20 border-blue-400"
                            : "bg-white/5 border-white/10 hover:border-blue-400/50"
                        }
                      `}
                    >
                      <p className="font-bold text-white">{method.name}</p>
                      <p className="text-sm text-white/70">{method.region}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function PrayerIcon({
  prayer,
  isHighlighted,
}: {
  prayer: string;
  isHighlighted: boolean;
}) {
  const iconProps = {
    width: 40,
    height: 40,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    className: isHighlighted ? "text-emerald-300" : "text-white/70",
  };

  switch (prayer) {
    case "Fajr":
      return (
        <svg {...iconProps}>
          <path d="M12 2v4M4.93 4.93l2.83 2.83M2 12h4M4.93 19.07l2.83-2.83" />
          <circle cx="12" cy="12" r="4" />
          <path d="M12 22v-4" />
        </svg>
      );
    case "Sunrise":
      return (
        <svg {...iconProps}>
          <path d="M12 2v8M4.93 10.93l2.83 2.83M2 18h4M18 18h4M19.07 13.76l2.83-2.83" />
          <path d="M2 18h20M12 18v-4" />
        </svg>
      );
    case "Dhuhr":
      return (
        <svg {...iconProps}>
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41" />
        </svg>
      );
    case "Asr":
      return (
        <svg {...iconProps}>
          <circle cx="12" cy="12" r="5" />
          <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" />
        </svg>
      );
    case "Maghrib":
      return (
        <svg {...iconProps}>
          <path d="M12 10V2M4.93 10.93l2.83-2.83M2 18h2M20 18h2M16.24 7.76l2.83-2.83" />
          <path d="M2 18h20" />
          <path d="M12 18v-4" />
        </svg>
      );
    case "Isha":
      return (
        <svg {...iconProps}>
          <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9z" />
        </svg>
      );
    default:
      return (
        <svg {...iconProps}>
          <circle cx="12" cy="12" r="4" />
        </svg>
      );
  }
}
