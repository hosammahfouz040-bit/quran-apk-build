import { useEffect, useState, useRef } from "react";

/**
 * صفحة المسبحة الإلكترونية - تصميم إسلامي فخم.
 * Features:
 * - عداد دائري كبير
 * - قائمة أذكار شاملة
 * - أهداف متعددة (33, 100, 1000, مخصص)
 * - التراجع عن آخر ضغطة
 * - حفظ واستعادة تلقائي
 * - شريط تقدم وسجل يومي
 * - اهتزاز وصوت اختياريين
 */

interface TasbihItem {
  id: string;
  text: string;
  translation: string;
  defaultTarget: number;
  category: string;
}

interface TasbihState {
  counts: Record<string, number>;
  selectedTasbihId: string;
  customTargets: Record<string, number>;
  dailyStats: DailyStat[];
  settings: {
    vibration: boolean;
    sound: boolean;
  };
}

interface DailyStat {
  date: string;
  totalCount: number;
  completedTasks: number;
}

const DEFAULT_TASBIHS: TasbihItem[] = [
  // التسبيح
  { id: "subhanallah", text: "سُبْحَانَ اللَّهِ", translation: "Glory be to Allah", defaultTarget: 33, category: "تسبيح" },
  { id: "subhanallah_wa_bihamdihi", text: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", translation: "Glory and praise be to Allah", defaultTarget: 100, category: "تسبيح" },
  { id: "subhanallah_alazeem", text: "سُبْحَانَ اللَّهِ الْعَظِيمِ", translation: "Glory be to Allah the Almighty", defaultTarget: 100, category: "تسبيح" },
  
  // التحميد
  { id: "alhamdulillah", text: "الْحَمْدُ لِلَّهِ", translation: "All praise is due to Allah", defaultTarget: 33, category: "تحميد" },
  { id: "alhamdulillahi_rabbil_alamin", text: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", translation: "Praise be to Allah, Lord of the worlds", defaultTarget: 100, category: "تحميد" },
  
  // التكبير
  { id: "allahuakbar", text: "اللَّهُ أَكْبَرُ", translation: "Allah is the Greatest", defaultTarget: 34, category: "تكبير" },
  
  // التهليل
  { id: "lailaha", text: "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ", translation: "There is no god but Allah alone, no partner has He", defaultTarget: 100, category: "تهليل" },
  { id: "lailaha_short", text: "لَا إِلَهَ إِلَّا اللَّهُ", translation: "There is no god but Allah", defaultTarget: 100, category: "تهليل" },
  
  // الاستغفار
  { id: "astaghfirullah", text: "أَسْتَغْفِرُ اللَّهَ", translation: "I seek forgiveness from Allah", defaultTarget: 100, category: "استغفار" },
  { id: "astaghfirullah_wa_atubu", text: "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ", translation: "I seek forgiveness and repent to Allah", defaultTarget: 100, category: "استغفار" },
  
  // الصلاة على النبي
  { id: "salawat", text: "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ", translation: "O Allah, send prayers and peace upon our Prophet Muhammad", defaultTarget: 100, category: "صلاة على النبي" },
  { id: "salawat_ibrahimiyyah", text: "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ كَمَا صَلَّيْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ", translation: "O Allah, send prayers upon Muhammad and upon the family of Muhammad", defaultTarget: 100, category: "صلاة على النبي" },
  
  // الحوقلة
  { id: "hawqala", text: "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", translation: "There is no power and no strength except with Allah", defaultTarget: 100, category: "ذكر" },
  
  // أسماء الله الحسنى
  { id: "ya_rahman", text: "يَا رَحْمَنُ", translation: "O Most Gracious", defaultTarget: 100, category: "أسماء الله" },
  { id: "ya_rahim", text: "يَا رَحِيمُ", translation: "O Most Merciful", defaultTarget: 100, category: "أسماء الله" },
  { id: "ya_allah", text: "يَا اللَّهُ", translation: "O Allah", defaultTarget: 100, category: "أسماء الله" },
];

const STORAGE_KEY = "noor-tasbih-state-v2";
const TARGET_OPTIONS = [33, 100, 1000];

export default function Tasbih() {
  const [state, setState] = useState<TasbihState>({
    counts: {},
    selectedTasbihId: "subhanallah",
    customTargets: {},
    dailyStats: [],
    settings: {
      vibration: false,
      sound: false,
    },
  });

  const [showSettings, setShowSettings] = useState(false);
  const [showTargetDialog, setShowTargetDialog] = useState(false);
  const [customTargetInput, setCustomTargetInput] = useState("");
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [lastCount, setLastCount] = useState<number | null>(null);
  const [showDailyStats, setShowDailyStats] = useState(false);

  const buttonRef = useRef<HTMLButtonElement>(null);

  // تحميل الحالة المحفوظة
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        setState(parsed);
      }
    } catch (e) {
      console.warn("فشل تحميل حالة المسبحة:", e);
    }
  }, []);

  // حفظ الحالة
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn("فشل حفظ حالة المسبحة:", e);
    }
  }, [state]);

  const selectedTasbih = DEFAULT_TASBIHS.find(t => t.id === state.selectedTasbihId) || DEFAULT_TASBIHS[0];
  const currentCount = state.counts[selectedTasbih.id] || 0;
  const target = state.customTargets[selectedTasbih.id] || selectedTasbih.defaultTarget;
  const progress = Math.min((currentCount / target) * 100, 100);
  const isCompleted = currentCount >= target;

  const increment = () => {
    const newCount = currentCount + 1;
    setLastCount(currentCount);

    setState(prev => ({
      ...prev,
      counts: { ...prev.counts, [selectedTasbih.id]: newCount },
    }));

    // اهتزاز خفيف
    if (state.settings.vibration && "vibrate" in navigator) {
      navigator.vibrate(30);
    }

    // صوت خفيف
    if (state.settings.sound) {
      try {
        const audio = new Audio("data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=");
        audio.volume = 0.1;
        audio.play().catch(() => {});
      } catch (e) {
        // تجاهل أخطاء الصوت
      }
    }

    // تحقق من الإكمال
    if (newCount === target) {
      updateDailyStats(newCount, true);
      if (state.settings.vibration && "vibrate" in navigator) {
        navigator.vibrate([100, 50, 100, 50, 100]);
      }
    }
  };

  const undo = () => {
    if (lastCount !== null) {
      setState(prev => ({
        ...prev,
        counts: { ...prev.counts, [selectedTasbih.id]: lastCount },
      }));
      setLastCount(null);
    }
  };

  const resetCurrent = () => {
    setState(prev => ({
      ...prev,
      counts: { ...prev.counts, [selectedTasbih.id]: 0 },
    }));
    setLastCount(null);
    setShowResetConfirm(false);
  };

  const resetAll = () => {
    if (confirm("هل تريد تصفير جميع العدادات؟")) {
      setState(prev => ({
        ...prev,
        counts: {},
      }));
      setLastCount(null);
    }
  };

  const selectTasbih = (id: string) => {
    setState(prev => ({ ...prev, selectedTasbihId: id }));
    setLastCount(null);
  };

  const setTarget = (newTarget: number) => {
    setState(prev => ({
      ...prev,
      customTargets: { ...prev.customTargets, [selectedTasbih.id]: newTarget },
    }));
    setShowTargetDialog(false);
  };

  const toggleSetting = (setting: "vibration" | "sound") => {
    setState(prev => ({
      ...prev,
      settings: { ...prev.settings, [setting]: !prev.settings[setting] },
    }));
  };

  const updateDailyStats = (count: number, completed: boolean) => {
    const today = new Date().toISOString().split("T")[0];
    setState(prev => {
      const existingIndex = prev.dailyStats.findIndex(s => s.date === today);
      const newStats = [...prev.dailyStats];
      
      if (existingIndex >= 0) {
        newStats[existingIndex] = {
          ...newStats[existingIndex],
          totalCount: newStats[existingIndex].totalCount + count,
          completedTasks: completed ? newStats[existingIndex].completedTasks + 1 : newStats[existingIndex].completedTasks,
        };
      } else {
        newStats.push({
          date: today,
          totalCount: count,
          completedTasks: completed ? 1 : 0,
        });
      }

      // احتفظ بآخر 30 يوم فقط
      if (newStats.length > 30) {
        newStats.shift();
      }

      return { ...prev, dailyStats: newStats };
    });
  };

  const totalCount = Object.values(state.counts).reduce((sum, c) => sum + c, 0);
  const todayStat = state.dailyStats.find(s => s.date === new Date().toISOString().split("T")[0]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-900 via-emerald-800 to-emerald-900 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
      {/* زخرفة إسلامية في الخلفية */}
      <div className="fixed inset-0 opacity-5 pointer-events-none">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="islamic-pattern" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
              <path d="M50 0 L100 50 L50 100 L0 50 Z" fill="none" stroke="currentColor" strokeWidth="1" />
              <circle cx="50" cy="50" r="20" fill="none" stroke="currentColor" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#islamic-pattern)" />
        </svg>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-2xl relative z-10">
        {/* الرأس */}
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-amber-400 mb-1">المسبحة الإلكترونية</h1>
            <p className="text-emerald-100 text-sm">سبّح واذكر الله</p>
          </div>
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-3 bg-white/10 hover:bg-white/20 rounded-full transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-400">
              <circle cx="12" cy="12" r="3" />
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
            </svg>
          </button>
        </div>

        {/* الإعدادات */}
        {showSettings && (
          <div className="mb-6 p-5 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20">
            <h3 className="text-lg font-bold text-amber-400 mb-4">الإعدادات</h3>
            
            <div className="space-y-3">
              <label className="flex items-center justify-between cursor-pointer">
                <span className="text-white">الاهتزاز</span>
                <input
                  type="checkbox"
                  checked={state.settings.vibration}
                  onChange={() => toggleSetting("vibration")}
                  className="w-6 h-6 accent-amber-400"
                />
              </label>
              
              <label className="flex items-center justify-between cursor-pointer">
                <span className="text-white">الصوت</span>
                <input
                  type="checkbox"
                  checked={state.settings.sound}
                  onChange={() => toggleSetting("sound")}
                  className="w-6 h-6 accent-amber-400"
                />
              </label>
            </div>

            <div className="mt-4 pt-4 border-t border-white/20 space-y-2">
              <button
                onClick={() => setShowDailyStats(!showDailyStats)}
                className="w-full px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-colors"
              >
                {showDailyStats ? "إخفاء" : "عرض"} السجل اليومي
              </button>
              
              <button
                onClick={resetAll}
                className="w-full px-4 py-2 bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-red-300 rounded-lg transition-colors"
              >
                تصفير جميع العدادات
              </button>
            </div>
          </div>
        )}

        {/* السجل اليومي */}
        {showDailyStats && (
          <div className="mb-6 p-5 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20">
            <h3 className="text-lg font-bold text-amber-400 mb-4">السجل اليومي</h3>
            
            {state.dailyStats.length === 0 ? (
              <p className="text-white/70 text-center py-4">لا توجد إحصائيات بعد</p>
            ) : (
              <div className="space-y-2">
                <div className="p-3 bg-amber-400/20 rounded-lg">
                  <p className="text-sm text-amber-200">اليوم</p>
                  <p className="text-xl font-bold text-amber-400">
                    {todayStat?.totalCount || 0} تسبيحة
                  </p>
                  <p className="text-xs text-amber-200">
                    {todayStat?.completedTasks || 0} أهداف مكتملة
                  </p>
                </div>
                
                <div className="p-3 bg-white/5 rounded-lg">
                  <p className="text-sm text-white/70">الإجمالي</p>
                  <p className="text-xl font-bold text-white">{totalCount} تسبيحة</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* اختيار الذكر */}
        <div className="mb-6">
          <label className="block text-amber-400 text-sm font-medium mb-2">اختر الذكر</label>
          <select
            value={state.selectedTasbihId}
            onChange={(e) => selectTasbih(e.target.value)}
            className="w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white text-base"
          >
            {DEFAULT_TASBIHS.map((tasbih) => {
              const count = state.counts[tasbih.id] || 0;
              const target = state.customTargets[tasbih.id] || tasbih.defaultTarget;
              const completed = count >= target;
              return (
                <option key={tasbih.id} value={tasbih.id} className="bg-emerald-900">
                  {tasbih.text} ({target})
                  {completed ? " ✓" : ""}
                </option>
              );
            })}
          </select>
        </div>

        {/* بطاقة الذكر الحالية */}
        <div className="mb-6 p-6 bg-gradient-to-br from-amber-500/20 to-amber-600/20 backdrop-blur-sm border-2 border-amber-400/30 rounded-3xl shadow-2xl">
          <div className="text-center mb-6">
            <p
              className="text-2xl font-bold leading-relaxed text-white mb-2"
              style={{ fontFamily: "Amiri, serif" }}
            >
              {selectedTasbih.text}
            </p>
            <p className="text-sm text-emerald-200">{selectedTasbih.translation}</p>
          </div>

          {/* العداد الدائري */}
          <div className="relative mx-auto w-64 h-64 mb-6">
            {/* دائرة الخلفية */}
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200">
              <circle
                cx="100"
                cy="100"
                r="90"
                fill="none"
                stroke="rgba(255,255,255,0.1)"
                strokeWidth="12"
              />
              {/* دائرة التقدم */}
              <circle
                cx="100"
                cy="100"
                r="90"
                fill="none"
                stroke="rgb(251, 191, 36)"
                strokeWidth="12"
                strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 90}`}
                strokeDashoffset={`${2 * Math.PI * 90 * (1 - progress / 100)}`}
                className="transition-all duration-300"
              />
            </svg>
            
            {/* العداد في المنتصف */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="text-6xl font-bold text-white mb-1">{currentCount}</div>
              <div className="text-lg text-amber-300">من {target}</div>
              <div className="text-sm text-emerald-200 mt-1">{Math.round(progress)}%</div>
            </div>
          </div>

          {/* رسالة الإكمال */}
          {isCompleted && (
            <div className="mb-4 p-3 bg-green-500/20 border border-green-500/30 rounded-xl text-center">
              <p className="text-green-300 font-bold">
                ✓ بارك الله فيك! أكملت {target} تسبيحة
              </p>
            </div>
          )}

          {/* زر العد */}
          <button
            ref={buttonRef}
            onClick={increment}
            className={`
              w-full py-8 rounded-2xl text-3xl font-bold
              transition-all active:scale-95 shadow-xl
              ${
                isCompleted
                  ? "bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white"
                  : "bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white"
              }
            `}
          >
            {isCompleted ? "✓ اضغط للاستمرار" : "سَبِّحْ"}
          </button>

          {/* أزرار التحكم */}
          <div className="mt-4 grid grid-cols-2 gap-3">
            <button
              onClick={undo}
              disabled={lastCount === null}
              className="px-4 py-3 bg-white/10 hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl text-white transition-colors"
            >
              ↩ تراجع
            </button>
            <button
              onClick={() => setShowResetConfirm(true)}
              className="px-4 py-3 bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-red-300 rounded-xl transition-colors"
            >
              تصفير
            </button>
          </div>

          {/* تغيير الهدف */}
          <div className="mt-4">
            <button
              onClick={() => setShowTargetDialog(true)}
              className="w-full px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-white text-sm transition-colors"
            >
              تغيير الهدف ({target})
            </button>
          </div>
        </div>

        {/* قائمة الأذكار */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-amber-400 mb-4">جميع الأذكار</h2>
          <div className="space-y-3">
            {DEFAULT_TASBIHS.map((tasbih) => {
              const count = state.counts[tasbih.id] || 0;
              const target = state.customTargets[tasbih.id] || tasbih.defaultTarget;
              const isCurrent = tasbih.id === state.selectedTasbihId;
              const isDone = count >= target;
              const itemProgress = Math.min((count / target) * 100, 100);

              return (
                <button
                  key={tasbih.id}
                  onClick={() => selectTasbih(tasbih.id)}
                  className={`
                    w-full p-4 rounded-xl border-2 transition-all text-right
                    ${
                      isCurrent
                        ? "bg-amber-400/20 border-amber-400 shadow-lg"
                        : "bg-white/5 border-white/10 hover:border-amber-400/50"
                    }
                  `}
                >
                  <div className="flex items-center justify-between gap-4 mb-2">
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-white truncate" style={{ fontFamily: "Amiri, serif" }}>
                        {tasbih.text}
                      </p>
                      <p className="text-xs text-emerald-200 mt-1">{tasbih.category}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {isDone && (
                        <span className="text-green-400">
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M20 6 9 17l-7-7" />
                          </svg>
                        </span>
                      )}
                      <div className="text-sm font-bold text-amber-400">
                        {count}/{target}
                      </div>
                    </div>
                  </div>
                  <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-amber-400 rounded-full transition-all duration-300"
                      style={{ width: `${itemProgress}%` }}
                    />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* نافذة تغيير الهدف */}
        {showTargetDialog && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
            onClick={() => setShowTargetDialog(false)}
          >
            <div
              className="bg-emerald-900 border-2 border-amber-400/30 rounded-2xl max-w-sm w-full shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                <h3 className="text-xl font-bold text-amber-400 mb-4">تغيير الهدف</h3>
                
                <div className="space-y-3 mb-4">
                  {TARGET_OPTIONS.map((option) => (
                    <button
                      key={option}
                      onClick={() => setTarget(option)}
                      className="w-full p-3 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl text-white transition-colors"
                    >
                      {option} تسبيحة
                    </button>
                  ))}
                </div>

                <div className="mb-4">
                  <label className="block text-sm text-white mb-2">هدف مخصص</label>
                  <input
                    type="number"
                    value={customTargetInput}
                    onChange={(e) => setCustomTargetInput(e.target.value)}
                    placeholder="أدخل رقماً"
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50"
                    min="1"
                  />
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      const num = parseInt(customTargetInput);
                      if (num > 0) {
                        setTarget(num);
                        setCustomTargetInput("");
                      }
                    }}
                    disabled={!customTargetInput || parseInt(customTargetInput) <= 0}
                    className="flex-1 px-4 py-2 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl text-white font-bold transition-colors"
                  >
                    تعيين
                  </button>
                  <button
                    onClick={() => setShowTargetDialog(false)}
                    className="px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-colors"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* نافذة تأكيد التصفير */}
        {showResetConfirm && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
            onClick={() => setShowResetConfirm(false)}
          >
            <div
              className="bg-emerald-900 border-2 border-red-500/30 rounded-2xl max-w-sm w-full shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6 text-center">
                <h3 className="text-xl font-bold text-red-400 mb-4">تأكيد التصفير</h3>
                <p className="text-white mb-6">
                  هل تريد تصفير عداد "{selectedTasbih.text}"؟
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={resetCurrent}
                    className="flex-1 px-4 py-3 bg-red-500 hover:bg-red-600 rounded-xl text-white font-bold transition-colors"
                  >
                    نعم، صفّر
                  </button>
                  <button
                    onClick={() => setShowResetConfirm(false)}
                    className="flex-1 px-4 py-3 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-colors"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
