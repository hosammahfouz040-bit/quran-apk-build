import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { RECITERS, getSurahAudioUrl } from "@/data/reciters";
import { SURAH_SIMPLE_NAMES } from "@/services/quranApi";
import { toArabicDigits } from "./QuranHome";
import {
  saveLastSession,
  getLastSession,
  getPlaybackSettings,
  savePlaybackSettings,
  saveFavoriteReciter,
  getPlaylists,
  addToPlaylist,
  type PlaybackSettings,
} from "@/services/playlistApi";

/**
 * صفحة قارئ القرآن المحسّنة - مشغل صوتي متقدم.
 * 
 * الميزات:
 * - مؤقت نوم
 * - التحكم في السرعة
 * - استكمال من آخر موضع
 * - قوائم تشغيل
 * - تكرار
 * - حفظ القارئ المفضل
 */
export default function EnhancedReciterPlayer() {
  const { reciterId } = useParams<{ reciterId: string }>();
  const navigate = useNavigate();
  const reciter = useMemo(
    () => RECITERS.find((r) => r.id === reciterId),
    [reciterId]
  );

  const [currentSurah, setCurrentSurah] = useState(1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [showPlaylists, setShowPlaylists] = useState(false);
  const [sleepTimerRemaining, setSleepTimerRemaining] = useState<number | null>(null);
  const [playbackSettings, setPlaybackSettings] = useState<PlaybackSettings>(
    getPlaybackSettings()
  );
  const [playlists, setPlaylists] = useState(getPlaylists());
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const sleepTimerRef = useRef<NodeJS.Timeout | null>(null);
  const sessionStartRef = useRef<Date | null>(null);

  // إنشاء عنصر الصوت مرة واحدة
  useEffect(() => {
    const audio = new Audio();
    audio.preload = "metadata";
    audioRef.current = audio;

    const onLoadedMetadata = () => {
      setDuration(audio.duration);
      setIsLoading(false);
      
      // استكمال من آخر موضع
      const lastSession = getLastSession();
      if (
        lastSession &&
        lastSession.reciterId === reciterId &&
        lastSession.surahNumber === currentSurah &&
        lastSession.currentTime > 0
      ) {
        audio.currentTime = lastSession.currentTime;
      }
    };

    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      
      // حفظ الجلسة كل 5 ثوانٍ
      if (Math.floor(audio.currentTime) % 5 === 0 && reciterId) {
        saveLastSession({
          reciterId,
          surahNumber: currentSurah,
          currentTime: audio.currentTime,
          duration: audio.duration,
          timestamp: new Date().toISOString(),
        });
      }
    };

    const onEnded = () => {
      // التعامل مع وضع التكرار
      if (playbackSettings.repeatMode === "one") {
        audio.currentTime = 0;
        audio.play();
      } else if (playbackSettings.repeatMode === "all" || currentSurah < 114) {
        setCurrentSurah((prev) => (prev < 114 ? prev + 1 : 1));
      } else {
        setIsPlaying(false);
      }
    };

    const onError = () => {
      setIsLoading(false);
      setIsPlaying(false);
      console.error("تعذّر تحميل الملف الصوتي");
    };

    const onWaiting = () => setIsLoading(true);
    const onCanPlay = () => setIsLoading(false);

    audio.addEventListener("loadedmetadata", onLoadedMetadata);
    audio.addEventListener("timeupdate", onTimeUpdate);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("error", onError);
    audio.addEventListener("waiting", onWaiting);
    audio.addEventListener("canplay", onCanPlay);

    return () => {
      audio.pause();
      audio.removeEventListener("loadedmetadata", onLoadedMetadata);
      audio.removeEventListener("timeupdate", onTimeUpdate);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("error", onError);
      audio.removeEventListener("waiting", onWaiting);
      audio.removeEventListener("canplay", onCanPlay);
    };
  }, [reciterId, currentSurah, playbackSettings.repeatMode]);

  // تحميل السورة الحالية
  useEffect(() => {
    if (!audioRef.current || !reciter) return;
    const audio = audioRef.current;
    const url = getSurahAudioUrl(reciter, currentSurah);
    audio.src = url;
    audio.playbackRate = playbackSettings.speed;
    setCurrentTime(0);
    setDuration(0);
    setIsLoading(true);
    audio.load();
    if (isPlaying) {
      audio.play().catch(() => {
        setIsPlaying(false);
      });
    }
  }, [currentSurah, reciter, playbackSettings.speed, isPlaying]);

  // التحكم في التشغيل/الإيقاف
  useEffect(() => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.play().catch(() => setIsPlaying(false));
      sessionStartRef.current = new Date();
    } else {
      audioRef.current.pause();
    }
  }, [isPlaying]);

  // مؤقت النوم
  useEffect(() => {
    if (playbackSettings.sleepTimer && isPlaying) {
      const startTime = sessionStartRef.current || new Date();
      
      sleepTimerRef.current = setInterval(() => {
        const elapsed = (Date.now() - startTime.getTime()) / 1000 / 60;
        const remaining = playbackSettings.sleepTimer! - elapsed;
        
        if (remaining <= 0) {
          // إيقاف التشغيل
          setIsPlaying(false);
          setSleepTimerRemaining(null);
          setPlaybackSettings((prev) => ({ ...prev, sleepTimer: null }));
          savePlaybackSettings({ ...playbackSettings, sleepTimer: null });
          if (sleepTimerRef.current) {
            clearInterval(sleepTimerRef.current);
          }
        } else {
          setSleepTimerRemaining(remaining);
        }
      }, 1000);

      return () => {
        if (sleepTimerRef.current) {
          clearInterval(sleepTimerRef.current);
        }
      };
    }
  }, [playbackSettings.sleepTimer, isPlaying]);

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const handleSpeedChange = (speed: number) => {
    const newSettings = { ...playbackSettings, speed };
    setPlaybackSettings(newSettings);
    savePlaybackSettings(newSettings);
    if (audioRef.current) {
      audioRef.current.playbackRate = speed;
    }
  };

  const handleRepeatModeChange = (mode: PlaybackSettings["repeatMode"]) => {
    const newSettings = { ...playbackSettings, repeatMode: mode };
    setPlaybackSettings(newSettings);
    savePlaybackSettings(newSettings);
  };

  const handleSleepTimerChange = (minutes: number | null) => {
    const newSettings = { ...playbackSettings, sleepTimer: minutes };
    setPlaybackSettings(newSettings);
    savePlaybackSettings(newSettings);
    setSleepTimerRemaining(minutes);
    sessionStartRef.current = new Date();
  };

  const handleAddToPlaylist = (playlistId: string) => {
    if (!reciter) return;
    addToPlaylist(
      playlistId,
      reciter.id,
      reciter.nameAr,
      currentSurah,
      SURAH_SIMPLE_NAMES[currentSurah] || `سورة ${currentSurah}`
    );
    setPlaylists(getPlaylists());
    setShowPlaylists(false);
  };

  const handleSaveAsFavorite = () => {
    if (!reciter) return;
    saveFavoriteReciter(reciter.id, currentSurah);
    alert(`تم حفظ ${reciter.nameAr} كقارئ مفضل لسورة ${SURAH_SIMPLE_NAMES[currentSurah]}`);
  };

  if (!reciter) {
    return (
      <div className="px-4 pt-6 text-center">
        <p className="text-sm font-bold text-red-600">القارئ غير موجود</p>
        <button
          onClick={() => navigate("/reciters")}
          className="tap-highlight mt-4 inline-block rounded-2xl bg-brand-900 px-4 py-2 text-sm font-bold text-gold-300"
        >
          العودة للقائمة
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-900 to-emerald-950 dark:from-slate-900 dark:to-slate-950">
      <div className="container mx-auto px-4 py-6 max-w-2xl">
        {/* معلومات القارئ والسورة */}
        <div className="mb-6 text-center text-white">
          <h1 className="text-2xl font-bold text-emerald-400 mb-2">
            {reciter.nameAr}
          </h1>
          <p className="text-emerald-200">
            سورة {SURAH_SIMPLE_NAMES[currentSurah] || currentSurah}
          </p>
        </div>

        {/* المشغل */}
        <div className="mb-6 p-6 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20">
          {/* شريط التقدم */}
          <div className="mb-4">
            <input
              type="range"
              min="0"
              max={duration || 0}
              value={currentTime}
              onChange={handleSeek}
              className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer accent-emerald-500"
            />
            <div className="flex justify-between text-xs text-emerald-200 mt-2">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* أزرار التحكم الرئيسية */}
          <div className="flex items-center justify-center gap-4 mb-4">
            <button
              onClick={() => setCurrentSurah((prev) => Math.max(1, prev - 1))}
              disabled={currentSurah <= 1}
              className="p-3 bg-white/10 hover:bg-white/20 rounded-full transition-colors disabled:opacity-50"
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="19 20 9 12 19 4 19 20" />
                <line x1="5" y1="19" x2="5" y2="5" />
              </svg>
            </button>

            <button
              onClick={() => setIsPlaying(!isPlaying)}
              disabled={isLoading}
              className="p-4 bg-emerald-600 hover:bg-emerald-700 rounded-full transition-colors disabled:opacity-50"
            >
              {isLoading ? (
                <svg className="animate-spin" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                </svg>
              ) : isPlaying ? (
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="6" y="4" width="4" height="16" />
                  <rect x="14" y="4" width="4" height="16" />
                </svg>
              ) : (
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="5 3 19 12 5 21 5 3" />
                </svg>
              )}
            </button>

            <button
              onClick={() => setCurrentSurah((prev) => Math.min(114, prev + 1))}
              disabled={currentSurah >= 114}
              className="p-3 bg-white/10 hover:bg-white/20 rounded-full transition-colors disabled:opacity-50"
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="5 4 15 12 5 20 5 4" />
                <line x1="19" y1="5" x2="19" y2="19" />
              </svg>
            </button>
          </div>

          {/* أزرار التحكم الإضافية */}
          <div className="flex items-center justify-center gap-2 mb-4">
            <button
              onClick={handleSaveAsFavorite}
              className="px-3 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-xs text-white transition-colors"
            >
              ❤️ حفظ كمفضل
            </button>
            <button
              onClick={() => setShowPlaylists(!showPlaylists)}
              className="px-3 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-xs text-white transition-colors"
            >
              📋 قائمة تشغيل
            </button>
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="px-3 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-xs text-white transition-colors"
            >
              ⚙️ إعدادات
            </button>
          </div>

          {/* مؤقت النوم */}
          {sleepTimerRemaining !== null && (
            <div className="p-3 bg-amber-500/20 border border-amber-500/30 rounded-lg text-center">
              <p className="text-amber-300 text-sm">
                ⏰ سيتم الإيقاف خلال: {Math.ceil(sleepTimerRemaining)} دقيقة
              </p>
            </div>
          )}
        </div>

        {/* قائمة القراءات */}
        <div className="mb-6 p-4 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20">
          <h2 className="text-lg font-bold text-white mb-3">اختر سورة</h2>
          <div className="grid grid-cols-3 gap-2 max-h-96 overflow-y-auto">
            {Array.from({ length: 114 }, (_, i) => i + 1).map((num) => (
              <button
                key={num}
                onClick={() => setCurrentSurah(num)}
                className={`p-2 rounded-lg text-xs transition-colors ${
                  currentSurah === num
                    ? "bg-emerald-600 text-white"
                    : "bg-white/10 text-white hover:bg-white/20"
                }`}
              >
                {toArabicDigits(num)}
              </button>
            ))}
          </div>
        </div>

        {/* الإعدادات */}
        {showSettings && (
          <div className="mb-6 p-6 bg-white dark:bg-slate-800 rounded-2xl shadow-lg">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4">
              إعدادات التشغيل
            </h2>

            {/* السرعة */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                سرعة التشغيل: {playbackSettings.speed}x
              </label>
              <div className="grid grid-cols-6 gap-2">
                {[0.5, 0.75, 1, 1.25, 1.5, 2].map((speed) => (
                  <button
                    key={speed}
                    onClick={() => handleSpeedChange(speed)}
                    className={`p-2 rounded-lg text-xs transition-colors ${
                      playbackSettings.speed === speed
                        ? "bg-emerald-600 text-white"
                        : "bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600"
                    }`}
                  >
                    {speed}x
                  </button>
                ))}
              </div>
            </div>

            {/* وضع التكرار */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                وضع التكرار
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => handleRepeatModeChange("none")}
                  className={`p-2 rounded-lg text-xs transition-colors ${
                    playbackSettings.repeatMode === "none"
                      ? "bg-emerald-600 text-white"
                      : "bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600"
                  }`}
                >
                  بدون تكرار
                </button>
                <button
                  onClick={() => handleRepeatModeChange("one")}
                  className={`p-2 rounded-lg text-xs transition-colors ${
                    playbackSettings.repeatMode === "one"
                      ? "bg-emerald-600 text-white"
                      : "bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600"
                  }`}
                >
                  تكرار السورة
                </button>
                <button
                  onClick={() => handleRepeatModeChange("all")}
                  className={`p-2 rounded-lg text-xs transition-colors ${
                    playbackSettings.repeatMode === "all"
                      ? "bg-emerald-600 text-white"
                      : "bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600"
                  }`}
                >
                  تكرار الكل
                </button>
              </div>
            </div>

            {/* مؤقت النوم */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                مؤقت النوم
              </label>
              <div className="grid grid-cols-5 gap-2">
                <button
                  onClick={() => handleSleepTimerChange(null)}
                  className={`p-2 rounded-lg text-xs transition-colors ${
                    playbackSettings.sleepTimer === null
                      ? "bg-emerald-600 text-white"
                      : "bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600"
                  }`}
                >
                  إيقاف
                </button>
                {[15, 30, 45, 60].map((minutes) => (
                  <button
                    key={minutes}
                    onClick={() => handleSleepTimerChange(minutes)}
                    className={`p-2 rounded-lg text-xs transition-colors ${
                      playbackSettings.sleepTimer === minutes
                        ? "bg-emerald-600 text-white"
                        : "bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600"
                    }`}
                  >
                    {minutes} د
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* قوائم التشغيل */}
        {showPlaylists && (
          <div className="mb-6 p-6 bg-white dark:bg-slate-800 rounded-2xl shadow-lg">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4">
              إضافة إلى قائمة تشغيل
            </h2>
            {playlists.length === 0 ? (
              <p className="text-slate-600 dark:text-slate-400 text-center py-4">
                لا توجد قوائم تشغيل. قم بإنشاء واحدة من صفحة القوائم.
              </p>
            ) : (
              <div className="space-y-2">
                {playlists.map((playlist) => (
                  <button
                    key={playlist.id}
                    onClick={() => handleAddToPlaylist(playlist.id)}
                    className="w-full p-3 bg-slate-50 dark:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 rounded-lg text-right transition-colors"
                  >
                    <p className="font-medium text-slate-900 dark:text-white">
                      {playlist.name}
                    </p>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      {playlist.items.length} عنصر
                    </p>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

/**
 * تنسيق الوقت (ثواني إلى MM:SS)
 */
function formatTime(seconds: number): string {
  if (!seconds || isNaN(seconds)) return "0:00";
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, "0")}`;
}
