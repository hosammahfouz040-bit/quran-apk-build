import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  getAzkarByCategory,
  saveAzkarProgress,
  getAzkarProgress,
  clearAzkarProgress,
  ALL_AZKAR_CATEGORIES,
  type Zikr,
} from "@/services/azkarApi";

export default function AzkarCategory() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const categoryId = parseInt(id || "1", 10);

  const [azkar, setAzkar] = useState<Zikr[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [counters, setCounters] = useState<{ [key: number]: number }>({});

  const category = ALL_AZKAR_CATEGORIES.find((c) => c.id === categoryId);

  useEffect(() => {
    loadAzkar();
  }, [categoryId]);

  const loadAzkar = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getAzkarByCategory(categoryId);
      setAzkar(data);

      // تحميل التقدم المحفوظ
      const progress = getAzkarProgress();
      if (progress[categoryId]) {
        setCounters(progress[categoryId]);
      } else {
        // تهيئة العدادات
        const initial: { [key: number]: number } = {};
        data.forEach((z) => {
          initial[z.id] = 0;
        });
        setCounters(initial);
      }
    } catch (e: any) {
      setError(e.message || "فشل في تحميل الأذكار");
    } finally {
      setLoading(false);
    }
  };

  const incrementCounter = (zikrId: number, maxCount: number) => {
    setCounters((prev) => {
      const newCount = (prev[zikrId] || 0) + 1;
      const updated = { ...prev, [zikrId]: newCount };

      // حفظ التقدم
      saveAzkarProgress(categoryId, zikrId, newCount);

      // اهتزاز خفيف عند الوصول للعدد المطلوب
      if (newCount === maxCount && "vibrate" in navigator) {
        navigator.vibrate(100);
      }

      return updated;
    });
  };

  const resetCounter = (zikrId: number) => {
    setCounters((prev) => {
      const updated = { ...prev, [zikrId]: 0 };
      saveAzkarProgress(categoryId, zikrId, 0);
      return updated;
    });
  };

  const resetAll = () => {
    if (confirm("هل تريد مسح جميع العدادات؟")) {
      const initial: { [key: number]: number } = {};
      azkar.forEach((z) => {
        initial[z.id] = 0;
      });
      setCounters(initial);
      clearAzkarProgress(categoryId);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="text-center py-12">
          <p className="text-muted-foreground">جاري تحميل الأذكار...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="text-center py-12">
          <p className="text-destructive mb-4">{error}</p>
          <button
            onClick={loadAzkar}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
          >
            إعادة المحاولة
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      {/* الرأس */}
      <div className="mb-6 flex items-center gap-4">
        <button
          onClick={() => navigate("/azkar")}
          className="p-2 hover:bg-muted rounded-lg transition-colors"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="m15 18-6-6 6-6" />
          </svg>
        </button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold">{category?.name}</h1>
          <p className="text-sm text-muted-foreground">
            {azkar.length} ذكر
          </p>
        </div>
        <button
          onClick={resetAll}
          className="px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          مسح العدادات
        </button>
      </div>

      {/* قائمة الأذكار */}
      <div className="space-y-4">
        {azkar.map((zikr) => {
          const count = counters[zikr.id] || 0;
          const isComplete = count >= zikr.repeat;

          return (
            <div
              key={zikr.id}
              className={`p-6 bg-card border rounded-lg transition-all ${
                isComplete ? "border-green-500 bg-green-50 dark:bg-green-950/20" : "border-border"
              }`}
            >
              {/* النص */}
              <div
                className="text-lg leading-loose mb-4 text-right"
                dir="rtl"
                style={{ fontFamily: "Amiri, serif" }}
                dangerouslySetInnerHTML={{ __html: zikr.text }}
              />

              {/* معلومات إضافية */}
              <div className="flex items-center justify-between mt-4 pt-4 border-t">
                <div className="text-sm text-muted-foreground">
                  <span>التكرار: {zikr.repeat}</span>
                </div>

                {/* العداد */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => resetCounter(zikr.id)}
                    className="p-2 text-muted-foreground hover:text-foreground transition-colors"
                    title="إعادة تعيين"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
                      <path d="M3 3v5h5" />
                    </svg>
                  </button>

                  <button
                    onClick={() => incrementCounter(zikr.id, zikr.repeat)}
                    disabled={isComplete}
                    className={`
                      px-6 py-3 rounded-lg font-bold text-lg transition-all
                      ${
                        isComplete
                          ? "bg-green-500 text-white cursor-default"
                          : "bg-primary text-primary-foreground hover:bg-primary/90 active:scale-95"
                      }
                    `}
                  >
                    {count} / {zikr.repeat}
                  </button>
                </div>
              </div>

              {/* رسالة الإكمال */}
              {isComplete && (
                <div className="mt-3 text-sm text-green-600 dark:text-green-400 font-medium">
                  ✓ تم إكمال هذا الذكر
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* معلومات المصدر */}
      <div className="mt-8 p-4 bg-muted rounded-lg text-xs text-muted-foreground">
        <p>المصدر: حصن المسلم - سعيد بن علي بن وهف القحطاني</p>
        <p className="mt-1">يتم حفظ تقدمك تلقائياً على جهازك</p>
      </div>
    </div>
  );
}
