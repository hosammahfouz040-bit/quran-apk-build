import { Link } from "react-router-dom";
import { MAIN_AZKAR_CATEGORIES, ALL_AZKAR_CATEGORIES } from "@/services/azkarApi";

export default function Azkar() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-primary mb-2">الأذكار</h1>
        <p className="text-muted-foreground">
          من كتاب حصن المسلم - سعيد بن علي بن وهف القحطاني
        </p>
      </div>

      {/* الفئات الرئيسية */}
      <section className="mb-10">
        <h2 className="text-xl font-semibold mb-4">الأذكار اليومية</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {MAIN_AZKAR_CATEGORIES.map((category) => (
            <Link
              key={category.id}
              to={`/azkar/${category.id}`}
              className="block p-6 bg-card border border-border rounded-lg hover:border-primary transition-colors"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold mb-1">{category.name}</h3>
                  <p className="text-sm text-muted-foreground">
                    {category.count} ذكر
                  </p>
                </div>
                <div className="text-primary">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m15 18-6-6 6-6" />
                  </svg>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* جميع الفئات */}
      <section>
        <h2 className="text-xl font-semibold mb-4">جميع الأذكار</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {ALL_AZKAR_CATEGORIES.map((category) => (
            <Link
              key={category.id}
              to={`/azkar/${category.id}`}
              className="block p-4 bg-card border border-border rounded-lg hover:border-primary transition-colors"
            >
              <h3 className="font-medium text-sm mb-1">{category.name}</h3>
              <p className="text-xs text-muted-foreground">
                {category.count} ذكر
              </p>
            </Link>
          ))}
        </div>
      </section>

      {/* معلومات المصدر */}
      <div className="mt-10 p-4 bg-muted rounded-lg text-sm text-muted-foreground">
        <p className="font-semibold mb-1">المصدر:</p>
        <p>حصن المسلم - سعيد بن علي بن وهف القحطاني</p>
        <p className="mt-2 text-xs">
          البيانات من: hisnmuslim.com - جميع الأذكار صحيحة ومأخوذة من الكتاب مباشرة
        </p>
      </div>
    </div>
  );
}
