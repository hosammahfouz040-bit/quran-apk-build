import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import type { Section } from "@/data/sections";

type Props = {
  section: Section;
};

/**
 * صفحة placeholder موحّدة لجميع الأقسام في المرحلة الأولى.
 * تُظهر اسم القسم وأيقونته وتوضّح أن المحتوى سيكون جاهزاً في مرحلة لاحقة.
 */
export default function ComingSoon({ section }: Props) {
  return (
    <div className="px-4 pt-5 pb-4">
      {/* بطاقة القسم الرئيسية */}
      <div
        className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${section.accent} p-6 text-white shadow-xl`}
      >
        <svg
          className="pointer-events-none absolute -left-4 -top-4 text-white/10"
          width="120"
          height="120"
          viewBox="0 0 120 120"
          fill="none"
        >
          <path
            d="M60 10 L75 45 L110 60 L75 75 L60 110 L45 75 L10 60 L45 45 Z"
            stroke="currentColor"
            strokeWidth="1.5"
          />
          <circle cx="60" cy="60" r="25" stroke="currentColor" strokeWidth="1" />
        </svg>

        <div className="relative">
          <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-white/15 backdrop-blur-sm">
            <div className="text-white">{section.icon}</div>
          </div>
          <h2 className="text-2xl font-extrabold">{section.title}</h2>
          <p className="mt-1 text-sm font-medium text-white/80">
            {section.subtitle}
          </p>
        </div>
      </div>

      {/* بطاقة "قيد التطوير" */}
      <div className="mt-4 rounded-2xl border border-brand-100 bg-white p-5 shadow-sm">
        <div className="flex items-start gap-3">
          <div className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gold-50 text-gold-600">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="text-base font-extrabold text-brand-900">
              هذا القسم قيد التطوير
            </h3>
            <p className="mt-1 text-sm leading-relaxed text-slate-600">
              تم تجهيز واجهة هذا القسم وسيتم إضافة المحتوى الموثوق في المراحل
              القادمة من تطوير التطبيق، إن شاء الله.
            </p>
          </div>
        </div>

        <StatusRow label="الواجهة" status="مكتملة" done />
        <StatusRow label="التنقل" status="مكتمل" done />
        <StatusRow label="المحتوى" status="قريباً" />
        <StatusRow label="الميزات التفاعلية" status="قريباً" />
      </div>

      {/* زر العودة */}
      <Link
        to="/"
        className="tap-highlight mt-4 flex w-full items-center justify-center gap-2 rounded-2xl border border-brand-200 bg-white px-4 py-3 text-sm font-bold text-brand-800 shadow-sm hover:bg-brand-50"
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1v-9.5Z" />
        </svg>
        العودة للصفحة الرئيسية
      </Link>
    </div>
  );
}

function StatusRow({
  label,
  status,
  done,
}: {
  label: string;
  status: string;
  done?: boolean;
}) {
  return (
    <div className="mt-2 flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2">
      <span className="text-sm font-medium text-slate-700">{label}</span>
      <span
        className={`flex items-center gap-1 text-xs font-bold ${
          done ? "text-brand-700" : "text-gold-600"
        }`}
      >
        {done ? (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12" />
          </svg>
        ) : (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
        )}
        {status}
      </span>
    </div>
  );
}

export function PagePlaceholder(props: { section: Section }): ReactNode {
  return <ComingSoon section={props.section} />;
}
