import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  getMemorizationPlans,
  deleteMemorizationPlan,
  createMemorizationPlan,
  calculatePlanProgress,
  getDailyProgress,
  type MemorizationPlan,
  type DailyProgress,
} from "@/services/memorizationApi";

export default function Memorization() {
  const navigate = useNavigate();
  const [plans, setPlans] = useState<MemorizationPlan[]>([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newPlanName, setNewPlanName] = useState("");
  const [newPlanGoal, setNewPlanGoal] = useState(5);
  const [todayProgress, setTodayProgress] = useState<DailyProgress | null>(null);

  useEffect(() => {
    loadPlans();
    loadTodayProgress();
  }, []);

  const loadPlans = () => {
    const savedPlans = getMemorizationPlans();
    setPlans(savedPlans);
  };

  const loadTodayProgress = () => {
    const today = new Date().toISOString().split("T")[0];
    const allProgress = getDailyProgress();
    const todayData = allProgress.find((p) => p.date === today);
    setTodayProgress(todayData || null);
  };

  const handleCreatePlan = () => {
    if (!newPlanName.trim()) {
      alert("يرجى إدخال اسم الخطة");
      return;
    }

    // إنشاء خطة نموذجية بسورة الفاتحة
    const plan = createMemorizationPlan(newPlanName, [1], newPlanGoal);
    setPlans([...plans, plan]);
    setNewPlanName("");
    setNewPlanGoal(5);
    setShowCreateForm(false);
  };

  const handleDeletePlan = (planId: string) => {
    if (confirm("هل أنت متأكد من حذف هذه الخطة؟")) {
      deleteMemorizationPlan(planId);
      setPlans(plans.filter((p) => p.id !== planId));
    }
  };

  const startReviewSession = (planId: string) => {
    navigate(`/memorization/review/${planId}`);
  };

  const viewPlanDetails = (planId: string) => {
    navigate(`/memorization/plan/${planId}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 to-white dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* الرأس */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-emerald-700 dark:text-emerald-400 mb-2">
            حفظ القرآن ومراجعته
          </h1>
          <p className="text-slate-600 dark:text-slate-300">
            خطط لحفظ القرآن وتابع تقدمك اليومي
          </p>
        </div>

        {/* إحصائيات اليوم */}
        <div className="mb-6 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-emerald-100 dark:border-slate-700">
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">آيات محفوظة</p>
            <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">
              {todayProgress?.versesMemorized || 0}
            </p>
          </div>
          <div className="p-4 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-emerald-100 dark:border-slate-700">
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">آيات مراجعة</p>
            <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
              {todayProgress?.versesReviewed || 0}
            </p>
          </div>
          <div className="p-4 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-emerald-100 dark:border-slate-700">
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">جلسات المراجعة</p>
            <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">
              {todayProgress?.reviewSessions || 0}
            </p>
          </div>
          <div className="p-4 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-emerald-100 dark:border-slate-700">
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">الإنجاز</p>
            <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">
              {todayProgress?.achievement || 0}%
            </p>
          </div>
        </div>

        {/* زر إنشاء خطة جديدة */}
        {!showCreateForm && (
          <button
            onClick={() => setShowCreateForm(true)}
            className="w-full mb-6 p-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-md transition-colors flex items-center justify-center gap-2"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <line x1="12" y1="5" x2="12" y2="19" />
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
            إنشاء خطة حفظ جديدة
          </button>
        )}

        {/* نموذج إنشاء خطة */}
        {showCreateForm && (
          <div className="mb-6 p-6 bg-white dark:bg-slate-800 rounded-xl shadow-md border border-emerald-100 dark:border-slate-700">
            <h2 className="text-xl font-bold text-emerald-700 dark:text-emerald-400 mb-4">
              خطة حفظ جديدة
            </h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  اسم الخطة
                </label>
                <input
                  type="text"
                  value={newPlanName}
                  onChange={(e) => setNewPlanName(e.target.value)}
                  placeholder="مثال: حفظ سورة البقرة"
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-slate-900 dark:text-white placeholder-slate-400"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  الهدف اليومي (عدد الآيات)
                </label>
                <input
                  type="number"
                  min="1"
                  max="50"
                  value={newPlanGoal}
                  onChange={(e) => setNewPlanGoal(parseInt(e.target.value))}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleCreatePlan}
                  className="flex-1 px-4 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors"
                >
                  إنشاء الخطة
                </button>
                <button
                  onClick={() => setShowCreateForm(false)}
                  className="px-4 py-3 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 rounded-lg transition-colors"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        )}

        {/* قائمة الخطط */}
        {plans.length === 0 ? (
          <div className="p-12 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-emerald-100 dark:border-slate-700 text-center">
            <svg
              className="mx-auto mb-4 text-slate-400"
              width="64"
              height="64"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <polyline points="14 2 14 8 20 8" />
              <line x1="16" y1="13" x2="8" y2="13" />
              <line x1="16" y1="17" x2="8" y2="17" />
              <polyline points="10 9 9 9 8 9" />
            </svg>
            <p className="text-slate-600 dark:text-slate-400 mb-4">
              لا توجد خطط حفظ بعد
            </p>
            <p className="text-sm text-slate-500 dark:text-slate-500">
              ابدأ بإنشاء خطة حفظ جديدة لتنظيم حفظك للقرآن الكريم
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {plans.map((plan) => {
              const progress = calculatePlanProgress(plan);
              return (
                <div
                  key={plan.id}
                  className="p-6 bg-white dark:bg-slate-800 rounded-xl shadow-md border border-emerald-100 dark:border-slate-700 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-emerald-700 dark:text-emerald-400 mb-1">
                        {plan.name}
                      </h3>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        بدأت في: {new Date(plan.startDate).toLocaleDateString("ar-SA")}
                      </p>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        الهدف اليومي: {plan.dailyGoal} آية
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold text-emerald-600 dark:text-emerald-400">
                        {progress}%
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-500">الإنجاز</p>
                    </div>
                  </div>

                  {/* شريط التقدم */}
                  <div className="mb-4">
                    <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-emerald-500 to-emerald-600 h-full rounded-full transition-all duration-500"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>

                  {/* الأزرار */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => viewPlanDetails(plan.id)}
                      className="flex-1 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors text-sm"
                    >
                      عرض التفاصيل
                    </button>
                    <button
                      onClick={() => startReviewSession(plan.id)}
                      className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm"
                    >
                      بدء المراجعة
                    </button>
                    <button
                      onClick={() => handleDeletePlan(plan.id)}
                      className="px-4 py-2 bg-red-100 hover:bg-red-200 dark:bg-red-900/30 dark:hover:bg-red-900/50 text-red-600 dark:text-red-400 rounded-lg transition-colors text-sm"
                    >
                      حذف
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* معلومات */}
        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-200 dark:border-blue-800">
          <h3 className="font-semibold text-blue-700 dark:text-blue-400 mb-2">
            💡 نصائح للحفظ
          </h3>
          <ul className="space-y-1 text-sm text-blue-600 dark:text-blue-300">
            <li>• احرص على المراجعة اليومية للحفظ الجديد</li>
            <li>• خصص وقتاً ثابتاً يومياً للحفظ</li>
            <li>• ابدأ بالقليل وزد تدريجياً</li>
            <li>• استخدم التكرار والاستماع لتثبيت الحفظ</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
