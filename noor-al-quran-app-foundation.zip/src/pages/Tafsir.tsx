import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  getSurahTafsir,
  TAFSIR_EDITIONS,
  type TafsirAyah,
} from "@/services/tafsirApi";
import { SURAH_SIMPLE_NAMES } from "@/services/quranApi";

export default function Tafsir() {
  const navigate = useNavigate();
  const [selectedSurah, setSelectedSurah] = useState(1);
  const [selectedEdition, setSelectedEdition] = useState("ar.muyassar");
  const [tafsirData, setTafsirData] = useState<TafsirAyah[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadTafsir();
  }, [selectedSurah, selectedEdition]);

  const loadTafsir = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getSurahTafsir(selectedSurah, selectedEdition);
      setTafsirData(data);
    } catch (e: any) {
      setError(e.message || "فشل في تحميل التفسير");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      {/* الرأس */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-primary mb-2">تفسير القرآن</h1>
        <p className="text-muted-foreground">
          اختر السورة والتفسير لعرض التفسير الكامل
        </p>
      </div>

      {/* أدوات الاختيار */}
      <div className="mb-6 space-y-4">
        {/* اختيار السورة */}
        <div>
          <label className="block text-sm font-medium mb-2">اختر السورة</label>
          <select
            value={selectedSurah}
            onChange={(e) => setSelectedSurah(parseInt(e.target.value, 10))}
            className="w-full px-4 py-3 bg-card border border-border rounded-lg text-base"
          >
            {Array.from({ length: 114 }, (_, i) => i + 1).map((num) => (
              <option key={num} value={num}>
                {num}. {SURAH_SIMPLE_NAMES[num]}
              </option>
            ))}
          </select>
        </div>

        {/* اختيار التفسير */}
        <div>
          <label className="block text-sm font-medium mb-2">اختر التفسير</label>
          <select
            value={selectedEdition}
            onChange={(e) => setSelectedEdition(e.target.value)}
            className="w-full px-4 py-3 bg-card border border-border rounded-lg text-base"
          >
            {TAFSIR_EDITIONS.map((edition) => (
              <option key={edition.id} value={edition.id}>
                {edition.name} - {edition.description}
              </option>
            ))}
          </select>
        </div>

        {/* زر الانتقال للقراءة */}
        <button
          onClick={() => navigate(`/quran/${selectedSurah}`)}
          className="w-full px-4 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
        >
          قراءة السورة
        </button>
      </div>

      {/* اسم السورة */}
      <div className="mb-4 p-4 bg-primary/10 rounded-lg text-center">
        <h2 className="text-2xl font-bold text-primary">
          سورة {SURAH_SIMPLE_NAMES[selectedSurah]}
        </h2>
      </div>

      {/* محتوى التفسير */}
      {loading && (
        <div className="text-center py-12">
          <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent" />
          <p className="mt-4 text-muted-foreground">جاري تحميل التفسير...</p>
        </div>
      )}

      {error && (
        <div className="text-center py-12">
          <p className="text-destructive mb-4">{error}</p>
          <button
            onClick={loadTafsir}
            className="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
          >
            إعادة المحاولة
          </button>
        </div>
      )}

      {!loading && !error && (
        <div className="space-y-6">
          {tafsirData.map((ayah) => (
            <div
              key={ayah.number}
              className="p-6 bg-card border border-border rounded-lg"
            >
              {/* رقم الآية */}
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-border">
                <span className="text-sm font-semibold text-muted-foreground">
                  الآية {ayah.numberInSurah}
                </span>
              </div>

              {/* نص التفسير */}
              <div
                className="text-lg leading-loose text-right"
                dir="rtl"
                style={{ fontFamily: "Amiri, serif" }}
              >
                {ayah.text}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* معلومات المصدر */}
      <div className="mt-8 p-4 bg-muted rounded-lg text-sm text-muted-foreground">
        <p className="font-semibold mb-2">المصادر المتاحة:</p>
        <ul className="space-y-1 text-xs">
          <li>• التفسير الميسر - مجموعة من العلماء</li>
          <li>• تفسير الجلالين - السيوطي والمحلي</li>
          <li>• تفسير القرطبي - الجامع لأحكام القرآن</li>
          <li>• تفسير البغوي - معالم التنزيل</li>
          <li>• التفسير الوسيط - طنطاوي</li>
        </ul>
        <p className="mt-3 text-xs">
          المصدر: AlQuran.cloud API - جميع التفاسير معتمدة وموثوقة
        </p>
      </div>
    </div>
  );
}
