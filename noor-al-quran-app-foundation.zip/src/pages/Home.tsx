import { Link } from "react-router-dom";
import { sections } from "@/data/sections";
import InstallButton from "@/components/InstallButton";

export default function Home() {
  return (
    <div className="px-4 pt-5 pb-2">
      {/* زر تثبيت التطبيق */}
      <InstallButton />

      {/* زر تنزيل APK */}
      <Link
        to="/download-app"
        className="tap-highlight w-full mb-4 p-4 bg-gradient-to-l from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white rounded-2xl shadow-lg transition-all flex items-center gap-3"
      >
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/20 backdrop-blur-sm">
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
            <polyline points="7 10 12 15 17 10" />
            <line x1="12" y1="15" x2="12" y2="3" />
          </svg>
        </div>
        <div className="flex-1 text-right">
          <p className="text-base font-bold">تنزيل ملف APK</p>
          <p className="text-xs opacity-90">احصل على ملف APK جاهز للتثبيت</p>
        </div>
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="opacity-70"
        >
          <path d="M15 6l-6 6 6 6" />
        </svg>
      </Link>
      {/* بطاقة ترحيبية */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-800 via-brand-900 to-brand-950 p-5 text-white shadow-xl shadow-brand-900/30">
        {/* زخرفة ذهبية */}
        <svg
          className="pointer-events-none absolute -left-6 -top-6 text-gold-400/20"
          width="140"
          height="140"
          viewBox="0 0 140 140"
          fill="none"
        >
          <path
            d="M70 10 L85 55 L130 70 L85 85 L70 130 L55 85 L10 70 L55 55 Z"
            stroke="currentColor"
            strokeWidth="1.5"
          />
          <circle cx="70" cy="70" r="30" stroke="currentColor" strokeWidth="1" />
          <circle cx="70" cy="70" r="15" stroke="currentColor" strokeWidth="0.8" />
        </svg>
        <svg
          className="pointer-events-none absolute -bottom-8 -right-8 text-gold-400/15"
          width="120"
          height="120"
          viewBox="0 0 120 120"
          fill="none"
        >
          <path
            d="M60 10 L75 45 L110 60 L75 75 L60 110 L45 75 L10 60 L45 45 Z"
            stroke="currentColor"
            strokeWidth="1.5"
          />
        </svg>

        <div className="relative">
          <p className="mb-1 text-xs font-semibold text-gold-300">
            بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
          </p>
          <h2 className="font-amiri text-2xl font-bold leading-snug">
            أهلاً بك في نور القرآن
          </h2>
          <p className="mt-1.5 text-sm font-medium text-brand-100/90">
            رفيقك اليومي للعبادة والذكر
          </p>

          {/* إحصائيات تشجيعية (ثابتة - لا تعتمد على بيانات حقيقية) */}
          <div className="mt-4 grid grid-cols-3 gap-2">
            <div className="rounded-xl bg-white/10 px-3 py-2 text-center backdrop-blur-sm">
              <div className="text-lg font-extrabold text-gold-300">٦</div>
              <div className="text-[10px] font-medium text-brand-100">أقسام</div>
            </div>
            <div className="rounded-xl bg-white/10 px-3 py-2 text-center backdrop-blur-sm">
              <div className="text-lg font-extrabold text-gold-300">١١٤</div>
              <div className="text-[10px] font-medium text-brand-100">سورة</div>
            </div>
            <div className="rounded-xl bg-white/10 px-3 py-2 text-center backdrop-blur-sm">
              <div className="text-lg font-extrabold text-gold-300">٥</div>
              <div className="text-[10px] font-medium text-brand-100">صلوات</div>
            </div>
          </div>
        </div>
      </div>

      {/* عنوان الأقسام */}
      <div className="mt-6 mb-3 flex items-center justify-between">
        <h3 className="text-base font-extrabold text-brand-900">
          أقسام التطبيق
        </h3>
        <span className="text-xs font-medium text-brand-600">
          اختر قسماً للبدء
        </span>
      </div>

      {/* شبكة البطاقات - 6 أقسام رئيسية فقط */}
      <div className="grid grid-cols-2 gap-3">
        {sections
          .filter((section) =>
            ["quran", "reciters", "azkar", "prayer", "tasbih", "adhan"].includes(
              section.id
            )
          )
          .map((section) => (
            <Link
              key={section.id}
              to={section.path}
              className="tap-highlight group relative overflow-hidden rounded-2xl border border-brand-100 bg-white p-4 shadow-sm transition-shadow hover:shadow-md"
            >
              {/* شارة ملونة علوية */}
              <div
                className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-l ${section.accent}`}
                aria-hidden
              />

              <div
                className={`mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl ${section.iconBg}`}
              >
                {section.icon}
              </div>

              <h4 className="text-sm font-extrabold text-brand-900 leading-tight">
                {section.title}
              </h4>
            <p className="mt-1 text-[11px] font-medium leading-snug text-slate-500">
              {section.subtitle}
            </p>

            {/* سهم صغير */}
            <div className="mt-3 flex items-center gap-1 text-[10px] font-bold text-brand-700">
              <span>فتح</span>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M15 6l-6 6 6 6" />
              </svg>
            </div>
          </Link>
        ))}
      </div>

      {/* زر عرض المزيد */}
      <Link
        to="/menu"
        className="tap-highlight mt-4 flex items-center justify-center gap-2 rounded-2xl border-2 border-brand-200 bg-white p-4 shadow-sm transition-all hover:border-brand-300 hover:shadow-md"
      >
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="6" cy="6" r="1.5" fill="currentColor" />
            <circle cx="12" cy="6" r="1.5" fill="currentColor" />
            <circle cx="18" cy="6" r="1.5" fill="currentColor" />
            <circle cx="6" cy="12" r="1.5" fill="currentColor" />
            <circle cx="12" cy="12" r="1.5" fill="currentColor" />
            <circle cx="18" cy="12" r="1.5" fill="currentColor" />
            <circle cx="6" cy="18" r="1.5" fill="currentColor" />
            <circle cx="12" cy="18" r="1.5" fill="currentColor" />
            <circle cx="18" cy="18" r="1.5" fill="currentColor" />
          </svg>
        </div>
        <div className="flex-1 text-right">
          <p className="text-sm font-extrabold text-brand-900">عرض المزيد</p>
          <p className="text-[11px] font-medium text-slate-500">
            جميع الأقسام والإعدادات
          </p>
        </div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="text-brand-700">
          <path d="M15 6l-6 6 6 6" />
        </svg>
      </Link>

      {/* فوتر صغير */}
      <div className="mt-6 rounded-2xl border border-brand-100 bg-white/70 p-4 text-center">
        <p className="font-amiri text-base font-bold text-brand-800">
          «وَنُنَزِّلُ مِنَ الْقُرْآنِ مَا هُوَ شِفَاءٌ وَرَحْمَةٌ لِّلْمُؤْمِنِينَ»
        </p>
        <p className="mt-1 text-[11px] font-medium text-slate-500">
          سورة الإسراء - آية ٨٢
        </p>
      </div>

      <p className="mt-4 text-center text-[11px] text-slate-400">
        نور القرآن · الإصدار ١٫٠
      </p>
    </div>
  );
}
