import { Link } from "react-router-dom";
import { RECITERS } from "@/data/reciters";

/**
 * صفحة قائمة القراء.
 * عند اختيار قارئ، ينتقل إلى صفحة اختيار السورة.
 */
export default function RecitersList() {
  return (
    <div className="px-4 pt-4 pb-4">
      {/* بطاقة تعريفية */}
      <div className="mb-4 overflow-hidden rounded-2xl border border-gold-200 bg-gradient-to-l from-gold-50 to-white p-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-gold-400 to-gold-600 text-brand-900 shadow-sm">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
              <path d="M19 10v1a7 7 0 0 1-14 0v-1M12 18v4M8 22h8" />
            </svg>
          </div>
          <div>
            <h2 className="text-base font-extrabold text-brand-900">
              القراء والتلاوات
            </h2>
            <p className="mt-0.5 text-xs text-slate-500">
              اختر قارئاً للاستماع إلى تلاواته
            </p>
          </div>
        </div>
      </div>

      {/* قائمة القراء */}
      <ul className="space-y-2.5">
        {RECITERS.map((reciter) => (
          <li key={reciter.id}>
            <Link
              to={`/reciters/${reciter.id}`}
              className="tap-highlight group flex items-center gap-3 rounded-2xl border border-brand-100 bg-white p-3.5 shadow-sm hover:border-brand-300 hover:shadow-md"
            >
              {/* صورة/رمز القارئ */}
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-brand-700 to-brand-900 text-gold-300 shadow-md">
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 2a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
                  <path d="M19 10v1a7 7 0 0 1-14 0v-1" />
                </svg>
              </div>

              {/* معلومات القارئ */}
              <div className="min-w-0 flex-1">
                <h3 className="truncate text-sm font-extrabold text-brand-900">
                  {reciter.shortName}
                </h3>
                <p className="mt-0.5 truncate text-[11px] font-medium text-slate-500">
                  {reciter.nameAr}
                </p>
                <div className="mt-1 flex items-center gap-2 text-[10px]">
                  <span className="rounded-full bg-brand-50 px-2 py-0.5 font-bold text-brand-700">
                    {reciter.country}
                  </span>
                  <span className="rounded-full bg-gold-50 px-2 py-0.5 font-bold text-gold-700">
                    {reciter.style}
                  </span>
                  {reciter.complete && (
                    <span className="rounded-full bg-emerald-50 px-2 py-0.5 font-bold text-emerald-700">
                      كامل
                    </span>
                  )}
                </div>
              </div>

              {/* سهم */}
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 text-brand-400">
                <path d="M15 6l-6 6 6 6" />
              </svg>
            </Link>
          </li>
        ))}
      </ul>

      {/* فوتر */}
      <div className="mt-6 rounded-2xl border border-brand-100 bg-white/70 p-4 text-center">
        <p className="text-xs text-slate-500">
          المصادر: cdn.islamic.network · mp3quran.net · تلاوات كاملة بجودة عالية
        </p>
        <p className="mt-1 text-[11px] text-slate-400">
          {RECITERS.length} قارئ متاح · ١١٤ سورة لكل قارئ
        </p>
      </div>
    </div>
  );
}
