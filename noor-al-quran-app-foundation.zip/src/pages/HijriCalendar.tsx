import { useState, useEffect } from "react";
import {
  getAdjustedHijriDate,
  getIslamicEvents,
  getUpcomingEvents,
  saveHijriOffset,
  getHijriOffset,
  hijriToGregorian,
  type HijriDate,
  type IslamicEvent,
} from "@/services/hijriApi";

export default function HijriCalendar() {
  const [today, setToday] = useState(new Date());
  const [hijriDate, setHijriDate] = useState<HijriDate | null>(null);
  const [events, setEvents] = useState<IslamicEvent[]>([]);
  const [upcomingEvents, setUpcomingEvents] = useState<IslamicEvent[]>([]);
  const [hijriOffset, setHijriOffset] = useState(getHijriOffset());

  useEffect(() => {
    updateDate();
    setEvents(getIslamicEvents());
    setUpcomingEvents(getUpcomingEvents(today, 5));
  }, [today, hijriOffset]);

  const updateDate = () => {
    setHijriDate(getAdjustedHijriDate(today));
  };

  const handleOffsetChange = (newOffset: number) => {
    setHijriOffset(newOffset);
    saveHijriOffset(newOffset);
    updateDate();
  };

  const goToToday = () => {
    const now = new Date();
    setToday(now);
    setHijriOffset(0);
    saveHijriOffset(0);
  };

  if (!hijriDate) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-emerald-200 border-t-emerald-600" />
          <p className="mt-4 text-slate-600">جاري تحميل التقويم...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* الرأس */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-indigo-700 dark:text-indigo-400 mb-2">
            التقويم الهجري
          </h1>
          <p className="text-slate-600 dark:text-slate-300">
            التاريخ الهجري والمناسبات الإسلامية
          </p>
        </div>

        {/* التاريخ الحالي */}
        <div className="mb-6 p-6 bg-gradient-to-br from-indigo-600 to-indigo-700 text-white rounded-2xl shadow-lg">
          <div className="text-center">
            <p className="text-indigo-200 mb-2">التاريخ الهجري</p>
            <h2 className="text-4xl font-bold mb-2">
              {hijriDate.day} {hijriDate.monthNameAr} {hijriDate.year} هـ
            </h2>
            <p className="text-indigo-200 mb-4">
              {hijriDate.dayOfWeekAr}
            </p>
            <div className="inline-flex gap-4 text-sm text-indigo-200">
              <span>
                {today.toLocaleDateString("ar-SA", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </span>
            </div>
          </div>

          {/* أزرار التحكم */}
          <div className="flex gap-2 mt-4">
            <button
              onClick={() => handleOffsetChange(hijriOffset - 1)}
              className="flex-1 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors text-sm"
            >
              اليوم السابق
            </button>
            <button
              onClick={goToToday}
              className="flex-1 px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors text-sm font-medium"
            >
              اليوم
            </button>
            <button
              onClick={() => handleOffsetChange(hijriOffset + 1)}
              className="flex-1 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors text-sm"
            >
              اليوم التالي
            </button>
          </div>
        </div>

        {/* تعديل فرق اليوم */}
        <div className="mb-6 p-4 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-indigo-100 dark:border-slate-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-slate-900 dark:text-white">تعديل فرق اليوم</p>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                استخدم هذا لضبط التاريخ إذا كان يختلف عن التقويم المحلي
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleOffsetChange(hijriOffset - 1)}
                className="w-8 h-8 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 rounded-lg transition-colors flex items-center justify-center"
              >
                -
              </button>
              <span className="w-12 text-center font-bold text-slate-900 dark:text-white">
                {hijriOffset}
              </span>
              <button
                onClick={() => handleOffsetChange(hijriOffset + 1)}
                className="w-8 h-8 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 rounded-lg transition-colors flex items-center justify-center"
              >
                +
              </button>
            </div>
          </div>
        </div>

        {/* المناسبات القادمة */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-indigo-700 dark:text-indigo-400 mb-4">
            المناسبات القادمة
          </h2>
          {upcomingEvents.length === 0 ? (
            <div className="p-6 bg-white dark:bg-slate-800 rounded-xl shadow-sm text-center">
              <p className="text-slate-600 dark:text-slate-400">
                لا توجد مناسبات قادمة
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {upcomingEvents.map((event) => {
                const [day, month] = event.hijriDate.split("-").map(Number);
                const eventHijri = { ...hijriDate, day, month };
                const eventGregorian = hijriToGregorian(
                  eventHijri.year,
                  eventHijri.month,
                  eventHijri.day
                );

                return (
                  <div
                    key={event.id}
                    className={`p-4 rounded-xl shadow-sm border ${
                      event.type === "major"
                        ? "bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800"
                        : "bg-white dark:bg-slate-800 border-indigo-100 dark:border-slate-700"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3
                          className={`font-bold mb-1 ${
                            event.type === "major"
                              ? "text-emerald-700 dark:text-emerald-400"
                              : "text-slate-900 dark:text-white"
                          }`}
                        >
                          {event.nameAr}
                        </h3>
                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">
                          {event.descriptionAr}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-500">
                          {day} {hijriDate.monthNameAr} {hijriDate.year} هـ •{" "}
                          {eventGregorian.toLocaleDateString("ar-SA", {
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </p>
                      </div>
                      <span
                        className={`px-2 py-1 rounded-full text-xs font-medium ${
                          event.type === "major"
                            ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"
                            : "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400"
                        }`}
                      >
                        {event.type === "major" ? "رئيسية" : "ثانوية"}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* جميع المناسبات */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-indigo-700 dark:text-indigo-400 mb-4">
            جميع المناسبات الإسلامية
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {events.map((event) => (
              <div
                key={event.id}
                className="p-4 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-indigo-100 dark:border-slate-700"
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-bold text-slate-900 dark:text-white">
                    {event.nameAr}
                  </h3>
                  <span
                    className={`px-2 py-1 rounded-full text-xs font-medium ${
                      event.type === "major"
                        ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"
                        : event.type === "minor"
                        ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400"
                        : "bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-400"
                    }`}
                  >
                    {event.type === "major"
                      ? "رئيسية"
                      : event.type === "minor"
                      ? "ثانوية"
                      : "اختيارية"}
                  </span>
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                  {event.descriptionAr}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-500">
                  {event.hijriDate.split("-")[0]}{" "}
                  {HIJRI_MONTHS_AR[parseInt(event.hijriDate.split("-")[1]) - 1]}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* معلومات */}
        <div className="mt-6 p-4 bg-amber-50 dark:bg-amber-900/20 rounded-xl border border-amber-200 dark:border-amber-800">
          <h3 className="font-semibold text-amber-700 dark:text-amber-400 mb-2">
            📅 ملاحظات مهمة
          </h3>
          <ul className="space-y-1 text-sm text-amber-600 dark:text-amber-300">
            <li>• التواريخ الهجرية حسابية وقد تختلف عن الرؤية الشرعية</li>
            <li>• بعض المناسبات مثل ليلة القدر لها تواريخ تقديرية</li>
            <li>• استخدم تعديل فرق اليوم لمطابقة التقويم المحلي</li>
            <li>• التواريخ المؤكدة تعتمد على الرؤية الشرعية في بلدك</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

const HIJRI_MONTHS_AR = [
  "محرم",
  "صفر",
  "ربيع الأول",
  "ربيع الآخر",
  "جمادى الأولى",
  "جمادى الآخرة",
  "رجب",
  "شعبان",
  "رمضان",
  "شوال",
  "ذو القعدة",
  "ذو الحجة",
];
