import { useState, useEffect } from "react";
import {
  calculateQiblaDirection,
  getCurrentLocation,
  saveQiblaLocation,
  getSavedQiblaLocation,
  POPULAR_CITIES,
  getCompassDirection,
  type QiblaResult,
  type SavedLocation,
} from "@/services/qiblaApi";

export default function Qibla() {
  const [qiblaData, setQiblaData] = useState<QiblaResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [showCitySelector, setShowCitySelector] = useState(false);
  const [deviceOrientation, setDeviceOrientation] = useState<number | null>(null);

  useEffect(() => {
    initializeQibla();
    setupDeviceOrientation();

    return () => {
      window.removeEventListener("deviceorientation", handleOrientation);
    };
  }, []);

  const initializeQibla = async () => {
    try {
      setLoading(true);

      // التحقق من الموقع المحفوظ
      const savedLocation = getSavedQiblaLocation();

      if (savedLocation) {
        const result = calculateQiblaDirection(
          savedLocation.latitude,
          savedLocation.longitude
        );
        setQiblaData({ ...result, locationName: savedLocation.name });
      } else {
        // طلب الموقع الحالي
        await requestLocation();
      }
    } catch (e: any) {
      setShowCitySelector(true);
    } finally {
      setLoading(false);
    }
  };

  const requestLocation = async () => {
    try {
      const position = await getCurrentLocation();
      const result = calculateQiblaDirection(
        position.coords.latitude,
        position.coords.longitude
      );
      setQiblaData(result);

      // حفظ الموقع
      saveQiblaLocation({
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        name: "موقعك الحالي",
      });
    } catch (e: any) {
      setShowCitySelector(true);
    }
  };

  const setupDeviceOrientation = () => {
    if (typeof DeviceOrientationEvent !== "undefined") {
      // طلب الإذن على iOS 13+
      if (typeof (DeviceOrientationEvent as any).requestPermission === "function") {
        // سيتم طلب الإذن عند الضغط على زر
      } else {
        window.addEventListener("deviceorientation", handleOrientation);
      }
    }
  };

  const handleOrientation = (event: DeviceOrientationEvent) => {
    if (event.alpha !== null) {
      setDeviceOrientation(event.alpha);
    }
  };

  const requestOrientationPermission = async () => {
    if (typeof (DeviceOrientationEvent as any).requestPermission === "function") {
      try {
        const permission = await (DeviceOrientationEvent as any).requestPermission();
        if (permission === "granted") {
          window.addEventListener("deviceorientation", handleOrientation);
        }
      } catch (e) {
        console.error("فشل طلب إذن البوصلة:", e);
      }
    }
  };

  const selectCity = (city: SavedLocation) => {
    const result = calculateQiblaDirection(city.latitude, city.longitude);
    setQiblaData({ ...result, locationName: city.name });
    saveQiblaLocation(city);
    setShowCitySelector(false);
  };

  const getCompassRotation = () => {
    if (!qiblaData || deviceOrientation === null) return 0;
    
    // حساب الدوران النسبي
    const qiblaDirection = qiblaData.direction;
    const rotation = qiblaDirection - deviceOrientation;
    
    return (rotation + 360) % 360;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-teal-50 to-white dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* الرأس */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-teal-700 dark:text-teal-400 mb-2">
            اتجاه القبلة
          </h1>
          <p className="text-slate-600 dark:text-slate-300">
            حدد اتجاه القبلة من موقعك الحالي
          </p>
        </div>

        {/* تنبيه المعايرة */}
        <div className="mb-6 p-4 bg-amber-50 dark:bg-amber-900/20 rounded-xl border border-amber-200 dark:border-amber-800">
          <div className="flex items-start gap-3">
            <svg
              className="shrink-0 mt-0.5 text-amber-600 dark:text-amber-400"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
            <div>
              <p className="font-semibold text-amber-700 dark:text-amber-400 mb-1">
                معايرة البوصلة
              </p>
              <p className="text-sm text-amber-600 dark:text-amber-300">
                للحصول على دقة أفضل، قم بتحريك هاتفك على شكل رقم 8 عدة مرات لمعايرة البوصلة.
                قد تتأثر الدقة بالمعادن والأجهزة الإلكترونية القريبة.
              </p>
            </div>
          </div>
        </div>

        {/* حالة التحميل */}
        {loading && (
          <div className="text-center py-12">
            <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-teal-200 border-t-teal-600" />
            <p className="mt-4 text-slate-600 dark:text-slate-400">جاري تحديد الموقع...</p>
          </div>
        )}

        {/* عرض القبلة */}
        {qiblaData && !loading && (
          <>
            {/* معلومات الموقع */}
            <div className="mb-6 p-4 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-teal-100 dark:border-slate-700">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">الموقع</p>
                  <p className="text-lg font-semibold text-slate-900 dark:text-white">
                    {qiblaData.locationName}
                  </p>
                </div>
                <button
                  onClick={() => setShowCitySelector(true)}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg transition-colors text-sm"
                >
                  تغيير
                </button>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-3">
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-500">المسافة إلى مكة</p>
                  <p className="text-lg font-bold text-teal-600 dark:text-teal-400">
                    {Math.round(qiblaData.distance)} كم
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-500">الاتجاه</p>
                  <p className="text-lg font-bold text-teal-600 dark:text-teal-400">
                    {Math.round(qiblaData.direction)}° {getCompassDirection(qiblaData.direction)}
                  </p>
                </div>
              </div>
            </div>

            {/* البوصلة */}
            <div className="mb-6 flex justify-center">
              <div className="relative w-80 h-80">
                {/* البوصلة الدائرية */}
                <div className="absolute inset-0 rounded-full bg-white dark:bg-slate-800 shadow-xl border-4 border-teal-200 dark:border-slate-700">
                  {/* علامات البوصلة */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-full h-full relative">
                      {/* الشمال */}
                      <div className="absolute top-4 left-1/2 -translate-x-1/2 text-red-600 dark:text-red-400 font-bold text-lg">
                        ش
                      </div>
                      {/* الشرق */}
                      <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-600 dark:text-slate-400 font-bold text-lg">
                        ش
                      </div>
                      {/* الجنوب */}
                      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-slate-600 dark:text-slate-400 font-bold text-lg">
                        ج
                      </div>
                      {/* الغرب */}
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 dark:text-slate-400 font-bold text-lg">
                        غ
                      </div>
                    </div>
                  </div>

                  {/* مؤشر القبلة */}
                  <div
                    className="absolute inset-0 flex items-center justify-center transition-transform duration-300"
                    style={{
                      transform: `rotate(${getCompassRotation()}deg)`,
                    }}
                  >
                    <div className="relative w-full h-full">
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-full w-1 h-32 bg-gradient-to-b from-emerald-600 to-emerald-400 origin-bottom" />
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-full -mt-4">
                        <svg
                          width="32"
                          height="32"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-emerald-600 dark:text-emerald-400"
                        >
                          <path d="M12 2 L8 12 L12 10 L16 12 Z" fill="currentColor" />
                        </svg>
                      </div>
                    </div>
                  </div>

                  {/* علامة الكعبة */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                    <div className="w-16 h-16 bg-emerald-600 dark:bg-emerald-500 rounded-full flex items-center justify-center shadow-lg">
                      <svg
                        width="32"
                        height="32"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="white"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <rect x="4" y="4" width="16" height="16" rx="2" />
                        <path d="M9 9h6M9 12h6M9 15h6" />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* تعليمات */}
            <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-200 dark:border-blue-800">
              <h3 className="font-semibold text-blue-700 dark:text-blue-400 mb-2">
                📱 كيفية الاستخدام
              </h3>
              <ul className="space-y-1 text-sm text-blue-600 dark:text-blue-300">
                <li>• أمسك هاتفك بشكل مسطح وموازٍ للأرض</li>
                <li>• وجّه السهم الأخضر نحو الكعبة المشرفة</li>
                <li>• إذا كان السهم يشير للأعلى، فأنت تواجه القبلة</li>
                <li>• حرّك الهاتف ببطء لضبط الاتجاه</li>
              </ul>
            </div>

            {/* زر طلب إذن البوصلة */}
            {deviceOrientation === null && (
              <button
                onClick={requestOrientationPermission}
                className="w-full mb-6 p-4 bg-teal-600 hover:bg-teal-700 text-white rounded-xl shadow-md transition-colors"
              >
                تفعيل البوصلة التفاعلية
              </button>
            )}
          </>
        )}

        {/* اختيار المدينة */}
        {showCitySelector && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
            <div className="bg-white dark:bg-slate-800 rounded-2xl max-w-md w-full max-h-[80vh] overflow-hidden shadow-2xl">
              <div className="p-5 border-b border-slate-200 dark:border-slate-700">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                    اختر المدينة
                  </h2>
                  <button
                    onClick={() => setShowCitySelector(false)}
                    className="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M18 6 6 18" />
                      <path d="m6 6 12 12" />
                    </svg>
                  </button>
                </div>
              </div>
              <div className="p-3 overflow-y-auto max-h-[60vh]">
                <div className="space-y-2">
                  {POPULAR_CITIES.map((city) => (
                    <button
                      key={`${city.latitude}-${city.longitude}`}
                      onClick={() => selectCity(city)}
                      className="w-full p-4 text-right bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg hover:border-teal-400 hover:bg-teal-50 dark:hover:bg-teal-900/20 transition-all"
                    >
                      <p className="font-bold text-slate-900 dark:text-white">{city.name}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* معلومات */}
        <div className="mt-6 p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
          <h3 className="font-semibold text-slate-700 dark:text-slate-400 mb-2">
            ℹ️ معلومات مهمة
          </h3>
          <ul className="space-y-1 text-sm text-slate-600 dark:text-slate-400">
            <li>• يتم حساب الاتجاه باستخدام معادلات المجال العظيم</li>
            <li>• الدقة تعتمد على جودة بوصلة الهاتف</li>
            <li>• قد تختلف القراءة في الأماكن المغلقة</li>
            <li>• استخدم هذه الأداة كدليل وليس كمرجع وحيد</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
