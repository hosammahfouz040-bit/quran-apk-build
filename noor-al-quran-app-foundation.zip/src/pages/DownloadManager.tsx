import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  getDownloadedFiles,
  deleteDownloadedFile,
  deleteAllDownloadedFiles,
  getTotalDownloadedSize,
  formatFileSize,
  type DownloadedFile,
} from "@/services/downloadManagerApi";
import { SURAH_SIMPLE_NAMES } from "@/services/quranApi";

export default function DownloadManager() {
  const navigate = useNavigate();
  const [files, setFiles] = useState<DownloadedFile[]>([]);
  const [totalSize, setTotalSize] = useState(0);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    loadFiles();
  }, []);

  const loadFiles = () => {
    const downloadedFiles = getDownloadedFiles();
    setFiles(downloadedFiles);
    setTotalSize(getTotalDownloadedSize());
  };

  const handleDeleteFile = (reciterId: string, surahNumber: number) => {
    if (confirm("هل أنت متأكد من حذف هذا الملف؟")) {
      deleteDownloadedFile(reciterId, surahNumber);
      loadFiles();
    }
  };

  const handleDeleteAll = () => {
    if (confirm("هل أنت متأكد من حذف جميع الملفات المحملة؟")) {
      deleteAllDownloadedFiles();
      loadFiles();
      setShowDeleteConfirm(false);
    }
  };

  const filesByReciter = files.reduce((acc, file) => {
    if (!acc[file.reciterId]) {
      acc[file.reciterId] = {
        reciterName: file.reciterName,
        files: [],
      };
    }
    acc[file.reciterId].files.push(file);
    return acc;
  }, {} as Record<string, { reciterName: string; files: DownloadedFile[] }>);

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* الرأس */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-orange-700 dark:text-orange-400 mb-2">
            إدارة التنزيلات
          </h1>
          <p className="text-slate-600 dark:text-slate-300">
            إدارة الملفات الصوتية المحملة للاستخدام دون إنترنت
          </p>
        </div>

        {/* إحصائيات */}
        <div className="mb-6 grid grid-cols-2 gap-4">
          <div className="p-4 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-orange-100 dark:border-slate-700">
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">
              الملفات المحملة
            </p>
            <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">
              {files.length}
            </p>
          </div>
          <div className="p-4 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-orange-100 dark:border-slate-700">
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">
              الحجم الإجمالي
            </p>
            <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">
              {formatFileSize(totalSize)}
            </p>
          </div>
        </div>

        {/* زر حذف الكل */}
        {files.length > 0 && (
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="w-full mb-6 p-4 bg-red-600 hover:bg-red-700 text-white rounded-xl shadow-md transition-colors"
          >
            حذف جميع الملفات
          </button>
        )}

        {/* قائمة الملفات */}
        {files.length === 0 ? (
          <div className="p-12 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-orange-100 dark:border-slate-700 text-center">
            <svg
              className="mx-auto mb-4 text-slate-400"
              width="64"
              height="64"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="7 10 12 15 17 10" />
              <line x1="12" y1="15" x2="12" y2="3" />
            </svg>
            <p className="text-slate-600 dark:text-slate-400 mb-4">
              لا توجد ملفات محملة
            </p>
            <p className="text-sm text-slate-500 dark:text-slate-500 mb-4">
              قم بتحميل التلاوات من صفحة القراء للاستماع إليها دون إنترنت
            </p>
            <button
              onClick={() => navigate("/reciters")}
              className="px-6 py-3 bg-orange-600 hover:bg-orange-700 text-white rounded-lg transition-colors"
            >
              الذهاب إلى القراء
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(filesByReciter).map(([reciterId, data]) => (
              <div
                key={reciterId}
                className="p-4 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-orange-100 dark:border-slate-700"
              >
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-slate-900 dark:text-white">
                    {data.reciterName}
                  </h3>
                  <span className="text-xs text-slate-500 dark:text-slate-500">
                    {data.files.length} ملف •{" "}
                    {formatFileSize(
                      data.files.reduce((sum, f) => sum + f.size, 0)
                    )}
                  </span>
                </div>

                <div className="space-y-2">
                  {data.files.map((file) => (
                    <div
                      key={file.id}
                      className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-700 rounded-lg"
                    >
                      <div className="flex-1">
                        <p className="font-medium text-slate-900 dark:text-white">
                          سورة {SURAH_SIMPLE_NAMES[file.surahNumber] || file.surahNumber}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-500">
                          {formatFileSize(file.size)} •{" "}
                          {new Date(file.downloadedAt).toLocaleDateString("ar-SA")}
                        </p>
                      </div>
                      <button
                        onClick={() =>
                          handleDeleteFile(file.reciterId, file.surahNumber)
                        }
                        className="p-2 bg-red-100 hover:bg-red-200 dark:bg-red-900/30 dark:hover:bg-red-900/50 text-red-600 dark:text-red-400 rounded-lg transition-colors"
                      >
                        <svg
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <polyline points="3 6 5 6 21 6" />
                          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                        </svg>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* معلومات */}
        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-200 dark:border-blue-800">
          <h3 className="font-semibold text-blue-700 dark:text-blue-400 mb-2">
            💡 معلومات مهمة
          </h3>
          <ul className="space-y-1 text-sm text-blue-600 dark:text-blue-300">
            <li>• الملفات المحملة متاحة للاستماع دون إنترنت</li>
            <li>• يمكنك حذف أي ملف في أي وقت لتحرير المساحة</li>
            <li>• الملفات تُحفظ محلياً على جهازك</li>
            <li>• تأكد من وجود مساحة كافية قبل التحميل</li>
          </ul>
        </div>
      </div>

      {/* نافذة تأكيد الحذف */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white dark:bg-slate-800 rounded-2xl max-w-sm w-full p-6 shadow-2xl">
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-4">
              تأكيد الحذف
            </h2>
            <p className="text-slate-600 dark:text-slate-400 mb-6">
              هل أنت متأكد من حذف جميع الملفات المحملة؟ لا يمكن التراجع عن هذا
              الإجراء.
            </p>
            <div className="flex gap-2">
              <button
                onClick={handleDeleteAll}
                className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
              >
                حذف الكل
              </button>
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 px-4 py-3 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 rounded-lg transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
