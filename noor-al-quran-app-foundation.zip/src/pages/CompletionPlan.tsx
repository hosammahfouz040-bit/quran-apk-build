import { useState, useEffect } from "react";
import {
  getCompletionPlans,
  createCompletionPlan,
  deleteCompletionPlan,
  updateCurrentPage,
  togglePlanStatus,
  calculateCompletionProgress,
  getRemainingPages,
  getRemainingDays,
  getPageSurah,
  type CompletionPlan,
} from "@/services/completionPlanApi";

export default function CompletionPlanPage() {
  const [plans, setPlans] = useState<CompletionPlan[]>([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newPlanName, setNewPlanName] = useState("");
  const [newPlanDuration, setNewPlanDuration] = useState(30);

  useEffect(() => {
    loadPlans();
  }, []);

  const loadPlans = () => {
    const savedPlans = getCompletionPlans();
    setPlans(savedPlans);
  };

  const handleCreatePlan = () => {
    if (!newPlanName.trim()) {
      alert("يرجى إدخال اسم الخطة");
      return;
    }

    if (newPlanDuration < 1 || newPlanDuration > 365) {
      alert("المدة يجب أن تكون بين 1 و 365 يوم");
      return;
    }

    const plan = createCompletionPlan(newPlanName, newPlanDuration);
    setPlans([...plans, plan]);
    setNewPlanName("");
    setNewPlanDuration(30);
    setShowCreateForm(false);
  };

  const handleDeletePlan = (planId: string) => {
    if (confirm("هل أنت متأكد من حذف هذه الخطة؟")) {
      deleteCompletionPlan(planId);
      setPlans(plans.filter((p) => p.id !== planId));
    }
  };

  const handleIncrementPage = (planId: string, current: number) => {
    updateCurrentPage(planId, current + 1);
    loadPlans();
  };

  const handleToggleStatus = (planId: string) => {
    togglePlanStatus(planId);
    loadPlans();
  };

  const getSurahForPage = (pageNumber: number) => {
    const { surahName } = getPageSurah(pageNumber);
    return surahName;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* الرأس */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-purple-700 dark:text-purple-400 mb-2">
            خطة ختم القرآن
          </h1>
          <p className="text-slate-600 dark:text-slate-300">
            نظم وقتك لختم القرآن الكريم في المدة التي تناسبك
          </p>
        </div>

        {/* زر إنشاء خطة جديدة */}
        {!showCreateForm && (
          <button
            onClick={() => setShowCreateForm(true)}
            className="w-full mb-6 p-4 bg-purple-600 hover:bg-purple-700 text-white rounded-xl shadow-md transition-colors flex items-center justify-center gap-2"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <line x1="12" y1="5" x2="12" y2="19" />
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
            إنشاء خطة ختم جديدة
          </button>
        )}

        {/* نموذج إنشاء خطة */}
        {showCreateForm && (
          <div className="mb-6 p-6 bg-white dark:bg-slate-800 rounded-xl shadow-md border border-purple-100 dark:border-slate-700">
            <h2 className="text-xl font-bold text-purple-700 dark:text-purple-400 mb-4">
              خطة ختم جديدة
            </h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  اسم الخطة
                </label>
                <input
                  type="text"
                  value={newPlanName}
                  onChange={(e) => setNewPlanName(e.target.value)}
                  placeholder="مثال: ختمة رمضان"
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-slate-900 dark:text-white placeholder-slate-400"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  مدة الختمة (أيام)
                </label>
                <div className="grid grid-cols-4 gap-2 mb-2">
                  {[7, 15, 30, 60].map((days) => (
                    <button
                      key={days}
                      onClick={() => setNewPlanDuration(days)}
                      className={`p-2 rounded-lg text-sm transition-colors ${
                        newPlanDuration === days
                          ? "bg-purple-600 text-white"
                          : "bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600"
                      }`}
                    >
                      {days} يوم
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  min="1"
                  max="365"
                  value={newPlanDuration}
                  onChange={(e) => setNewPlanDuration(parseInt(e.target.value))}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-slate-900 dark:text-white"
                />
              </div>

              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <p className="text-sm text-blue-700 dark:text-blue-400">
                  💡 ستقرأ حوالي{" "}
                  <span className="font-bold">
                    {Math.ceil(604 / newPlanDuration)} صفحة يومياً
                  </span>
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleCreatePlan}
                  className="flex-1 px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
                >
                  إنشاء الخطة
                </button>
                <button
                  onClick={() => setShowCreateForm(false)}
                  className="px-4 py-3 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 rounded-lg transition-colors"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        )}

        {/* قائمة الخطط */}
        {plans.length === 0 ? (
          <div className="p-12 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-purple-100 dark:border-slate-700 text-center">
            <svg
              className="mx-auto mb-4 text-slate-400"
              width="64"
              height="64"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
              <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
            </svg>
            <p className="text-slate-600 dark:text-slate-400 mb-4">
              لا توجد خطط ختم بعد
            </p>
            <p className="text-sm text-slate-500 dark:text-slate-500">
              ابدأ بإنشاء خطة ختم جديدة لتنظيم قراءتك للقرآن الكريم
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {plans.map((plan) => {
              const progress = calculateCompletionProgress(plan);
              const remainingPages = getRemainingPages(plan);
              const remainingDays = getRemainingDays(plan);
              const currentSurah = getSurahForPage(plan.currentPage + 1);

              return (
                <div
                  key={plan.id}
                  className="p-6 bg-white dark:bg-slate-800 rounded-xl shadow-md border border-purple-100 dark:border-slate-700 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-xl font-bold text-purple-700 dark:text-purple-400">
                          {plan.name}
                        </h3>
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium ${
                            plan.status === "completed"
                              ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                              : plan.status === "paused"
                              ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400"
                              : "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
                          }`}
                        >
                          {plan.status === "completed"
                            ? "مكتملة"
                            : plan.status === "paused"
                            ? "متوقفة"
                            : "نشطة"}
                        </span>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">
                        بدأت في: {new Date(plan.startDate).toLocaleDateString("ar-SA")}
                      </p>
                      {plan.status !== "completed" && (
                        <>
                          <p className="text-sm text-slate-600 dark:text-slate-400">
                            الورد اليومي: {plan.dailyPages} صفحة
                          </p>
                          <p className="text-sm text-purple-600 dark:text-purple-400 font-medium">
                            تقرأ الآن: {currentSurah} (صفحة {plan.currentPage + 1})
                          </p>
                        </>
                      )}
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">
                        {progress}%
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-500">الإنجاز</p>
                    </div>
                  </div>

                  {/* شريط التقدم */}
                  <div className="mb-4">
                    <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-3 overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-purple-500 to-purple-600 h-full rounded-full transition-all duration-500"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                    <div className="flex justify-between mt-2 text-xs text-slate-600 dark:text-slate-400">
                      <span>صفحة {plan.currentPage} من {plan.totalPages}</span>
                      {plan.status !== "completed" && (
                        <span>
                          متبقي: {remainingPages} صفحة • {remainingDays} يوم
                        </span>
                      )}
                    </div>
                  </div>

                  {/* الأزرار */}
                  <div className="flex gap-2">
                    {plan.status !== "completed" && (
                      <>
                        <button
                          onClick={() => handleIncrementPage(plan.id, plan.currentPage)}
                          className="flex-1 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors text-sm"
                        >
                          قرأت صفحة
                        </button>
                        <button
                          onClick={() => handleToggleStatus(plan.id)}
                          className="px-4 py-2 bg-amber-100 hover:bg-amber-200 dark:bg-amber-900/30 dark:hover:bg-amber-900/50 text-amber-600 dark:text-amber-400 rounded-lg transition-colors text-sm"
                        >
                          {plan.status === "paused" ? "استئناف" : "إيقاف"}
                        </button>
                      </>
                    )}
                    <button
                      onClick={() => handleDeletePlan(plan.id)}
                      className="px-4 py-2 bg-red-100 hover:bg-red-200 dark:bg-red-900/30 dark:hover:bg-red-900/50 text-red-600 dark:text-red-400 rounded-lg transition-colors text-sm"
                    >
                      حذف
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* معلومات */}
        <div className="mt-6 p-4 bg-amber-50 dark:bg-amber-900/20 rounded-xl border border-amber-200 dark:border-amber-800">
          <h3 className="font-semibold text-amber-700 dark:text-amber-400 mb-2">
            📖 معلومات مفيدة
          </h3>
          <ul className="space-y-1 text-sm text-amber-600 dark:text-amber-300">
            <li>• المصحف المدني يتكون من 604 صفحة</li>
            <li>• لختم القرآن في 30 يوم، اقرأ 20 صفحة يومياً</li>
            <li>• لختم القرآن في 15 يوم، اقرأ 40 صفحة يومياً</li>
            <li>• يمكنك إيقاف الخطة واستئنافها في أي وقت</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
