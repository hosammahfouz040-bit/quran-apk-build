import { Link } from "react-router-dom";
import { sections } from "@/data/sections";
import { icons } from "@/data/sections";

/**
 * صفحة "المزيد" - قائمة شاملة بجميع الأقسام.
 * تظهر عند الضغط على زر "المزيد" في شريط التنقل.
 */
export default function Menu() {
  return (
    <div className="px-4 pt-5 pb-4">
      <div className="mb-4 rounded-2xl bg-white p-4 shadow-sm border border-brand-100">
        <h2 className="text-lg font-extrabold text-brand-900">جميع الأقسام</h2>
        <p className="mt-0.5 text-xs text-slate-500">
          تصفّح جميع أقسام تطبيق نور القرآن
        </p>
      </div>

      <ul className="space-y-2.5">
        {sections.map((section) => (
          <li key={section.id}>
            <Link
              to={section.path}
              className="tap-highlight flex items-center gap-3 rounded-2xl border border-brand-100 bg-white p-3.5 shadow-sm transition-colors hover:bg-brand-50"
            >
              <div
                className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${section.iconBg}`}
              >
                {section.icon}
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-sm font-extrabold text-brand-900">
                  {section.title}
                </h3>
                <p className="mt-0.5 truncate text-xs font-medium text-slate-500">
                  {section.subtitle}
                </p>
              </div>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 text-brand-400">
                <path d="M15 6l-6 6 6 6" />
              </svg>
            </Link>
          </li>
        ))}
        
        {/* قسم المؤذن */}
        <li>
          <Link
            to="/adhan"
            className="tap-highlight flex items-center gap-3 rounded-2xl border border-brand-100 bg-white p-3.5 shadow-sm transition-colors hover:bg-brand-50"
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
                <path d="M19 10v1a7 7 0 0 1-14 0v-1M12 18v4M8 22h8" />
              </svg>
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="text-sm font-extrabold text-brand-900">
                المؤذن
              </h3>
              <p className="mt-0.5 truncate text-xs font-medium text-slate-500">
                إعدادات الأذان التلقائي
              </p>
            </div>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 text-brand-400">
              <path d="M15 6l-6 6 6 6" />
            </svg>
          </Link>
        </li>
      </ul>

      <div className="mt-6 rounded-2xl border border-brand-100 bg-white p-4 text-center">
        <div className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-gold-400 to-gold-600 text-brand-900">
          {icons.star}
        </div>
        <p className="text-xs font-medium text-slate-600">
          نور القرآن · تطبيق مجاني بالكامل
        </p>
        <p className="mt-0.5 text-[11px] text-slate-400">
          لا يحتوي على إعلانات ولا يتطلب اشتراكاً
        </p>
      </div>
    </div>
  );
}
