import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import type { Surah } from "@/types/quran";
import { loadQuran, revelationInArabic, SURAH_SIMPLE_NAMES } from "@/services/quranApi";
import { useSettings } from "@/hooks/useSettings";
import { toArabicDigits } from "./QuranHome";

/**
 * صفحة قراءة السورة.
 * تعرض البسملة (إن وُجدت) + جميع الآيات + أرقامها + زر الانتقال للسورة التالية/السابقة.
 */
export default function QuranReader() {
  const { number } = useParams<{ number: string }>();
  const surahNumber = parseInt(number ?? "1", 10);
  const navigate = useNavigate();
  const [surah, setSurah] = useState<Surah | null>(null);
  const [allSurahs, setAllSurahs] = useState<Surah[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [jumpOpen, setJumpOpen] = useState(false);
  const { settings, setFontSize, toggleDarkMode, saveLastRead } = useSettings();

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    loadQuran()
      .then((data) => {
        if (cancelled) return;
        setAllSurahs(data.surahs);
        const found = data.surahs.find((s) => s.number === surahNumber);
        if (!found) {
          setError("السورة غير موجودة");
        } else {
          setSurah(found);
        }
      })
      .catch((e: Error) => {
        if (!cancelled) setError(e.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [surahNumber]);

  // حفظ آخر قراءة تلقائياً عند فتح السورة
  useEffect(() => {
    if (surah) {
      saveLastRead(surah.number, 1);
    }
  }, [surah, saveLastRead]);

  // الانتقال إلى الآية المحددة في hash عند تحميل الصفحة
  useEffect(() => {
    if (!surah) return;
    const hash = window.location.hash;
    if (hash.startsWith("#ayah-")) {
      const ayahNum = parseInt(hash.slice(6), 10);
      if (ayahNum > 0 && ayahNum <= surah.numberOfAyahs) {
        // تأخير قصير لضمان تحميل DOM
        setTimeout(() => {
          const el = document.getElementById(`ayah-${ayahNum}`);
          el?.scrollIntoView({ behavior: "smooth", block: "center" });
          // تحديث آخر قراءة
          saveLastRead(surah.number, ayahNum);
        }, 300);
      }
    }
  }, [surah, saveLastRead]);

  // تفعيل الوضع الليلي على العنصر الجذر للقارئ
  const dark = settings.darkMode;

  const prevSurah = useMemo(
    () => allSurahs.find((s) => s.number === surahNumber - 1),
    [allSurahs, surahNumber]
  );
  const nextSurah = useMemo(
    () => allSurahs.find((s) => s.number === surahNumber + 1),
    [allSurahs, surahNumber]
  );

  // معالجة البسملة: في المصحف المطبوع، البسملة تُعرض كعنوان مستقل في بداية
  // كل سورة ما عدا الفاتحة (حيث هي آية) والتوبة (لا تبدأ بالبسملة).
  // نص API يضع البسملة في بداية الآية الأولى، لذا نفصلها للعرض الصحيح.
  const BASMALAH_PATTERN = /^بِسْمِ\s+ٱللَّهِ\s+ٱلرَّحْمَٰنِ\s+ٱلرَّحِيمِ\s*/;
  const processedAyahs = useMemo(() => {
    if (!surah) return { basmalah: null as string | null, ayahs: [] as Surah["ayahs"] };
    if (surah.number === 1 || surah.number === 9) {
      return { basmalah: null, ayahs: surah.ayahs };
    }
    const first = surah.ayahs[0];
    const match = first.text.match(BASMALAH_PATTERN);
    if (match) {
      const basmalah = match[0].trim();
      const restText = first.text.slice(match[0].length);
      return {
        basmalah,
        ayahs: [{ ...first, text: restText }, ...surah.ayahs.slice(1)],
      };
    }
    return { basmalah: null, ayahs: surah.ayahs };
  }, [surah]);

  if (loading) {
    return (
      <div className="px-4 pt-8 text-center">
        <div className="mx-auto mb-4 h-12 w-12 animate-spin rounded-full border-4 border-brand-200 border-t-brand-700" />
        <p className="text-sm font-medium text-slate-500">تحميل السورة...</p>
      </div>
    );
  }

  if (error || !surah) {
    return (
      <div className="px-4 pt-6 text-center">
        <p className="text-sm font-bold text-red-600">{error ?? "خطأ"}</p>
        <Link
          to="/quran"
          className="tap-highlight mt-4 inline-block rounded-2xl bg-brand-900 px-4 py-2 text-sm font-bold text-gold-300"
        >
          العودة للقائمة
        </Link>
      </div>
    );
  }

  return (
    <div
      className={`min-h-screen transition-colors ${
        dark ? "bg-[#0b1f17]" : "bg-paper-soft"
      }`}
    >
      {/* رأس السورة */}
      <div
        className={`mx-4 mt-4 overflow-hidden rounded-3xl border shadow-sm ${
          dark
            ? "border-brand-800 bg-gradient-to-br from-brand-900 to-brand-950"
            : "border-gold-200 bg-gradient-to-br from-brand-800 to-brand-950"
        } p-5 text-center text-white`}
      >
        <svg
          className="pointer-events-none absolute inset-x-0 top-0 mx-auto text-gold-400/10"
          width="300"
          height="80"
          viewBox="0 0 300 80"
        >
          <path
            d="M0 40 Q 150 0 300 40 Q 150 80 0 40"
            fill="none"
            stroke="currentColor"
            strokeWidth="1"
          />
        </svg>
        <p className="text-xs font-bold text-gold-300/90">
          سورة رقم {toArabicDigits(surah.number)}
        </p>
        <h2 className="mt-1 font-amiri text-3xl font-bold leading-snug">
          {surah.simpleName}
        </h2>
        <div className="mt-2 flex items-center justify-center gap-3 text-[11px] text-brand-100/80">
          <span>{revelationInArabic(surah.revelationType)}</span>
          <span className="h-1 w-1 rounded-full bg-gold-400/50" />
          <span>{toArabicDigits(surah.numberOfAyahs)} آية</span>
        </div>
      </div>

      {/* شريط الأدوات */}
      <div className="mx-4 mt-3 flex flex-wrap items-center justify-between gap-2">
        <button
          onClick={() => setJumpOpen(true)}
          className={`tap-highlight flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-bold ${
            dark
              ? "border-brand-700 bg-brand-900/50 text-brand-100"
              : "border-brand-200 bg-white text-brand-800"
          }`}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 5v14M5 12h14" />
          </svg>
          الانتقال لآية
        </button>
        <button
          onClick={() => setShowSettings((v) => !v)}
          className={`tap-highlight flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-bold ${
            dark
              ? "border-brand-700 bg-brand-900/50 text-brand-100"
              : "border-brand-200 bg-white text-brand-800"
          }`}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="3" />
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h0a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
          </svg>
          الإعدادات
        </button>
      </div>

      {/* لوحة الإعدادات */}
      {showSettings && (
        <SettingsPanel
          fontSize={settings.fontSize}
          darkMode={dark}
          onFontSize={setFontSize}
          onToggleDark={toggleDarkMode}
        />
      )}

      {/* البسملة (للسور ما عدا الفاتحة والتوبة) */}
      {processedAyahs.basmalah && (
        <p
          className="mx-4 mt-4 text-center font-amiri"
          style={{
            fontSize: `${Math.min(settings.fontSize + 2, 40)}px`,
            color: dark ? "#e8d89a" : "#0f3d2e",
          }}
        >
          {processedAyahs.basmalah}
        </p>
      )}

      {/* الآيات */}
      <div className="mx-4 mt-4 rounded-3xl border p-4 shadow-sm"
        style={{
          backgroundColor: dark ? "#0f2a1f" : "#ffffff",
          borderColor: dark ? "#1d4333" : undefined,
        }}
      >
        <div className="font-amiri leading-loose"
          style={{
            fontSize: `${settings.fontSize}px`,
            color: dark ? "#f5ecd0" : "#0f3d2e",
            textAlign: "justify",
          }}
        >
          {processedAyahs.ayahs.map((ayah) => {
            // إذا كانت الآية بعد إزالة البسملة فارغة (مثل آية البقرة الأولى
            // التي تصبح "الٓمٓ" فقط)، نعرضها بشكل طبيعي
            const displayText = ayah.text || "";
            return (
              <span key={ayah.number} id={`ayah-${ayah.numberInSurah}`}>
                <span>{displayText}</span>
                <span
                  className="mx-1 inline-flex h-8 w-8 items-center justify-center rounded-full align-middle"
                  style={{
                    fontSize: "0.45em",
                    fontFamily: "Cairo, sans-serif",
                    fontWeight: 700,
                    color: dark ? "#d4af37" : "#85632f",
                    backgroundImage:
                      "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='32' height='32' viewBox='0 0 32 32'%3E%3Cpath d='M16 2 L20 12 L30 16 L20 20 L16 30 L12 20 L2 16 L12 12 Z' fill='none' stroke='%23d4af37' stroke-opacity='0.6' stroke-width='1'/%3E%3Ccircle cx='16' cy='16' r='5' fill='none' stroke='%23d4af37' stroke-opacity='0.4' stroke-width='0.8'/%3E%3C/svg%3E\")",
                    backgroundSize: "contain",
                    backgroundRepeat: "no-repeat",
                    backgroundPosition: "center",
                  }}
                  aria-label={`آية ${ayah.numberInSurah}`}
                >
                  {toArabicDigits(ayah.numberInSurah)}
                </span>
                {" "}
              </span>
            );
          })}
        </div>
      </div>

      {/* التنقل بين السور */}
      <div className="mx-4 mt-4 grid grid-cols-2 gap-2 pb-6">
        {prevSurah ? (
          <button
            onClick={() => navigate(`/quran/${prevSurah.number}`)}
            className={`tap-highlight flex items-center gap-2 rounded-2xl border p-3 text-right ${
              dark
                ? "border-brand-700 bg-brand-900/50 text-brand-100"
                : "border-brand-100 bg-white text-brand-800"
            }`}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
              <path d="M9 6l6 6-6 6" />
            </svg>
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold text-slate-400">السابقة</p>
              <p className="truncate text-sm font-extrabold">{prevSurah.simpleName}</p>
            </div>
          </button>
        ) : <div />}
        {nextSurah ? (
          <button
            onClick={() => navigate(`/quran/${nextSurah.number}`)}
            className={`tap-highlight flex items-center gap-2 rounded-2xl border p-3 text-right ${
              dark
                ? "border-brand-700 bg-brand-900/50 text-brand-100"
                : "border-brand-100 bg-white text-brand-800"
            }`}
          >
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold text-slate-400">التالية</p>
              <p className="truncate text-sm font-extrabold">{nextSurah.simpleName}</p>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
              <path d="M15 6l-6 6 6 6" />
            </svg>
          </button>
        ) : <div />}
      </div>

      {/* نافذة الانتقال لآية */}
      {jumpOpen && (
        <JumpToAyahDialog
          maxAyah={surah.numberOfAyahs}
          allSurahs={allSurahs}
          onClose={() => setJumpOpen(false)}
          onJump={(surahNum, ayahNum) => {
            setJumpOpen(false);
            if (surahNum !== surah.number) {
              navigate(`/quran/${surahNum}#ayah-${ayahNum}`);
            } else {
              const el = document.getElementById(`ayah-${ayahNum}`);
              el?.scrollIntoView({ behavior: "smooth", block: "center" });
            }
          }}
        />
      )}

    </div>
  );
}

function SettingsPanel({
  fontSize,
  darkMode,
  onFontSize,
  onToggleDark,
}: {
  fontSize: number;
  darkMode: boolean;
  onFontSize: (n: number) => void;
  onToggleDark: () => void;
}) {
  return (
    <div
      className={`mx-4 mt-3 rounded-2xl border p-4 shadow-sm ${
        darkMode
          ? "border-brand-700 bg-brand-900/70 text-brand-100"
          : "border-brand-100 bg-white text-brand-800"
      }`}
    >
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm font-bold">حجم الخط</p>
          <p className="text-[11px] opacity-70">{toArabicDigits(fontSize)} بكسل</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onFontSize(fontSize - 2)}
            className={`tap-highlight flex h-9 w-9 items-center justify-center rounded-full border ${
              darkMode ? "border-brand-700 bg-brand-900" : "border-brand-200 bg-white"
            }`}
            aria-label="تصغير الخط"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M5 12h14" /></svg>
          </button>
          <button
            onClick={() => onFontSize(fontSize + 2)}
            className={`tap-highlight flex h-9 w-9 items-center justify-center rounded-full border ${
              darkMode ? "border-brand-700 bg-brand-900" : "border-brand-200 bg-white"
            }`}
            aria-label="تكبير الخط"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
          </button>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between gap-3 border-t pt-3" style={{ borderColor: darkMode ? "#1d4333" : undefined }}>
        <div>
          <p className="text-sm font-bold">الوضع الليلي</p>
          <p className="text-[11px] opacity-70">لقراءة مريحة في الظلام</p>
        </div>
        <button
          onClick={onToggleDark}
          className={`relative h-7 w-12 rounded-full transition-colors ${
            darkMode ? "bg-gold-500" : "bg-brand-200"
          }`}
          aria-label="تبديل الوضع الليلي"
        >
          <span
            className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow-md transition-transform ${
              darkMode ? "right-0.5" : "right-[22px]"
            }`}
          />
        </button>
      </div>
    </div>
  );
}

function JumpToAyahDialog({
  maxAyah,
  allSurahs,
  onClose,
  onJump,
}: {
  maxAyah: number;
  allSurahs: Surah[];
  onClose: () => void;
  onJump: (surah: number, ayah: number) => void;
}) {
  const { number } = useParams<{ number: string }>();
  const currentSurah = parseInt(number ?? "1", 10);
  const [surahNum, setSurahNum] = useState(currentSurah);
  const [ayahNum, setAyahNum] = useState(1);

  const selectedSurah = allSurahs.find((s) => s.number === surahNum);
  const max = selectedSurah?.numberOfAyahs ?? maxAyah;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-4 sm:items-center"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-3xl bg-white p-5 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-base font-extrabold text-brand-900">الانتقال</h3>
          <button
            onClick={onClose}
            className="tap-highlight flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-500"
            aria-label="إغلاق"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>

        <label className="block text-xs font-bold text-brand-800">السورة</label>
        <select
          value={surahNum}
          onChange={(e) => {
            const n = parseInt(e.target.value, 10);
            setSurahNum(n);
            setAyahNum(1);
          }}
          className="mt-1 w-full rounded-xl border border-brand-200 bg-white p-2.5 text-sm font-medium text-brand-900"
        >
          {allSurahs.map((s) => (
            <option key={s.number} value={s.number}>
              {s.number}. {SURAH_SIMPLE_NAMES[s.number]}
            </option>
          ))}
        </select>

        <label className="mt-3 block text-xs font-bold text-brand-800">
          رقم الآية (١ - {toArabicDigits(max)})
        </label>
        <input
          type="number"
          min={1}
          max={max}
          value={ayahNum}
          onChange={(e) => {
            const v = parseInt(e.target.value, 10) || 1;
            setAyahNum(Math.max(1, Math.min(max, v)));
          }}
          className="mt-1 w-full rounded-xl border border-brand-200 bg-white p-2.5 text-sm font-medium text-brand-900"
        />

        <button
          onClick={() => onJump(surahNum, ayahNum)}
          className="tap-highlight mt-4 w-full rounded-2xl bg-brand-900 py-2.5 text-sm font-bold text-gold-300 shadow-md"
        >
          انتقال
        </button>
      </div>
    </div>
  );
}
