import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  MUEZZINS,
  searchMuezzins,
  getAvailableCountries,
  getMuezzinById,
  type Muezzin,
} from "@/data/muezzins";
import {
  getAdhanSettings,
  saveAdhanSettings,
} from "@/services/adhanService";

interface PrayerMuezzinSettings {
  Fajr: string;
  Dhuhr: string;
  Asr: string;
  Maghrib: string;
  Isha: string;
}

export default function MuezzinPage() {
  const navigate = useNavigate();
  const [prayerMuezzins, setPrayerMuezzins] = useState<PrayerMuezzinSettings>({
    Fajr: "ali_ahmed_mulla",
    Dhuhr: "ali_ahmed_mulla",
    Asr: "ali_ahmed_mulla",
    Maghrib: "ali_ahmed_mulla",
    Isha: "ali_ahmed_mulla",
  });
  const [selectedPrayer, setSelectedPrayer] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCountry, setSelectedCountry] = useState<string>("all");
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [audioPlayer, setAudioPlayer] = useState<HTMLAudioElement | null>(null);
  const [volume, setVolume] = useState(0.8);
  const [nextPrayerInfo, setNextPrayerInfo] = useState<{
    name: string;
    nameAr: string;
    time: string;
    countdown: string;
  } | null>(null);

  const prayers = [
    { id: "Fajr", nameAr: "الفجر", icon: "🌅" },
    { id: "Dhuhr", nameAr: "الظهر", icon: "☀️" },
    { id: "Asr", nameAr: "العصر", icon: "🌤️" },
    { id: "Maghrib", nameAr: "المغرب", icon: "🌅" },
    { id: "Isha", nameAr: "العشاء", icon: "🌙" },
  ];

  const countries = getAvailableCountries();

  // تحميل إعدادات المؤذنين لكل صلاة
  useEffect(() => {
    const saved = localStorage.getItem("prayer-muezzins");
    if (saved) {
      try {
        setPrayerMuezzins(JSON.parse(saved));
      } catch (e) {
        console.warn("فشل تحميل إعدادات المؤذنين:", e);
      }
    }
  }, []);

  // حفظ إعدادات المؤذنين
  useEffect(() => {
    localStorage.setItem("prayer-muezzins", JSON.stringify(prayerMuezzins));
  }, [prayerMuezzins]);

  // تحديث معلومات الصلاة التالية
  useEffect(() => {
    const interval = setInterval(() => {
      // محاكاة - في الواقع يجب ربط هذا بمواقيت الصلاة
      const now = new Date();
      const hours = now.getHours();
      let nextPrayer = "الفجر";
      let nextTime = "05:30";
      let countdown = "3 ساعات 15 دقيقة";

      if (hours >= 5 && hours < 12) {
        nextPrayer = "الظهر";
        nextTime = "12:15";
        countdown = "2 ساعة 45 دقيقة";
      } else if (hours >= 12 && hours < 15) {
        nextPrayer = "العصر";
        nextTime = "15:30";
        countdown = "1 ساعة 20 دقيقة";
      } else if (hours >= 15 && hours < 18) {
        nextPrayer = "المغرب";
        nextTime = "18:20";
        countdown = "45 دقيقة";
      } else if (hours >= 18 && hours < 20) {
        nextPrayer = "العشاء";
        nextTime = "19:45";
        countdown = "30 دقيقة";
      }

      setNextPrayerInfo({
        name: nextPrayer,
        nameAr: nextPrayer,
        time: nextTime,
        countdown,
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const filteredMuezzins = searchQuery
    ? searchMuezzins(searchQuery)
    : selectedCountry !== "all"
    ? MUEZZINS.filter((m) => m.countryAr === selectedCountry)
    : MUEZZINS;

  const playAdhan = async (muezzin: Muezzin) => {
    if (playingId === muezzin.id) {
      // إيقاف التشغيل
      if (audioPlayer) {
        audioPlayer.pause();
        audioPlayer.currentTime = 0;
      }
      setPlayingId(null);
      setAudioPlayer(null);
    } else {
      // تشغيل جديد
      if (audioPlayer) {
        audioPlayer.pause();
      }

      try {
        const audio = new Audio(muezzin.adhanUrl);
        audio.volume = volume;
        audio.preload = "auto";

        audio.onplay = () => {
          setPlayingId(muezzin.id);
          setAudioPlayer(audio);
        };

        audio.onended = () => {
          setPlayingId(null);
          setAudioPlayer(null);
        };

        audio.onerror = () => {
          alert("فشل تشغيل الأذان. يرجى التحقق من الاتصال بالإنترنت.");
          setPlayingId(null);
          setAudioPlayer(null);
        };

        await audio.play();
      } catch (e) {
        console.error("فشل تشغيل الأذان:", e);
        alert("فشل تشغيل الأذان. يرجى المحاولة مرة أخرى.");
      }
    }
  };

  const selectMuezzin = (muezzinId: string) => {
    if (!selectedPrayer) return;

    const newSettings = {
      ...prayerMuezzins,
      [selectedPrayer]: muezzinId,
    };
    setPrayerMuezzins(newSettings);
    setSelectedPrayer(null);

    // حفظ في إعدادات الأذان أيضاً
    const adhanSettings = getAdhanSettings();
    saveAdhanSettings({
      ...adhanSettings,
      selectedAdhanId: muezzinId,
    });
  };

  const applyToAllPrayers = (muezzinId: string) => {
    const newSettings = {
      Fajr: muezzinId,
      Dhuhr: muezzinId,
      Asr: muezzinId,
      Maghrib: muezzinId,
      Isha: muezzinId,
    };
    setPrayerMuezzins(newSettings);
    alert("تم تطبيق المؤذن على جميع الصلوات");
  };

  const getCurrentMuezzin = (prayerId: string): Muezzin => {
    const muezzinId = prayerMuezzins[prayerId as keyof PrayerMuezzinSettings];
    return getMuezzinById(muezzinId) || MUEZZINS[0];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-900">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* الرأس */}
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-amber-400 mb-2">المؤذن والأذان</h1>
            <p className="text-emerald-100">اختر مؤذنك المفضل لكل صلاة</p>
          </div>
          <button
            onClick={() => navigate("/prayer")}
            className="p-3 bg-white/10 hover:bg-white/20 rounded-full transition-colors"
            title="العودة لمواقيت الصلاة"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
              <path d="M19 12H5M12 19l-7-7 7-7" />
            </svg>
          </button>
        </div>

        {/* بطاقة الصلاة التالية */}
        {nextPrayerInfo && (
          <div className="mb-6 p-6 bg-gradient-to-br from-amber-500 to-amber-600 text-white rounded-2xl shadow-2xl">
            <div className="text-center">
              <p className="text-sm opacity-90 mb-1">الصلاة التالية</p>
              <h2 className="text-3xl font-bold mb-2">{nextPrayerInfo.nameAr}</h2>
              <p className="text-xl font-semibold mb-1" dir="ltr">{nextPrayerInfo.time}</p>
              <p className="text-sm opacity-90">باقي على الأذان: {nextPrayerInfo.countdown}</p>
            </div>
          </div>
        )}

        {/* بطاقات الصلوات */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-white mb-4">اختر مؤذن لكل صلاة</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {prayers.map((prayer) => {
              const muezzin = getCurrentMuezzin(prayer.id);
              const isSelected = selectedPrayer === prayer.id;
              return (
                <button
                  key={prayer.id}
                  onClick={() => setSelectedPrayer(prayer.id)}
                  className={`p-4 rounded-xl border-2 transition-all text-right ${
                    isSelected
                      ? "bg-amber-400/20 border-amber-400 shadow-lg scale-105"
                      : "bg-white/10 border-white/20 hover:border-amber-400/50"
                  }`}
                >
                  <div className="text-3xl mb-2">{prayer.icon}</div>
                  <p className="font-bold text-white text-lg mb-1">{prayer.nameAr}</p>
                  <p className="text-xs text-amber-300 truncate">{muezzin.nameAr}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* البحث والفلترة */}
        {selectedPrayer && (
          <>
            <div className="mb-6 p-5 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20">
              <h3 className="text-lg font-bold text-white mb-4">
                اختر مؤذن لصلاة {prayers.find((p) => p.id === selectedPrayer)?.nameAr}
              </h3>

              <div className="mb-4">
                <input
                  type="text"
                  placeholder="ابحث عن مؤذن..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50"
                />
              </div>

              <div className="mb-4">
                <select
                  value={selectedCountry}
                  onChange={(e) => setSelectedCountry(e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white"
                >
                  <option value="all" className="bg-emerald-900">جميع البلدان</option>
                  {countries.map((country) => (
                    <option key={country} value={country} className="bg-emerald-900">
                      {country}
                    </option>
                  ))}
                </select>
              </div>

              {/* مستوى الصوت */}
              <div className="mb-4">
                <label className="block text-sm text-white mb-2">مستوى الصوت</label>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={volume}
                    onChange={(e) => setVolume(parseFloat(e.target.value))}
                    className="flex-1 h-2 bg-white/20 rounded-lg appearance-none cursor-pointer accent-amber-400"
                  />
                  <span className="text-white text-sm w-12 text-center">{Math.round(volume * 100)}%</span>
                </div>
              </div>
            </div>

            {/* قائمة المؤذنين */}
            <div className="space-y-3 mb-6">
              {filteredMuezzins.map((muezzin) => {
                const isPlaying = playingId === muezzin.id;
                return (
                  <div
                    key={muezzin.id}
                    className="p-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl hover:border-amber-400/50 transition-all"
                  >
                    <div className="flex items-start gap-4">
                      {/* أيقونة المؤذن */}
                      <div className="shrink-0">
                        <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full flex items-center justify-center text-2xl font-bold text-emerald-900">
                          🕌
                        </div>
                      </div>

                      {/* معلومات المؤذن */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="flex-1 min-w-0">
                            <h3 className="font-bold text-white text-lg truncate">{muezzin.nameAr}</h3>
                            <p className="text-sm text-amber-300 truncate">{muezzin.name}</p>
                          </div>
                          {muezzin.verified && (
                            <span className="shrink-0 px-2 py-1 bg-green-500/20 border border-green-500/30 rounded text-xs text-green-300">
                              ✓ موثق
                            </span>
                          )}
                        </div>

                        <div className="space-y-1 mb-3">
                          <p className="text-sm text-emerald-200">
                            🌍 {muezzin.countryAr}
                          </p>
                          {muezzin.mosqueAr && (
                            <p className="text-sm text-emerald-200">
                              🕌 {muezzin.mosqueAr}
                            </p>
                          )}
                          {muezzin.descriptionAr && (
                            <p className="text-xs text-white/70">
                              {muezzin.descriptionAr}
                            </p>
                          )}
                          <p className="text-xs text-white/50">
                            المصدر: {muezzin.source} • المدة: {muezzin.duration} دقيقة
                          </p>
                        </div>

                        {/* أزرار التحكم */}
                        <div className="flex items-center gap-2 flex-wrap">
                          <button
                            onClick={() => playAdhan(muezzin)}
                            disabled={!muezzin.verified}
                            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                              isPlaying
                                ? "bg-red-500 hover:bg-red-600 text-white"
                                : "bg-amber-500 hover:bg-amber-600 text-white"
                            } disabled:opacity-50 disabled:cursor-not-allowed`}
                          >
                            {isPlaying ? "⏹️ إيقاف" : "▶️ معاينة"}
                          </button>

                          <button
                            onClick={() => selectMuezzin(muezzin.id)}
                            className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg text-sm font-medium transition-colors"
                          >
                            ✓ اختيار
                          </button>

                          <button
                            onClick={() => applyToAllPrayers(muezzin.id)}
                            className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg text-sm font-medium transition-colors"
                          >
                            تطبيق على الكل
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {/* معلومات مهمة */}
        <div className="mb-6 p-5 bg-blue-500/10 border border-blue-500/20 rounded-xl">
          <h3 className="font-bold text-blue-300 mb-3">📝 ملاحظات مهمة</h3>
          <ul className="space-y-2 text-sm text-blue-200">
            <li>• جميع التسجيلات حقيقية من مصادر موثوقة (Internet Archive)</li>
            <li>• يمكنك اختيار مؤذن مختلف لكل صلاة</li>
            <li>• اضغط "معاينة" للاستماع قبل الاختيار</li>
            <li>• يتم حفظ اختياراتك تلقائياً</li>
            <li>• الأذان التلقائي يعمل عند فتح التطبيق</li>
            <li>• للتنبيهات في الخلفية، يرجى تثبيت التطبيق كـ PWA</li>
          </ul>
        </div>

        {/* إعدادات إضافية */}
        <div className="p-5 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
          <h3 className="font-bold text-white mb-4">⚙️ إعدادات إضافية</h3>
          <div className="space-y-3">
            <button
              onClick={() => navigate("/adhan")}
              className="w-full px-4 py-3 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg transition-colors text-right"
            >
              🔔 إعدادات التنبيهات والأذان التلقائي
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
