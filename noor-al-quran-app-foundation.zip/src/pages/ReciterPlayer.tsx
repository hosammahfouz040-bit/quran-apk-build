import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { RECITERS, getSurahAudioUrl, type Reciter } from "@/data/reciters";
import { SURAH_SIMPLE_NAMES } from "@/services/quranApi";
import { toArabicDigits } from "./QuranHome";

/**
 * صفحة قارئ القرآن - قائمة السور + مشغل صوتي.
 */
export default function ReciterPlayer() {
  const { reciterId } = useParams<{ reciterId: string }>();
  const navigate = useNavigate();
  const reciter = useMemo(
    () => RECITERS.find((r) => r.id === reciterId),
    [reciterId]
  );

  const [currentSurah, setCurrentSurah] = useState(1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // إنشاء عنصر الصوت مرة واحدة
  useEffect(() => {
    const audio = new Audio();
    audio.preload = "metadata";
    audioRef.current = audio;

    const onLoadedMetadata = () => {
      setDuration(audio.duration);
      setIsLoading(false);
    };
    const onTimeUpdate = () => setCurrentTime(audio.currentTime);
    const onEnded = () => {
      // الانتقال للسورة التالية تلقائياً
      setCurrentSurah((prev) => {
        const next = prev < 114 ? prev + 1 : prev;
        return next;
      });
    };
    const onError = () => {
      setIsLoading(false);
      setIsPlaying(false);
      setError("تعذّر تحميل الملف الصوتي");
    };
    const onWaiting = () => setIsLoading(true);
    const onCanPlay = () => setIsLoading(false);

    audio.addEventListener("loadedmetadata", onLoadedMetadata);
    audio.addEventListener("timeupdate", onTimeUpdate);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("error", onError);
    audio.addEventListener("waiting", onWaiting);
    audio.addEventListener("canplay", onCanPlay);

    return () => {
      audio.pause();
      audio.removeEventListener("loadedmetadata", onLoadedMetadata);
      audio.removeEventListener("timeupdate", onTimeUpdate);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("error", onError);
      audio.removeEventListener("waiting", onWaiting);
      audio.removeEventListener("canplay", onCanPlay);
    };
  }, []);

  // تحميل السورة الحالية
  useEffect(() => {
    if (!audioRef.current || !reciter) return;
    const audio = audioRef.current;
    const url = getSurahAudioUrl(reciter, currentSurah);
    audio.src = url;
    setError(null);
    setCurrentTime(0);
    setDuration(0);
    setIsLoading(true);
    audio.load();
    if (isPlaying) {
      audio.play().catch(() => {
        setIsPlaying(false);
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentSurah, reciter]);

  // التحكم في التشغيل/الإيقاف
  useEffect(() => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.play().catch(() => setIsPlaying(false));
    } else {
      audioRef.current.pause();
    }
  }, [isPlaying]);

  if (!reciter) {
    return (
      <div className="px-4 pt-6 text-center">
        <p className="text-sm font-bold text-red-600">القارئ غير موجود</p>
        <button
          onClick={() => navigate("/reciters")}
          className="tap-highlight mt-4 inline-block rounded-2xl bg-brand-900 px-4 py-2 text-sm font-bold text-gold-300"
        >
          العودة للقائمة
        </button>
      </div>
    );
  }

  const togglePlay = () => {
    setError(null);
    setIsPlaying((p) => !p);
  };

  const playSurah = (num: number) => {
    setCurrentSurah(num);
    setIsPlaying(true);
  };

  const nextSurah = () => {
    if (currentSurah < 114) {
      setCurrentSurah((s) => s + 1);
    }
  };

  const prevSurah = () => {
    if (currentSurah > 1) {
      setCurrentSurah((s) => s - 1);
    }
  };

  const seek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (audioRef.current) {
      const newTime = parseFloat(e.target.value);
      audioRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const restart = () => {
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      setCurrentTime(0);
      if (!isPlaying) setIsPlaying(true);
    }
  };

  return (
    <div className="px-4 pt-4 pb-4">
      {/* رأس القارئ */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-800 via-brand-900 to-brand-950 p-5 text-white shadow-xl">
        <svg className="pointer-events-none absolute -left-6 -top-6 text-gold-400/15" width="140" height="140" viewBox="0 0 140 140" fill="none">
          <path d="M70 10 L85 55 L130 70 L85 85 L70 130 L55 85 L10 70 L55 55 Z" stroke="currentColor" strokeWidth="1.5" />
          <circle cx="70" cy="70" r="30" stroke="currentColor" strokeWidth="1" />
        </svg>
        <div className="relative flex items-center gap-4">
          <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-gold-400 to-gold-600 text-brand-900 shadow-lg">
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
              <path d="M19 10v1a7 7 0 0 1-14 0v-1" />
            </svg>
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-lg font-extrabold leading-tight">{reciter.shortName}</h2>
            <p className="mt-0.5 text-[11px] text-brand-100/80 truncate">
              {reciter.nameAr}
            </p>
            <div className="mt-1.5 flex flex-wrap gap-1.5 text-[10px]">
              <span className="rounded-full bg-white/15 px-2 py-0.5 font-bold backdrop-blur-sm">
                {reciter.country}
              </span>
              <span className="rounded-full bg-gold-400/20 px-2 py-0.5 font-bold text-gold-200 backdrop-blur-sm">
                {reciter.style}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* مشغل الصوت */}
      <div className="mt-4 rounded-3xl border border-brand-100 bg-white p-4 shadow-sm">
        {/* معلومات السورة الحالية */}
        <div className="text-center">
          <p className="text-[11px] font-bold text-brand-500">
            سورة {toArabicDigits(currentSurah)} من ١١٤
          </p>
          <h3 className="mt-1 text-xl font-extrabold text-brand-900">
            {SURAH_SIMPLE_NAMES[currentSurah]}
          </h3>
        </div>

        {/* شريط التقدم */}
        <div className="mt-4">
          <input
            type="range"
            min={0}
            max={duration || 0}
            step={0.1}
            value={currentTime}
            onChange={seek}
            disabled={!duration}
            className="quran-range w-full"
            aria-label="تقدم التلاوة"
          />
          <div className="mt-1 flex justify-between text-[11px] font-bold text-slate-500">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* رسالة الخطأ */}
        {error && (
          <div className="mt-2 rounded-xl bg-red-50 p-2 text-center text-xs font-bold text-red-600">
            {error}
          </div>
        )}

        {/* أزرار التحكم */}
        <div className="mt-4 flex items-center justify-center gap-3">
          <button
            onClick={prevSurah}
            disabled={currentSurah <= 1}
            className="tap-highlight flex h-11 w-11 items-center justify-center rounded-full border border-brand-100 bg-white text-brand-800 shadow-sm disabled:opacity-30"
            aria-label="السورة السابقة"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
              <path d="M6 4h2v16H6zM20 4L10 12l10 8V4z" />
            </svg>
          </button>

          <button
            onClick={restart}
            disabled={!duration}
            className="tap-highlight flex h-11 w-11 items-center justify-center rounded-full border border-brand-100 bg-white text-brand-800 shadow-sm disabled:opacity-30"
            aria-label="إعادة من البداية"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 12a9 9 0 1 0 3-6.7L3 8" />
              <path d="M3 3v5h5" />
            </svg>
          </button>

          <button
            onClick={togglePlay}
            disabled={isLoading && !duration}
            className="tap-highlight flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-brand-700 to-brand-900 text-gold-300 shadow-lg shadow-brand-900/30 disabled:opacity-50"
            aria-label={isPlaying ? "إيقاف" : "تشغيل"}
          >
            {isLoading && !duration ? (
              <svg className="animate-spin" width="24" height="24" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeOpacity="0.3" strokeWidth="3" />
                <path d="M22 12a10 10 0 0 0-10-10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
              </svg>
            ) : isPlaying ? (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                <path d="M6 4h4v16H6zM14 4h4v16h-4z" />
              </svg>
            ) : (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5v14l11-7L8 5z" />
              </svg>
            )}
          </button>

          <button
            onClick={restart}
            disabled={!duration}
            className="tap-highlight flex h-11 w-11 items-center justify-center rounded-full border border-brand-100 bg-white text-brand-800 shadow-sm opacity-0 pointer-events-none"
            aria-hidden
            tabIndex={-1}
          >
            &nbsp;
          </button>

          <button
            onClick={nextSurah}
            disabled={currentSurah >= 114}
            className="tap-highlight flex h-11 w-11 items-center justify-center rounded-full border border-brand-100 bg-white text-brand-800 shadow-sm disabled:opacity-30"
            aria-label="السورة التالية"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
              <path d="M16 4h2v16h-2zM4 4l10 8-10 8V4z" />
            </svg>
          </button>
        </div>
      </div>

      {/* قائمة السور */}
      <div className="mt-4 rounded-2xl border border-brand-100 bg-white p-3 shadow-sm">
        <div className="mb-2 flex items-center justify-between px-1">
          <h3 className="text-sm font-extrabold text-brand-900">
            قائمة السور
          </h3>
          <span className="text-[11px] font-bold text-brand-500">
            {toArabicDigits(114)} سورة
          </span>
        </div>
        <div className="max-h-80 overflow-y-auto">
          <ul className="space-y-1">
            {Array.from({ length: 114 }, (_, i) => i + 1).map((num) => (
              <li key={num}>
                <button
                  onClick={() => playSurah(num)}
                  className={`tap-highlight flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-right ${
                    num === currentSurah
                      ? "bg-brand-900 text-gold-300"
                      : "hover:bg-brand-50 text-brand-900"
                  }`}
                >
                  <div
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-[11px] font-extrabold ${
                      num === currentSurah
                        ? "bg-gold-400/20 text-gold-300"
                        : "bg-brand-50 text-brand-700"
                    }`}
                  >
                    {toArabicDigits(num)}
                  </div>
                  <span className="min-w-0 flex-1 truncate text-sm font-bold">
                    {SURAH_SIMPLE_NAMES[num]}
                  </span>
                  {num === currentSurah && isPlaying && (
                    <div className="flex items-end gap-0.5">
                      <span className="inline-block h-3 w-0.5 animate-pulse bg-gold-400" />
                      <span className="inline-block h-4 w-0.5 animate-pulse bg-gold-400" style={{ animationDelay: "0.15s" }} />
                      <span className="inline-block h-2 w-0.5 animate-pulse bg-gold-400" style={{ animationDelay: "0.3s" }} />
                    </div>
                  )}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* مصدر الصوت */}
      <p className="mt-4 text-center text-[11px] text-slate-400">
        الصوت من cdn.islamic.network · جودة {toArabicDigits(reciter.bitrate)} kbps
      </p>

      {/* أنماط خاصة بشريط التقدم */}
      <style>{`
        .quran-range {
          -webkit-appearance: none;
          appearance: none;
          height: 6px;
          border-radius: 999px;
          background: linear-gradient(to left, #0f3d2e 0%, #0f3d2e ${duration ? (currentTime / duration) * 100 : 0}%, #dceee2 ${duration ? (currentTime / duration) * 100 : 0}%, #dceee2 100%);
          outline: none;
          direction: ltr;
        }
        .quran-range::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #0f3d2e;
          border: 2px solid #d4af37;
          cursor: pointer;
          box-shadow: 0 2px 6px rgba(0,0,0,0.15);
        }
        .quran-range::-moz-range-thumb {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #0f3d2e;
          border: 2px solid #d4af37;
          cursor: pointer;
        }
        .quran-range:disabled {
          opacity: 0.5;
        }
      `}</style>
    </div>
  );
}

function formatTime(seconds: number): string {
  if (!isFinite(seconds) || seconds < 0) return "٠٠:٠٠";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return toArabicDigits(`${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`);
}

// لتجنب تحذير TypeScript عن النوع غير المستخدم
void ({} as Reciter);
