// أنواع البيانات للقرآن الكريم (مطابقة لاستجابة AlQuran.cloud API)

export interface Ayah {
  /** الرقم العام للآية في المصحف (1 - 6236) */
  number: number;
  /** نص الآية بالرسم العثماني */
  text: string;
  /** رقم الآية داخل السورة */
  numberInSurah: number;
  /** رقم الجزء */
  juz: number;
  /** رقم الصفحة في المصحف */
  page: number;
  /** هل الآية سجدة؟ */
  sajda: boolean | { recommended?: boolean; obligatory?: boolean };
}

export interface Surah {
  /** رقم السورة (1 - 114) */
  number: number;
  /** اسم السورة بالعربية مع التشكيل */
  name: string;
  /** الاسم بالإنجليزية */
  englishName: string;
  /** ترجمة الاسم بالإنجليزية */
  englishNameTranslation: string;
  /** نوع الوحي: مكية أو مدنية */
  revelationType: "Meccan" | "Medinan";
  /** عدد الآيات */
  numberOfAyahs: number;
  /** قائمة الآيات */
  ayahs: Ayah[];
  /** اسم السورة العربي المبسّط (سنضيفه يدوياً) */
  simpleName?: string;
  /** فضل/وصف مختصر (اختياري) */
  description?: string;
}

export interface QuranData {
  /** بيانات السور الـ 114 */
  surahs: Surah[];
  /** إصدار النص (مثلاً: quran-uthmani) */
  edition: string;
  /** وقت التخزين (timestamp) */
  cachedAt: number;
}

export interface QuranSettings {
  /** حجم خط القراءة (بالبيكسل) */
  fontSize: number;
  /** الوضع الليلي */
  darkMode: boolean;
  /** آخر سورة قُرئت */
  lastSurah?: number;
  /** آخر آية قُرئت */
  lastAyah?: number;
}

export const DEFAULT_SETTINGS: QuranSettings = {
  fontSize: 28,
  darkMode: false,
};
