/**
 * خدمة جلب القرآن من AlQuran.cloud API.
 *
 * المصدر: https://alquran.cloud/api
 * النص: الرسم العثماني (quran-uthmani) من مشروع Tanzil/KFGQPC.
 * الترخيص: مفتوح ومجاني، يُسمح بالتخزين المحلي.
 */

import type { QuranData, Surah } from "@/types/quran";
import { getCachedQuran, saveQuran } from "./quranStorage";

const API_BASE = "https://api.alquran.cloud/v1";
const EDITION = "quran-uthmani";

/**
 * أسماء السور المبسّطة (بدون كلمة "سُورَةُ" وبلا تشكيل زائد) لعرضها في القوائم.
 * المصدر: الأسماء المعتمدة المتداولة للمصحف الشريف.
 */
export const SURAH_SIMPLE_NAMES: Record<number, string> = {
  1: "الفاتحة", 2: "البقرة", 3: "آل عمران", 4: "النساء", 5: "المائدة",
  6: "الأنعام", 7: "الأعراف", 8: "الأنفال", 9: "التوبة", 10: "يونس",
  11: "هود", 12: "يوسف", 13: "الرعد", 14: "إبراهيم", 15: "الحجر",
  16: "النحل", 17: "الإسراء", 18: "الكهف", 19: "مريم", 20: "طه",
  21: "الأنبياء", 22: "الحج", 23: "المؤمنون", 24: "النور", 25: "الفرقان",
  26: "الشعراء", 27: "النمل", 28: "القصص", 29: "العنكبوت", 30: "الروم",
  31: "لقمان", 32: "السجدة", 33: "الأحزاب", 34: "سبأ", 35: "فاطر",
  36: "يس", 37: "الصافات", 38: "ص", 39: "الزمر", 40: "غافر",
  41: "فصلت", 42: "الشورى", 43: "الزخرف", 44: "الدخان", 45: "الجاثية",
  46: "الأحقاف", 47: "محمد", 48: "الفتح", 49: "الحجرات", 50: "ق",
  51: "الذاريات", 52: "الطور", 53: "النجم", 54: "القمر", 55: "الرحمن",
  56: "الواقعة", 57: "الحديد", 58: "المجادلة", 59: "الحشر", 60: "الممتحنة",
  61: "الصف", 62: "الجمعة", 63: "المنافقون", 64: "التغابن", 65: "الطلاق",
  66: "التحريم", 67: "الملك", 68: "القلم", 69: "الحاقة", 70: "المعارج",
  71: "نوح", 72: "الجن", 73: "المزمل", 74: "المدثر", 75: "القيامة",
  76: "الإنسان", 77: "المرسلات", 78: "النبأ", 79: "النازعات", 80: "عبس",
  81: "التكوير", 82: "الانفطار", 83: "المطففين", 84: "الانشقاق", 85: "البروج",
  86: "الطارق", 87: "الأعلى", 88: "الغاشية", 89: "الفجر", 90: "البلد",
  91: "الشمس", 92: "الليل", 93: "الضحى", 94: "الشرح", 95: "التين",
  96: "العلق", 97: "القدر", 98: "البينة", 99: "الزلزلة", 100: "العاديات",
  101: "القارعة", 102: "التكاثر", 103: "العصر", 104: "الهمزة", 105: "الفيل",
  106: "قريش", 107: "الماعون", 108: "الكوثر", 109: "الكافرون", 110: "النصر",
  111: "المسد", 112: "الإخلاص", 113: "الفلق", 114: "الناس",
};

/** تطبيع النص: إزالة BOM الذي يُرجعه API في بداية الفاتحة */
function normalizeText(text: string): string {
  return text.replace(/^\uFEFF/, "").trim();
}

/** تصنيف السورة بالعربية */
export function revelationInArabic(type: string): string {
  return type === "Meccan" ? "مكية" : "مدنية";
}

export type ProgressCallback = (loaded: number, total: number) => void;

/**
 * يجلب القرآن كاملاً من API أو من الذاكرة المحلية.
 * - إذا كانت البيانات محفوظة محلياً: تُسترجع مباشرة.
 * - وإلا: تُنزَّل من API وتُحفظ محلياً للمستقبل.
 */
export async function loadQuran(
  onProgress?: ProgressCallback,
  forceRefresh = false
): Promise<QuranData> {
  // محاولة القراءة من الذاكرة المحلية أولاً
  if (!forceRefresh) {
    const cached = await getCachedQuran();
    if (cached) {
      onProgress?.(114, 114);
      return enrichSurahs(cached);
    }
  }

  // تنزيل النص الكامل دفعة واحدة من AlQuran.cloud API
  const url = `${API_BASE}/quran/${EDITION}`;
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(
      `تعذّر الاتصال بخادم القرآن (HTTP ${response.status}). تحقق من اتصالك بالإنترنت.`
    );
  }

  const json = await response.json();
  if (json.code !== 200 || !json.data?.surahs) {
    throw new Error("استجابة غير صالحة من خادم القرآن.");
  }

  const surahs: Surah[] = json.data.surahs.map((s: Surah) => ({
    ...s,
    ayahs: s.ayahs.map((a) => ({ ...a, text: normalizeText(a.text) })),
  }));

  // تحقق أساسي من السلامة: 114 سورة و 6236 آية
  const totalAyahs = surahs.reduce((sum, s) => sum + s.ayahs.length, 0);
  if (surahs.length !== 114) {
    throw new Error(
      `عدد السور المستلم (${surahs.length}) لا يساوي 114. تم رفض البيانات.`
    );
  }
  if (totalAyahs !== 6236) {
    throw new Error(
      `عدد الآيات المستلم (${totalAyahs}) لا يساوي 6236. تم رفض البيانات.`
    );
  }

  const data: QuranData = {
    surahs,
    edition: EDITION,
    cachedAt: Date.now(),
  };

  // نحفظ محلياً للاستخدام دون إنترنت
  try {
    await saveQuran(enrichSurahs(data));
  } catch (e) {
    console.warn("تعذّر حفظ القرآن محلياً:", e);
  }

  onProgress?.(114, 114);
  return enrichSurahs(data);
}

function enrichSurahs(data: QuranData): QuranData {
  return {
    ...data,
    surahs: data.surahs.map((s) => ({
      ...s,
      simpleName: SURAH_SIMPLE_NAMES[s.number] ?? s.englishName,
    })),
  };
}

/** جلب سورة واحدة فقط (للاستخدام السريع إذا كانت البيانات محفوظة) */
export async function getSurah(number: number): Promise<Surah | null> {
  const data = await getCachedQuran();
  if (!data) return null;
  return enrichSurahs(data).surahs.find((s) => s.number === number) ?? null;
}
