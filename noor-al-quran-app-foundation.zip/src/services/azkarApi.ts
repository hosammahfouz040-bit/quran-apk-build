/**
 * خدمة جلب الأذكار من hisnmuslim.com API.
 *
 * المصدر: https://www.hisnmuslim.com
 * كتاب: حصن المسلم - سعيد بن علي بن وهف القحطاني
 */

export interface Zikr {
  id: number;
  text: string;
  repeat: number;
  audio?: string;
}

export interface AzkarCategory {
  id: number;
  name: string;
  count: number;
}

/**
 * الفئات الرئيسية للأذكار.
 */
export const MAIN_AZKAR_CATEGORIES: AzkarCategory[] = [
  { id: 27, name: "أذكار الصباح والمساء", count: 24 },
  { id: 28, name: "أذكار النوم", count: 13 },
  { id: 1, name: "أذكار الاستيقاظ من النوم", count: 4 },
  { id: 25, name: "الأذكار بعد السلام من الصلاة", count: 8 },
];

/**
 * جميع الفئات المتاحة.
 */
export const ALL_AZKAR_CATEGORIES: AzkarCategory[] = [
  { id: 1, name: "أذكار الاستيقاظ من النوم", count: 4 },
  { id: 2, name: "دعاء لُبْس الثوب", count: 1 },
  { id: 3, name: "دعاء لُبْس الثوب الجديد", count: 1 },
  { id: 4, name: "الدعاء لمن لبس ثوبا جديدا", count: 2 },
  { id: 5, name: "ما يقول إذا وضع ثوبه", count: 1 },
  { id: 6, name: "دعاء دخول الخلاء", count: 1 },
  { id: 7, name: "دعاء الخروج من الخلاء", count: 1 },
  { id: 8, name: "الذكر قبل الوضوء", count: 1 },
  { id: 9, name: "الذكر بعد الفراغ من الوضوء", count: 3 },
  { id: 10, name: "الذكر عند الخروج من المنزل", count: 2 },
  { id: 11, name: "الذكر عند دخول المنزل", count: 1 },
  { id: 12, name: "دعاء الذهاب إلى المسجد", count: 1 },
  { id: 13, name: "دعاء دخول المسجد", count: 1 },
  { id: 14, name: "دعاء الخروج من المسجد", count: 1 },
  { id: 15, name: "أذكار الآذان", count: 5 },
  { id: 16, name: "دعاء الاستفتاح", count: 6 },
  { id: 17, name: "دعاء الركوع", count: 5 },
  { id: 18, name: "دعاء الرفع من الركوع", count: 3 },
  { id: 19, name: "دعاء السجود", count: 7 },
  { id: 20, name: "دعاء الجلسة بين السجدتين", count: 2 },
  { id: 21, name: "دعاء سجود التلاوة", count: 2 },
  { id: 22, name: "التشهد", count: 1 },
  { id: 23, name: "الصلاة على النبي بعد التشهد", count: 2 },
  { id: 24, name: "الدعاء بعد التشهد الأخير قبل السلام", count: 11 },
  { id: 25, name: "الأذكار بعد السلام من الصلاة", count: 8 },
  { id: 26, name: "دعاء صلاة الاستخارة", count: 1 },
  { id: 27, name: "أذكار الصباح والمساء", count: 24 },
  { id: 28, name: "أذكار النوم", count: 13 },
  { id: 29, name: "الدعاء إذا تقلب ليلا", count: 1 },
  { id: 30, name: "دعاء الفزع في النوم", count: 1 },
  { id: 31, name: "ما يفعل من رأى الرؤيا أو الحلم", count: 2 },
  { id: 32, name: "دعاء قنوت الوتر", count: 3 },
  { id: 33, name: "الذكر عقب السلام من الوتر", count: 1 },
  { id: 34, name: "دعاء الهم والحزن", count: 2 },
  { id: 35, name: "دعاء الكرب", count: 4 },
  { id: 36, name: "دعاء لقاء العدو وذي السلطان", count: 3 },
  { id: 37, name: "دعاء من خاف ظلم السلطان", count: 2 },
  { id: 38, name: "الدعاء على العدو", count: 1 },
  { id: 39, name: "ما يقول من خاف قوما", count: 1 },
  { id: 40, name: "دعاء من أصابه وسوسة في الإيمان", count: 3 },
  { id: 41, name: "دعاء قضاء الدين", count: 2 },
  { id: 42, name: "دعاء الوسوسة في الصلاة والقراءة", count: 1 },
  { id: 43, name: "دعاء من استصعب عليه أمر", count: 1 },
  { id: 44, name: "ما يقول ويفعل من أذنب ذنبا", count: 1 },
  { id: 45, name: "دعاء طرد الشيطان ووساوسه", count: 3 },
  { id: 46, name: "الدعاء حينما يقع ما لا يرضاه", count: 1 },
  { id: 47, name: "تهنئة المولود له وجوابه", count: 1 },
  { id: 48, name: "ما يعوذ به الأولاد", count: 1 },
  { id: 49, name: "الدعاء للمريض في عيادته", count: 2 },
  { id: 50, name: "فضل عيادة المريض", count: 1 },
  { id: 51, name: "دعاء المريض الذي يئس من حياته", count: 3 },
  { id: 52, name: "تلقين المحتضر", count: 1 },
  { id: 53, name: "دعاء من أصيب بمصيبة", count: 1 },
  { id: 54, name: "الدعاء عند إغماض الميت", count: 1 },
  { id: 55, name: "الدعاء للميت في الصلاة عليه", count: 4 },
  { id: 56, name: "الدعاء للفرط في الصلاة عليه", count: 2 },
  { id: 57, name: "دعاء التعزية", count: 1 },
  { id: 58, name: "الدعاء عند إدخال الميت القبر", count: 1 },
  { id: 59, name: "الدعاء بعد دفن الميت", count: 1 },
  { id: 60, name: "دعاء زيارة القبور", count: 1 },
  { id: 61, name: "دعاء الريح", count: 2 },
  { id: 62, name: "دعاء الرعد", count: 1 },
  { id: 63, name: "من أدعية الاستسقاء", count: 3 },
  { id: 64, name: "الدعاء إذا نزل المطر", count: 1 },
  { id: 65, name: "الذكر بعد نزول المطر", count: 1 },
  { id: 66, name: "من أدعية الاستصحاء", count: 1 },
  { id: 67, name: "دعاء رؤية الهلال", count: 1 },
  { id: 68, name: "الدعاء عند إفطار الصائم", count: 2 },
  { id: 69, name: "الدعاء قبل الطعام", count: 2 },
  { id: 70, name: "الدعاء عند الفراغ من الطعام", count: 2 },
];

/**
 * جلب الأذكار لفئة معينة.
 */
export async function getAzkarByCategory(categoryId: number): Promise<Zikr[]> {
  const url = `https://www.hisnmuslim.com/api/ar/${categoryId}.json`;
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`فشل في جلب الأذكار (HTTP ${response.status})`);
  }

  let text = await response.text();

  // إزالة BOM إذا كان موجوداً
  if (text.startsWith("\ufeff")) {
    text = text.substring(1);
  }

  const data = JSON.parse(text);

  // البيانات تأتي بصيغة { "اسم الفئة": [...] }
  const categoryKey = Object.keys(data)[0];
  const azkarList = data[categoryKey];

  if (!Array.isArray(azkarList)) {
    throw new Error("تنسيق البيانات غير صالح");
  }

  return azkarList.map((item: any) => ({
    id: item.ID,
    text: item.ARABIC_TEXT || "",
    repeat: item.REPEAT || 1,
    audio: item.AUDIO || undefined,
  }));
}

/**
 * حفظ تقدم المستخدم في الأذكار.
 */
const AZKAR_PROGRESS_KEY = "noor-azkar-progress";

export interface AzkarProgress {
  [categoryId: number]: {
    [zikrId: number]: number;
  };
}

export function saveAzkarProgress(
  categoryId: number,
  zikrId: number,
  count: number
): void {
  try {
    const existing = getAzkarProgress();
    if (!existing[categoryId]) {
      existing[categoryId] = {};
    }
    existing[categoryId][zikrId] = count;
    localStorage.setItem(AZKAR_PROGRESS_KEY, JSON.stringify(existing));
  } catch (e) {
    console.warn("فشل حفظ تقدم الأذكار:", e);
  }
}

export function getAzkarProgress(): AzkarProgress {
  try {
    const stored = localStorage.getItem(AZKAR_PROGRESS_KEY);
    return stored ? JSON.parse(stored) : {};
  } catch {
    return {};
  }
}

export function clearAzkarProgress(categoryId: number): void {
  try {
    const existing = getAzkarProgress();
    delete existing[categoryId];
    localStorage.setItem(AZKAR_PROGRESS_KEY, JSON.stringify(existing));
  } catch (e) {
    console.warn("فشل مسح تقدم الأذكار:", e);
  }
}
