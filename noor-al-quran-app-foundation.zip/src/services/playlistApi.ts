/**
 * خدمة قوائم التشغيل وتحسين تجربة الاستماع
 * 
 * تدير قوائم التشغيل، مؤقت النوم، السرعة، وحفظ آخر موضع
 */

export interface Playlist {
  id: string;
  name: string;
  items: PlaylistItem[];
  createdAt: string;
  lastPlayed?: string;
}

export interface PlaylistItem {
  reciterId: string;
  reciterName: string;
  surahNumber: number;
  surahName: string;
  addedAt: string;
}

export interface ListeningSession {
  reciterId: string;
  surahNumber: number;
  currentTime: number;
  duration: number;
  timestamp: string;
}

export interface PlaybackSettings {
  speed: number; // 0.5, 0.75, 1, 1.25, 1.5, 2
  repeatMode: "none" | "one" | "all";
  shuffle: boolean;
  sleepTimer: number | null; // دقائق أو null
}

const PLAYLISTS_KEY = "noor-playlists";
const LAST_SESSION_KEY = "noor-last-session";
const PLAYBACK_SETTINGS_KEY = "noor-playback-settings";
const FAVORITE_RECITERS_KEY = "noor-favorite-reciters";

/**
 * جلب جميع قوائم التشغيل
 */
export function getPlaylists(): Playlist[] {
  try {
    const stored = localStorage.getItem(PLAYLISTS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    console.error("فشل تحميل قوائم التشغيل:", e);
    return [];
  }
}

/**
 * حفظ قائمة تشغيل
 */
export function savePlaylist(playlist: Playlist): void {
  try {
    const playlists = getPlaylists();
    const index = playlists.findIndex((p) => p.id === playlist.id);
    
    if (index >= 0) {
      playlists[index] = playlist;
    } else {
      playlists.push(playlist);
    }
    
    localStorage.setItem(PLAYLISTS_KEY, JSON.stringify(playlists));
  } catch (e) {
    console.error("فشل حفظ قائمة التشغيل:", e);
  }
}

/**
 * حذف قائمة تشغيل
 */
export function deletePlaylist(playlistId: string): void {
  try {
    const playlists = getPlaylists().filter((p) => p.id !== playlistId);
    localStorage.setItem(PLAYLISTS_KEY, JSON.stringify(playlists));
  } catch (e) {
    console.error("فشل حذف قائمة التشغيل:", e);
  }
}

/**
 * إنشاء قائمة تشغيل جديدة
 */
export function createPlaylist(name: string): Playlist {
  const playlist: Playlist = {
    id: `playlist-${Date.now()}`,
    name,
    items: [],
    createdAt: new Date().toISOString(),
  };
  
  savePlaylist(playlist);
  return playlist;
}

/**
 * إضافة عنصر لقائمة التشغيل
 */
export function addToPlaylist(
  playlistId: string,
  reciterId: string,
  reciterName: string,
  surahNumber: number,
  surahName: string
): void {
  const playlist = getPlaylists().find((p) => p.id === playlistId);
  if (!playlist) return;
  
  playlist.items.push({
    reciterId,
    reciterName,
    surahNumber,
    surahName,
    addedAt: new Date().toISOString(),
  });
  
  savePlaylist(playlist);
}

/**
 * إزالة عنصر من قائمة التشغيل
 */
export function removeFromPlaylist(playlistId: string, itemIndex: number): void {
  const playlist = getPlaylists().find((p) => p.id === playlistId);
  if (!playlist) return;
  
  playlist.items.splice(itemIndex, 1);
  savePlaylist(playlist);
}

/**
 * حفظ آخر جلسة استماع
 */
export function saveLastSession(session: ListeningSession): void {
  try {
    localStorage.setItem(LAST_SESSION_KEY, JSON.stringify(session));
  } catch (e) {
    console.error("فشل حفظ الجلسة:", e);
  }
}

/**
 * جلب آخر جلسة استماع
 */
export function getLastSession(): ListeningSession | null {
  try {
    const stored = localStorage.getItem(LAST_SESSION_KEY);
    return stored ? JSON.parse(stored) : null;
  } catch (e) {
    console.error("فشل تحميل الجلسة:", e);
    return null;
  }
}

/**
 * حفظ إعدادات التشغيل
 */
export function savePlaybackSettings(settings: PlaybackSettings): void {
  try {
    localStorage.setItem(PLAYBACK_SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error("فشل حفظ الإعدادات:", e);
  }
}

/**
 * جلب إعدادات التشغيل
 */
export function getPlaybackSettings(): PlaybackSettings {
  try {
    const stored = localStorage.getItem(PLAYBACK_SETTINGS_KEY);
    return stored
      ? JSON.parse(stored)
      : {
          speed: 1,
          repeatMode: "none",
          shuffle: false,
          sleepTimer: null,
        };
  } catch (e) {
    console.error("فشل تحميل الإعدادات:", e);
    return {
      speed: 1,
      repeatMode: "none",
      shuffle: false,
      sleepTimer: null,
    };
  }
}

/**
 * حفظ القراء المفضلين
 */
export function saveFavoriteReciter(reciterId: string, surahNumber?: number): void {
  try {
    const stored = localStorage.getItem(FAVORITE_RECITERS_KEY);
    const favorites: Record<string, string> = stored ? JSON.parse(stored) : {};
    
    if (surahNumber !== undefined) {
      favorites[`surah-${surahNumber}`] = reciterId;
    } else {
      favorites["default"] = reciterId;
    }
    
    localStorage.setItem(FAVORITE_RECITERS_KEY, JSON.stringify(favorites));
  } catch (e) {
    console.error("فشل حفظ القارئ المفضل:", e);
  }
}

/**
 * جلب القارئ المفضل
 */
export function getFavoriteReciter(surahNumber?: number): string | null {
  try {
    const stored = localStorage.getItem(FAVORITE_RECITERS_KEY);
    const favorites: Record<string, string> = stored ? JSON.parse(stored) : {};
    
    if (surahNumber !== undefined) {
      return favorites[`surah-${surahNumber}`] || favorites["default"] || null;
    }
    
    return favorites["default"] || null;
  } catch (e) {
    console.error("فشل تحميل القارئ المفضل:", e);
    return null;
  }
}

/**
 * حساب الوقت المتبقي لمؤقت النوم
 */
export function calculateSleepTimerRemaining(
  sleepTimerMinutes: number,
  startTime: Date
): number {
  const elapsed = (Date.now() - startTime.getTime()) / 1000 / 60; // بالدقائق
  return Math.max(0, sleepTimerMinutes - elapsed);
}

/**
 * خلط قائمة التشغيل
 */
export function shufflePlaylist(items: PlaylistItem[]): PlaylistItem[] {
  const shuffled = [...items];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}
