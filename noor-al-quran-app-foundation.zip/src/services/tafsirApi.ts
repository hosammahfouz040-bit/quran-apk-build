/**
 * خدمة جلب التفسير من AlQuran.cloud API.
 *
 * المصدر: https://alquran.cloud/api
 * التفاسير المتاحة:
 *  - ar.muyassar: التفسير الميسر (مجموعة من العلماء)
 *  - ar.jalalayn: تفسير الجلالين (السيوطي والمحلي)
 *  - ar.qurtubi: تفسير القرطبي
 *  - ar.baghawi: تفسير البغوي
 *  - ar.waseet: التفسير الوسيط (طنطاوي)
 *  - ar.miqbas: تنوير المقباس (ابن عباس)
 */

export interface TafsirEdition {
  id: string;
  name: string;
  description: string;
}

export const TAFSIR_EDITIONS: TafsirEdition[] = [
  {
    id: "ar.muyassar",
    name: "التفسير الميسر",
    description: "مجموعة من العلماء - تفسير مختصر وواضح",
  },
  {
    id: "ar.jalalayn",
    name: "تفسير الجلالين",
    description: "السيوطي والمحلي - تفسير موجز",
  },
  {
    id: "ar.qurtubi",
    name: "تفسير القرطبي",
    description: "الجامع لأحكام القرآن",
  },
  {
    id: "ar.baghawi",
    name: "تفسير البغوي",
    description: "معالم التنزيل",
  },
  {
    id: "ar.waseet",
    name: "التفسير الوسيط",
    description: "طنطاوي - تفسير متوسط",
  },
];

export interface TafsirAyah {
  number: number;
  numberInSurah: number;
  text: string;
}

/**
 * جلب تفسير سورة كاملة.
 */
export async function getSurahTafsir(
  surahNumber: number,
  edition: string = "ar.muyassar"
): Promise<TafsirAyah[]> {
  const url = `https://api.alquran.cloud/v1/surah/${surahNumber}/${edition}`;
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`فشل في جلب التفسير (HTTP ${response.status})`);
  }

  const data = await response.json();

  if (data.code !== 200 || !data.data?.ayahs) {
    throw new Error("استجابة غير صالحة من خادم التفسير");
  }

  return data.data.ayahs.map((ayah: any) => ({
    number: ayah.number,
    numberInSurah: ayah.numberInSurah,
    text: ayah.text,
  }));
}

/**
 * جلب تفسير آية واحدة.
 */
export async function getAyahTafsir(
  surahNumber: number,
  ayahNumber: number,
  edition: string = "ar.muyassar"
): Promise<string> {
  const url = `https://api.alquran.cloud/v1/ayah/${surahNumber}:${ayahNumber}/${edition}`;
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`فشل في جلب التفسير (HTTP ${response.status})`);
  }

  const data = await response.json();

  if (data.code !== 200 || !data.data?.text) {
    throw new Error("استجابة غير صالحة من خادم التفسير");
  }

  return data.data.text;
}
