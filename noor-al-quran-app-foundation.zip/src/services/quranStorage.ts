/**
 * خدمة تخزين القرآن محلياً باستخدام IndexedDB.
 *IndexedDB يدعم لحجم البيانات (النص القرآني ~2 MB).
 */

import type { QuranData } from "@/types/quran";

const DB_NAME = "noor-quran-db";
const DB_VERSION = 1;
const STORE_NAME = "quran";
const QURAN_KEY = "quran-uthmani-full";

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB غير مدعوم في هذا المتصفح"));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
  });
}

export async function getCachedQuran(): Promise<QuranData | null> {
  try {
    const db = await openDB();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readonly");
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(QURAN_KEY);
      req.onsuccess = () => resolve((req.result as QuranData) ?? null);
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    console.warn("تعذّر قراءة البيانات المحفوظة:", e);
    return null;
  }
}

export async function saveQuran(data: QuranData): Promise<void> {
  const db = await openDB();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    const req = store.put(data, QURAN_KEY);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function clearQuran(): Promise<void> {
  const db = await openDB();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const req = tx.objectStore(STORE_NAME).clear();
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}
