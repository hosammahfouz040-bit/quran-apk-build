/**
 * خدمة الأذان - تشغيل الأذان وجدولة التنبيهات.
 * 
 * المصادر:
 * - AlAdhan.com CDN: https://cdn.aladhan.com/audio/adhan/
 * - Internet Archive: https://archive.org/details/adhans_sunnah
 * - Assabile: https://www.assabile.com/adhan-call-prayer
 */

export interface AdhanAudio {
  id: string;
  name: string;
  nameAr: string;
  url: string;
  fajrUrl?: string; // أذان الفجر المختلف (يحتوي على "الصلاة خير من النوم")
  duration: number; // بالدقائق
  source: string;
  country?: string;
}

export interface AdhanSettings {
  enabled: boolean;
  selectedAdhanId: string;
  fajrAdhanId?: string; // أذان مختلف للفجر
  volume: number; // 0-1
  notifications: {
    [prayer: string]: {
      enabled: boolean;
      playAdhan: boolean;
    };
  };
}

const ADHAN_SETTINGS_KEY = "noor-adhan-settings";

/**
 * قائمة الأذانات المتاحة من مصادر موثوقة.
 */
export const AVAILABLE_ADHANS: AdhanAudio[] = [
  {
    id: "alafasy_nice",
    name: "Mishary Alafasy - Nice Version",
    nameAr: "مشاري العفاسي - نسخة جميلة",
    url: "https://archive.org/download/adhans_sunnah/Athan_alafasi_nice.mp3",
    duration: 3.5,
    source: "Internet Archive",
    country: "الكويت",
  },
  {
    id: "mishary",
    name: "Mishary Rashid Alafasy",
    nameAr: "مشاري راشد العفاسي",
    url: "https://archive.org/download/adhans_sunnah/adhan_mishari.mp3",
    duration: 4,
    source: "Internet Archive",
    country: "الكويت",
  },
  {
    id: "abdul_baset",
    name: "Abdul Basit Abdul Samad",
    nameAr: "عبد الباسط عبد الصمد",
    url: "https://archive.org/download/adhans_sunnah/adhan_abdul_baset.mp3",
    duration: 4,
    source: "Internet Archive",
    country: "مصر",
  },
  {
    id: "nasser_al_qatami",
    name: "Nasser Al Qatami",
    nameAr: "ناصر القطامي",
    url: "https://archive.org/download/adhans_sunnah/adhan_nasser_al_qatami.mp3",
    duration: 3.5,
    source: "Internet Archive",
    country: "السعودية",
  },
  {
    id: "islam_sobhi",
    name: "Islam Sobhi",
    nameAr: "إسلام صبحي",
    url: "https://archive.org/download/adhans_sunnah/islam_sobhi.mp3",
    duration: 3.5,
    source: "Internet Archive",
    country: "مصر",
  },
  {
    id: "salman_utaybi",
    name: "Salman Utaybi",
    nameAr: "سلمان العتيبي",
    url: "https://archive.org/download/adhans_sunnah/salman_utaybi.mp3",
    duration: 3.5,
    source: "Internet Archive",
    country: "السعودية",
  },
];

/**
 * الحصول على الإعدادات المحفوظة.
 */
export function getAdhanSettings(): AdhanSettings {
  try {
    const stored = localStorage.getItem(ADHAN_SETTINGS_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.warn("فشل تحميل إعدادات الأذان:", e);
  }

  // الإعدادات الافتراضية
  return {
    enabled: false,
    selectedAdhanId: "makkah",
    volume: 0.8,
    notifications: {
      Fajr: { enabled: false, playAdhan: true },
      Dhuhr: { enabled: false, playAdhan: true },
      Asr: { enabled: false, playAdhan: true },
      Maghrib: { enabled: false, playAdhan: true },
      Isha: { enabled: false, playAdhan: true },
    },
  };
}

/**
 * حفظ الإعدادات.
 */
export function saveAdhanSettings(settings: AdhanSettings): void {
  try {
    localStorage.setItem(ADHAN_SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.warn("فشل حفظ إعدادات الأذان:", e);
  }
}

/**
 * الحصول على ملف الأذان المناسب.
 */
export function getAdhanAudio(
  adhanId: string,
  isFajr: boolean = false
): AdhanAudio | null {
  const adhan = AVAILABLE_ADHANS.find((a) => a.id === adhanId);
  if (!adhan) return null;

  // إذا كان فجر ويوجد أذان فجر مختلف، استخدمه
  if (isFajr && adhan.fajrUrl) {
    return {
      ...adhan,
      url: adhan.fajrUrl,
    };
  }

  return adhan;
}

/**
 * تشغيل الأذان.
 */
export async function playAdhan(
  adhanId: string,
  isFajr: boolean = false,
  volume: number = 0.8
): Promise<HTMLAudioElement> {
  const adhan = getAdhanAudio(adhanId, isFajr);
  if (!adhan) {
    throw new Error("ملف الأذان غير موجود");
  }

  const audio = new Audio(adhan.url);
  audio.volume = volume;
  audio.preload = "auto";

  return new Promise((resolve, reject) => {
    audio.oncanplay = () => {
      audio.play().then(() => resolve(audio)).catch(reject);
    };
    audio.onerror = () => reject(new Error("فشل تحميل ملف الأذان"));
  });
}

/**
 * اختبار الأذان (تشغيل قصير).
 */
export async function testAdhan(
  adhanId: string,
  isFajr: boolean = false,
  duration: number = 10 // ثواني
): Promise<void> {
  const audio = await playAdhan(adhanId, isFajr, 0.5);
  
  // إيقاف بعد المدة المحددة
  setTimeout(() => {
    audio.pause();
    audio.currentTime = 0;
  }, duration * 1000);
}

/**
 * حساب الوقت المتبقي للصلاة التالية بالمللي ثانية.
 */
export function getTimeUntilPrayerMs(prayerTime: string): number {
  const now = new Date();
  const [hours, minutes] = prayerTime.split(":").map((n) => parseInt(n, 10));
  const target = new Date();
  target.setHours(hours, minutes, 0, 0);

  // إذا كانت الصلاة في اليوم التالي
  if (target <= now) {
    target.setDate(target.getDate() + 1);
  }

  return target.getTime() - now.getTime();
}

/**
 * جدولة الأذان التلقائي.
 * ملاحظة: هذا يعمل فقط عندما يكون التطبيق مفتوحاً.
 * للعمل في الخلفية، يحتاج إلى Service Worker (PWA).
 */
export function scheduleAdhan(
  prayerTime: string,
  adhanId: string,
  isFajr: boolean,
  volume: number,
  callback?: () => void
): number {
  const timeUntil = getTimeUntilPrayerMs(prayerTime);
  
  if (timeUntil <= 0) {
    console.warn("وقت الصلاة قد فات");
    return -1;
  }

  console.log(`جدولة الأذان بعد ${Math.round(timeUntil / 1000 / 60)} دقيقة`);

  const timeoutId = window.setTimeout(async () => {
    try {
      await playAdhan(adhanId, isFajr, volume);
      callback?.();
    } catch (e) {
      console.error("فشل تشغيل الأذان:", e);
    }
  }, timeUntil);

  return timeoutId;
}

/**
 * إلغاء الأذان المجدول.
 */
export function cancelScheduledAdhan(timeoutId: number): void {
  if (timeoutId > 0) {
    window.clearTimeout(timeoutId);
    console.log("تم إلغاء الأذان المجدول");
  }
}

/**
 * طلب إذن الإشعارات.
 */
export async function requestNotificationPermission(): Promise<boolean> {
  if (!("Notification" in window)) {
    console.warn("الإشعارات غير مدعومة في هذا المتصفح");
    return false;
  }

  if (Notification.permission === "granted") {
    return true;
  }

  if (Notification.permission === "denied") {
    console.warn("تم رفض إذن الإشعارات سابقاً");
    return false;
  }

  const permission = await Notification.requestPermission();
  return permission === "granted";
}

/**
 * إرسال إشعار.
 */
export function sendNotification(title: string, body: string): void {
  if (!("Notification" in window)) {
    return;
  }

  if (Notification.permission === "granted") {
    new Notification(title, {
      body,
      icon: "/favicon.ico",
      badge: "/favicon.ico",
      tag: "adhan-notification",
    });
  }
}

/**
 * التحقق من قيود Android.
 */
export function checkAndroidRestrictions(): {
  isAndroid: boolean;
  hasBatteryOptimization: boolean;
  hasBackgroundRestriction: boolean;
  warning: string | null;
} {
  const userAgent = navigator.userAgent.toLowerCase();
  const isAndroid = userAgent.includes("android");
  
  // فحص عام (لا يمكن التحقق بدقة من المتصفح)
  const hasBatteryOptimization = isAndroid;
  const hasBackgroundRestriction = isAndroid;

  let warning: string | null = null;
  
  if (isAndroid) {
    warning = "قد يتأثر التشغيل التلقائي للأذان بوضع توفير البطارية أو قيود النظام. يُنصح بإضافة التطبيق إلى القائمة البيضاء في إعدادات البطارية.";
  }

  return {
    isAndroid,
    hasBatteryOptimization,
    hasBackgroundRestriction,
    warning,
  };
}
