/**
 * خدمة خطة ختم القرآن
 * 
 * تدير خطط ختم القرآن مع تقسيم الورد اليومي
 */

export interface CompletionPlan {
  id: string;
  name: string;
  startDate: string;
  targetDate: string;
  durationDays: number;
  dailyPages: number;
  currentPage: number;
  totalPages: number; // 604 صفحات المصحف المدني
  status: "active" | "completed" | "paused";
  createdAt: string;
  lastUpdated: string;
  pausedDays: number;
}

const COMPLETION_PLANS_KEY = "noor-completion-plans";

/**
 * جلب جميع خطط الختم
 */
export function getCompletionPlans(): CompletionPlan[] {
  try {
    const stored = localStorage.getItem(COMPLETION_PLANS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    console.error("فشل تحميل خطط الختم:", e);
    return [];
  }
}

/**
 * حفظ خطة ختم
 */
export function saveCompletionPlan(plan: CompletionPlan): void {
  try {
    const plans = getCompletionPlans();
    const index = plans.findIndex((p) => p.id === plan.id);
    
    if (index >= 0) {
      plans[index] = { ...plan, lastUpdated: new Date().toISOString() };
    } else {
      plans.push({ ...plan, lastUpdated: new Date().toISOString() });
    }
    
    localStorage.setItem(COMPLETION_PLANS_KEY, JSON.stringify(plans));
  } catch (e) {
    console.error("فشل حفظ خطة الختم:", e);
  }
}

/**
 * حذف خطة ختم
 */
export function deleteCompletionPlan(planId: string): void {
  try {
    const plans = getCompletionPlans().filter((p) => p.id !== planId);
    localStorage.setItem(COMPLETION_PLANS_KEY, JSON.stringify(plans));
  } catch (e) {
    console.error("فشل حذف خطة الختم:", e);
  }
}

/**
 * إنشاء خطة ختم جديدة
 */
export function createCompletionPlan(
  name: string,
  durationDays: number
): CompletionPlan {
  const id = `completion-${Date.now()}`;
  const now = new Date();
  const startDate = now.toISOString().split("T")[0];
  
  const targetDate = new Date(now);
  targetDate.setDate(targetDate.getDate() + durationDays);
  
  const totalPages = 604; // صفحات المصحف المدني
  const dailyPages = Math.ceil(totalPages / durationDays);
  
  const plan: CompletionPlan = {
    id,
    name,
    startDate,
    targetDate: targetDate.toISOString().split("T")[0],
    durationDays,
    dailyPages,
    currentPage: 0,
    totalPages,
    status: "active",
    createdAt: now.toISOString(),
    lastUpdated: now.toISOString(),
    pausedDays: 0,
  };
  
  saveCompletionPlan(plan);
  return plan;
}

/**
 * تحديث الصفحة الحالية
 */
export function updateCurrentPage(planId: string, newPage: number): void {
  try {
    const plans = getCompletionPlans();
    const plan = plans.find((p) => p.id === planId);
    
    if (!plan) return;
    
    plan.currentPage = Math.max(0, Math.min(newPage, plan.totalPages));
    
    if (plan.currentPage >= plan.totalPages) {
      plan.status = "completed";
    }
    
    saveCompletionPlan(plan);
  } catch (e) {
    console.error("فشل تحديث الصفحة:", e);
  }
}

/**
 * إيقاف/استئناف الخطة
 */
export function togglePlanStatus(planId: string): void {
  try {
    const plans = getCompletionPlans();
    const plan = plans.find((p) => p.id === planId);
    
    if (!plan || plan.status === "completed") return;
    
    if (plan.status === "active") {
      plan.status = "paused";
    } else {
      plan.status = "active";
    }
    
    saveCompletionPlan(plan);
  } catch (e) {
    console.error("فشل تغيير حالة الخطة:", e);
  }
}

/**
 * حساب نسبة الإنجاز
 */
export function calculateCompletionProgress(plan: CompletionPlan): number {
  return Math.round((plan.currentPage / plan.totalPages) * 100);
}

/**
 * حساب الصفحات المتبقية
 */
export function getRemainingPages(plan: CompletionPlan): number {
  return Math.max(0, plan.totalPages - plan.currentPage);
}

/**
 * حساب الأيام المتبقية
 */
export function getRemainingDays(plan: CompletionPlan): number {
  if (plan.status === "completed") return 0;
  
  const today = new Date();
  const target = new Date(plan.targetDate);
  const diff = target.getTime() - today.getTime();
  
  return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
}

/**
 * إعادة توزيع الورد عند التأخر
 */
export function redistributeDailyPages(planId: string): void {
  try {
    const plans = getCompletionPlans();
    const plan = plans.find((p) => p.id === planId);
    
    if (!plan || plan.status === "completed") return;
    
    const remainingDays = getRemainingDays(plan);
    const remainingPages = getRemainingPages(plan);
    
    if (remainingDays > 0 && remainingPages > 0) {
      plan.dailyPages = Math.ceil(remainingPages / remainingDays);
      saveCompletionPlan(plan);
    }
  } catch (e) {
    console.error("فشل إعادة التوزيع:", e);
  }
}

/**
 * الحصول على رقم السورة من رقم الصفحة
 */
export function getPageSurah(pageNumber: number): {
  surahNumber: number;
  surahName: string;
} {
  // خريطة مبسطة لصفحات المصحف المدني
  // في الواقع يجب استخدام خريطة كاملة
  const pageToSurah: Record<number, number> = {
    1: 1, // الفاتحة
    2: 2, // البقرة
    50: 2, // البقرة
    51: 3, // آل عمران
    77: 3,
    78: 4, // النساء
    107: 4,
    108: 5, // المائدة
    128: 5,
    129: 6, // الأنعام
    151: 6,
    152: 7, // الأعراف
    177: 7,
    178: 8, // الأنفال
    187: 8,
    188: 9, // التوبة
    208: 9,
    209: 10, // يونس
    222: 10,
    223: 11, // هود
    236: 11,
    237: 12, // يوسف
    249: 12,
    250: 13, // الرعد
    256: 13,
    257: 14, // إبراهيم
    262: 14,
    263: 15, // الحجر
    267: 15,
    268: 16, // النحل
    282: 16,
    283: 17, // الإسراء
    294: 17,
    295: 18, // الكهف
    305: 18,
    306: 19, // مريم
    313: 19,
    314: 20, // طه
    322: 20,
    323: 21, // الأنبياء
    332: 21,
    333: 22, // الحج
    342: 22,
    343: 23, // المؤمنون
    350: 23,
    351: 24, // النور
    359: 24,
    360: 25, // الفرقان
    367: 25,
    368: 26, // الشعراء
    377: 26,
    378: 27, // النمل
    386: 27,
    387: 28, // القصص
    396: 28,
    397: 29, // العنكبوت
    404: 29,
    405: 30, // الروم
    411: 30,
    412: 31, // لقمان
    415: 31,
    416: 32, // السجدة
    418: 32,
    419: 33, // الأحزاب
    428: 33,
    429: 34, // سبأ
    435: 34,
    436: 35, // فاطر
    441: 35,
    442: 36, // يس
    446: 36,
    447: 37, // الصافات
    453: 37,
    454: 38, // ص
    459: 38,
    460: 39, // الزمر
    468: 39,
    469: 40, // غافر
    477: 40,
    478: 41, // فصلت
    483: 41,
    484: 42, // الشورى
    490: 42,
    491: 43, // الزخرف
    496: 43,
    497: 44, // الدخان
    500: 44,
    501: 45, // الجاثية
    503: 45,
    504: 46, // الأحقاف
    507: 46,
    508: 47, // محمد
    511: 47,
    512: 48, // الفتح
    516: 48,
    517: 49, // الحجرات
    518: 49,
    519: 50, // ق
    521: 50,
    522: 51, // الذاريات
    524: 51,
    525: 52, // الطور
    527: 52,
    528: 53, // النجم
    530: 53,
    531: 54, // القمر
    533: 54,
    534: 55, // الرحمن
    537: 55,
    538: 56, // الواقعة
    541: 56,
    542: 57, // الحديد
    545: 57,
    546: 58, // المجادلة
    549: 58,
    550: 59, // الحشر
    552: 59,
    553: 60, // الممتحنة
    555: 60,
    556: 61, // الصف
    557: 61,
    558: 62, // الجمعة
    559: 62,
    560: 63, // المنافقون
    561: 63,
    562: 64, // التغابن
    563: 64,
    564: 65, // الطلاق
    566: 65,
    567: 66, // التحريم
    568: 66,
    569: 67, // الملك
    571: 67,
    572: 68, // القلم
    574: 68,
    575: 69, // الحاقة
    577: 69,
    578: 70, // المعارج
    580: 70,
    581: 71, // نوح
    582: 71,
    583: 72, // الجن
    585: 72,
    586: 73, // المزمل
    587: 73,
    588: 74, // المدثر
    590: 74,
    591: 75, // القيامة
    592: 75,
    593: 76, // الإنسان
    594: 76,
    595: 77, // المرسلات
    596: 77,
    597: 78, // النبأ
    598: 78,
    599: 79, // النازعات
    600: 79,
    601: 80, // عبس
    602: 80,
    603: 81, // التكوير
    604: 82, // الانفطار
  };
  
  // البحث عن أقرب صفحة
  let surahNumber = 1;
  const pages = Object.keys(pageToSurah).map(Number).sort((a, b) => a - b);
  
  for (const page of pages) {
    if (page <= pageNumber) {
      surahNumber = pageToSurah[page];
    } else {
      break;
    }
  }
  
  // أسماء السور (مبسطة)
  const surahNames: Record<number, string> = {
    1: "الفاتحة", 2: "البقرة", 3: "آل عمران", 4: "النساء", 5: "المائدة",
    6: "الأنعام", 7: "الأعراف", 8: "الأنفال", 9: "التوبة", 10: "يونس",
    11: "هود", 12: "يوسف", 13: "الرعد", 14: "إبراهيم", 15: "الحجر",
    16: "النحل", 17: "الإسراء", 18: "الكهف", 19: "مريم", 20: "طه",
    21: "الأنبياء", 22: "الحج", 23: "المؤمنون", 24: "النور", 25: "الفرقان",
    26: "الشعراء", 27: "النمل", 28: "القصص", 29: "العنكبوت", 30: "الروم",
    31: "لقمان", 32: "السجدة", 33: "الأحزاب", 34: "سبأ", 35: "فاطر",
    36: "يس", 37: "الصافات", 38: "ص", 39: "الزمر", 40: "غافر",
    41: "فصلت", 42: "الشورى", 43: "الزخرف", 44: "الدخان", 45: "الجاثية",
    46: "الأحقاف", 47: "محمد", 48: "الفتح", 49: "الحجرات", 50: "ق",
    51: "الذاريات", 52: "الطور", 53: "النجم", 54: "القمر", 55: "الرحمن",
    56: "الواقعة", 57: "الحديد", 58: "المجادلة", 59: "الحشر", 60: "الممتحنة",
    61: "الصف", 62: "الجمعة", 63: "المنافقون", 64: "التغابن", 65: "الطلاق",
    66: "التحريم", 67: "الملك", 68: "القلم", 69: "الحاقة", 70: "المعارج",
    71: "نوح", 72: "الجن", 73: "المزمل", 74: "المدثر", 75: "القيامة",
    76: "الإنسان", 77: "المرسلات", 78: "النبأ", 79: "النازعات", 80: "عبس",
    81: "التكوير", 82: "الانفطار",
  };
  
  return {
    surahNumber,
    surahName: surahNames[surahNumber] || `سورة ${surahNumber}`,
  };
}
