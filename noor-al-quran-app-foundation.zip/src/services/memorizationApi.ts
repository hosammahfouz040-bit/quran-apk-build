/**
 * خدمة حفظ القرآن والمراجعة
 * 
 * تدير خطط الحفظ والمراجعة والتقدم اليومي
 */

export interface MemorizationPlan {
  id: string;
  name: string;
  startDate: string;
  surahs: MemorizationSurah[];
  dailyGoal: number; // عدد الآيات يومياً
  createdAt: string;
  lastUpdated: string;
}

export interface MemorizationSurah {
  surahNumber: number;
  surahName: string;
  verses: MemorizationVerse[];
  status: "not-started" | "in-progress" | "completed";
}

export interface MemorizationVerse {
  verseNumber: number;
  status: "not-started" | "memorized" | "reviewed" | "needs-review";
  lastReviewed?: string;
  reviewCount: number;
}

export interface ReviewSession {
  id: string;
  date: string;
  surahNumber: number;
  verses: number[];
  score: number; // 0-100
  duration: number; // بالدقائق
}

export interface DailyProgress {
  date: string;
  versesMemorized: number;
  versesReviewed: number;
  reviewSessions: number;
  achievement: number; // 0-100
}

const MEMORIZATION_PLANS_KEY = "noor-memorization-plans";
const REVIEW_SESSIONS_KEY = "noor-review-sessions";
const DAILY_PROGRESS_KEY = "noor-daily-progress";

/**
 * جلب جميع خطط الحفظ
 */
export function getMemorizationPlans(): MemorizationPlan[] {
  try {
    const stored = localStorage.getItem(MEMORIZATION_PLANS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    console.error("فشل تحميل خطط الحفظ:", e);
    return [];
  }
}

/**
 * حفظ خطة حفظ
 */
export function saveMemorizationPlan(plan: MemorizationPlan): void {
  try {
    const plans = getMemorizationPlans();
    const index = plans.findIndex((p) => p.id === plan.id);
    
    if (index >= 0) {
      plans[index] = { ...plan, lastUpdated: new Date().toISOString() };
    } else {
      plans.push({ ...plan, lastUpdated: new Date().toISOString() });
    }
    
    localStorage.setItem(MEMORIZATION_PLANS_KEY, JSON.stringify(plans));
  } catch (e) {
    console.error("فشل حفظ خطة الحفظ:", e);
  }
}

/**
 * حذف خطة حفظ
 */
export function deleteMemorizationPlan(planId: string): void {
  try {
    const plans = getMemorizationPlans().filter((p) => p.id !== planId);
    localStorage.setItem(MEMORIZATION_PLANS_KEY, JSON.stringify(plans));
  } catch (e) {
    console.error("فشل حذف خطة الحفظ:", e);
  }
}

/**
 * إنشاء خطة حفظ جديدة
 */
export function createMemorizationPlan(
  name: string,
  surahs: number[],
  dailyGoal: number
): MemorizationPlan {
  const id = `plan-${Date.now()}`;
  const now = new Date().toISOString();
  
  const plan: MemorizationPlan = {
    id,
    name,
    startDate: now.split("T")[0],
    surahs: surahs.map((num) => ({
      surahNumber: num,
      surahName: "", // سيتم ملؤه لاحقاً
      verses: [],
      status: "not-started",
    })),
    dailyGoal,
    createdAt: now,
    lastUpdated: now,
  };
  
  saveMemorizationPlan(plan);
  return plan;
}

/**
 * تحديث حالة آية
 */
export function updateVerseStatus(
  planId: string,
  surahNumber: number,
  verseNumber: number,
  status: MemorizationVerse["status"]
): void {
  try {
    const plans = getMemorizationPlans();
    const plan = plans.find((p) => p.id === planId);
    
    if (!plan) return;
    
    const surah = plan.surahs.find((s) => s.surahNumber === surahNumber);
    if (!surah) return;
    
    let verse = surah.verses.find((v) => v.verseNumber === verseNumber);
    
    if (!verse) {
      verse = {
        verseNumber,
        status,
        reviewCount: 0,
      };
      surah.verses.push(verse);
    } else {
      verse.status = status;
      if (status === "reviewed") {
        verse.reviewCount++;
        verse.lastReviewed = new Date().toISOString();
      }
    }
    
    // تحديث حالة السورة
    const totalVerses = surah.verses.length;
    const completedVerses = surah.verses.filter(
      (v) => v.status === "memorized" || v.status === "reviewed"
    ).length;
    
    if (completedVerses === 0) {
      surah.status = "not-started";
    } else if (completedVerses === totalVerses) {
      surah.status = "completed";
    } else {
      surah.status = "in-progress";
    }
    
    saveMemorizationPlan(plan);
  } catch (e) {
    console.error("فشل تحديث حالة الآية:", e);
  }
}

/**
 * جلب جلسات المراجعة
 */
export function getReviewSessions(): ReviewSession[] {
  try {
    const stored = localStorage.getItem(REVIEW_SESSIONS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    console.error("فشل تحميل جلسات المراجعة:", e);
    return [];
  }
}

/**
 * حفظ جلسة مراجعة
 */
export function saveReviewSession(session: ReviewSession): void {
  try {
    const sessions = getReviewSessions();
    sessions.push(session);
    localStorage.setItem(REVIEW_SESSIONS_KEY, JSON.stringify(sessions));
  } catch (e) {
    console.error("فشل حفظ جلسة المراجعة:", e);
  }
}

/**
 * جلب التقدم اليومي
 */
export function getDailyProgress(): DailyProgress[] {
  try {
    const stored = localStorage.getItem(DAILY_PROGRESS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    console.error("فشل تحميل التقدم اليومي:", e);
    return [];
  }
}

/**
 * حفظ التقدم اليومي
 */
export function saveDailyProgress(progress: DailyProgress): void {
  try {
    const allProgress = getDailyProgress();
    const index = allProgress.findIndex((p) => p.date === progress.date);
    
    if (index >= 0) {
      allProgress[index] = progress;
    } else {
      allProgress.push(progress);
    }
    
    localStorage.setItem(DAILY_PROGRESS_KEY, JSON.stringify(allProgress));
  } catch (e) {
    console.error("فشل حفظ التقدم اليومي:", e);
  }
}

/**
 * حساب نسبة الإنجاز لخطة حفظ
 */
export function calculatePlanProgress(plan: MemorizationPlan): number {
  if (plan.surahs.length === 0) return 0;
  
  let totalVerses = 0;
  let completedVerses = 0;
  
  plan.surahs.forEach((surah) => {
    totalVerses += surah.verses.length;
    completedVerses += surah.verses.filter(
      (v) => v.status === "memorized" || v.status === "reviewed"
    ).length;
  });
  
  return totalVerses > 0 ? Math.round((completedVerses / totalVerses) * 100) : 0;
}

/**
 * الحصول على الآيات التي تحتاج مراجعة
 */
export function getVersesNeedingReview(planId: string): {
  surahNumber: number;
  verseNumber: number;
}[] {
  const plan = getMemorizationPlans().find((p) => p.id === planId);
  if (!plan) return [];
  
  const verses: { surahNumber: number; verseNumber: number }[] = [];
  
  plan.surahs.forEach((surah) => {
    surah.verses.forEach((verse) => {
      if (verse.status === "needs-review") {
        verses.push({
          surahNumber: surah.surahNumber,
          verseNumber: verse.verseNumber,
        });
      }
    });
  });
  
  return verses;
}

/**
 * إنشاء اختبار مراجعة عشوائي
 */
export function createReviewTest(
  planId: string,
  questionCount: number = 5
): {
  surahNumber: number;
  verseNumber: number;
  verseText: string;
}[] {
  const verses = getVersesNeedingReview(planId);
  if (verses.length === 0) return [];
  
  // اختيار عشوائي
  const shuffled = [...verses].sort(() => Math.random() - 0.5);
  const selected = shuffled.slice(0, Math.min(questionCount, verses.length));
  
  // سيتم ملء النص لاحقاً من QuranAPI
  return selected.map((v) => ({
    ...v,
    verseText: "", // سيتم ملؤه
  }));
}
