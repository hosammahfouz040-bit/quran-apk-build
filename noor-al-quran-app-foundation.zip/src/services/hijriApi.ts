/**
 * خدمة التقويم الهجري
 * 
 * توفر التاريخ الهجري والمناسبات الإسلامية
 */

export interface HijriDate {
  day: number;
  month: number;
  monthName: string;
  monthNameAr: string;
  year: number;
  dayOfWeek: string;
  dayOfWeekAr: string;
}

export interface IslamicEvent {
  id: string;
  name: string;
  nameAr: string;
  hijriDate: string; // DD-MM
  gregorianDate?: string;
  description?: string;
  descriptionAr?: string;
  type: "major" | "minor" | "optional";
}

const HIJRI_MONTHS_AR = [
  "محرم",
  "صفر",
  "ربيع الأول",
  "ربيع الآخر",
  "جمادى الأولى",
  "جمادى الآخرة",
  "رجب",
  "شعبان",
  "رمضان",
  "شوال",
  "ذو القعدة",
  "ذو الحجة",
];

const HIJRI_MONTHS_EN = [
  "Muharram",
  "Safar",
  "Rabi' al-Awwal",
  "Rabi' al-Thani",
  "Jumada al-Ula",
  "Jumada al-Thani",
  "Rajab",
  "Sha'ban",
  "Ramadan",
  "Shawwal",
  "Dhu al-Qi'dah",
  "Dhu al-Hijjah",
];

const WEEKDAYS_AR = [
  "الأحد",
  "الاثنين",
  "الثلاثاء",
  "الأربعاء",
  "الخميس",
  "الجمعة",
  "السبت",
];

const WEEKDAYS_EN = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

/**
 * تحويل التاريخ الميلادي إلى هجري (خوارزمية تقريبية)
 */
export function gregorianToHijri(date: Date): HijriDate {
  const jd = gregorianToJD(date.getFullYear(), date.getMonth() + 1, date.getDate());
  const hijri = jdToHijri(jd);
  
  return {
    day: hijri.day,
    month: hijri.month,
    monthName: HIJRI_MONTHS_EN[hijri.month - 1],
    monthNameAr: HIJRI_MONTHS_AR[hijri.month - 1],
    year: hijri.year,
    dayOfWeek: WEEKDAYS_EN[date.getDay()],
    dayOfWeekAr: WEEKDAYS_AR[date.getDay()],
  };
}

/**
 * تحويل التاريخ الهجري إلى ميلادي (خوارزمية تقريبية)
 */
export function hijriToGregorian(
  year: number,
  month: number,
  day: number
): Date {
  const jd = hijriToJD(year, month, day);
  const gregorian = jdToGregorian(jd);
  
  return new Date(gregorian.year, gregorian.month - 1, gregorian.day);
}

/**
 * تحويل ميلادي إلى يوليوسي
 */
function gregorianToJD(year: number, month: number, day: number): number {
  if (month <= 2) {
    year -= 1;
    month += 12;
  }
  
  const A = Math.floor(year / 100);
  const B = 2 - A + Math.floor(A / 4);
  
  return (
    Math.floor(365.25 * (year + 4716)) +
    Math.floor(30.6001 * (month + 1)) +
    day +
    B -
    1524.5
  );
}

/**
 * تحويل يوليوسي إلى هجري
 */
function jdToHijri(jd: number): { day: number; month: number; year: number } {
  const l = Math.floor(jd - 1948439.5) + 10632;
  const n = Math.floor((l - 1) / 10631);
  const l2 = l - 10631 * n + 354;
  const j =
    Math.floor((10985 - l2) / 5316) * Math.floor((50 * l2) / 17719) +
    Math.floor(l2 / 5670) * Math.floor((43 * l2) / 15238);
  const l3 =
    l2 -
    Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) -
    Math.floor(j / 16) * Math.floor((15238 * j) / 43) +
    29;
  const month = Math.floor((24 * l3) / 709);
  const day = l3 - Math.floor((709 * month) / 24);
  const year = 30 * n + j - 30;
  
  return { day, month, year };
}

/**
 * تحويل هجري إلى يوليوسي
 */
function hijriToJD(year: number, month: number, day: number): number {
  return (
    Math.floor((11 * year + 3) / 30) +
    354 * year +
    30 * month -
    Math.floor((month - 1) / 2) +
    day +
    1948440 -
    385
  );
}

/**
 * تحويل يوليوسي إلى ميلادي
 */
function jdToGregorian(jd: number): {
  year: number;
  month: number;
  day: number;
} {
  const z = Math.floor(jd + 0.5);
  const a = Math.floor((z - 1867216.25) / 36524.25);
  const a2 = z + 1 + a - Math.floor(a / 4);
  const b = a2 + 1524;
  const c = Math.floor((b - 122.1) / 365.25);
  const d = Math.floor(365.25 * c);
  const e = Math.floor((b - d) / 30.6001);
  
  const day = b - d - Math.floor(30.6001 * e);
  const month = e < 14 ? e - 1 : e - 13;
  const year = month > 2 ? c - 4716 : c - 4715;
  
  return { year, month, day };
}

/**
 * المناسبات الإسلامية الثابتة
 */
export const ISLAMIC_EVENTS: IslamicEvent[] = [
  {
    id: "muharram-1",
    name: "Islamic New Year",
    nameAr: "رأس السنة الهجرية",
    hijriDate: "01-01",
    descriptionAr: "بداية العام الهجري الجديد",
    type: "major",
  },
  {
    id: "muharram-10",
    name: "Day of Ashura",
    nameAr: "يوم عاشوراء",
    hijriDate: "10-01",
    descriptionAr: "اليوم العاشر من محرم، يستحب صيامه",
    type: "major",
  },
  {
    id: "rabi1-12",
    name: "Mawlid al-Nabi",
    nameAr: "المولد النبوي الشريف",
    hijriDate: "12-03",
    descriptionAr: "ذكرى مولد النبي محمد صلى الله عليه وسلم",
    type: "major",
  },
  {
    id: "rajab-27",
    name: "Isra and Mi'raj",
    nameAr: "الإسراء والمعراج",
    hijriDate: "27-07",
    descriptionAr: "ذكرى الإسراء والمعراج",
    type: "major",
  },
  {
    id: "shaaban-15",
    name: "Laylat al-Bara'at",
    nameAr: "ليلة النصف من شعبان",
    hijriDate: "15-08",
    descriptionAr: "ليلة النصف من شعبان",
    type: "minor",
  },
  {
    id: "ramadan-1",
    name: "Start of Ramadan",
    nameAr: "بداية شهر رمضان المبارك",
    hijriDate: "01-09",
    descriptionAr: "بداية شهر الصيام",
    type: "major",
  },
  {
    id: "ramadan-27",
    name: "Laylat al-Qadr",
    nameAr: "ليلة القدر",
    hijriDate: "27-09",
    descriptionAr: "ليلة القدر خير من ألف شهر (تاريخ تقديري)",
    type: "major",
  },
  {
    id: "shawwal-1",
    name: "Eid al-Fitr",
    nameAr: "عيد الفطر المبارك",
    hijriDate: "01-10",
    descriptionAr: "عيد الفطر المبارك",
    type: "major",
  },
  {
    id: "dhulhijjah-9",
    name: "Day of Arafah",
    nameAr: "يوم عرفة",
    hijriDate: "09-12",
    descriptionAr: "يوم الوقوف بعرفة، يستحب صيامه لغير الحاج",
    type: "major",
  },
  {
    id: "dhulhijjah-10",
    name: "Eid al-Adha",
    nameAr: "عيد الأضحى المبارك",
    hijriDate: "10-12",
    descriptionAr: "عيد الأضحى المبارك",
    type: "major",
  },
];

/**
 * جلب المناسبات الإسلامية
 */
export function getIslamicEvents(): IslamicEvent[] {
  return ISLAMIC_EVENTS;
}

/**
 * جلب المناسبات القادمة
 */
export function getUpcomingEvents(
  currentDate: Date = new Date(),
  limit: number = 5
): IslamicEvent[] {
  const currentHijri = gregorianToHijri(currentDate);
  const currentHijriDate = `${String(currentHijri.day).padStart(2, "0")}-${String(
    currentHijri.month
  ).padStart(2, "0")}`;
  
  return ISLAMIC_EVENTS
    .filter((event) => event.hijriDate >= currentHijriDate)
    .sort((a, b) => a.hijriDate.localeCompare(b.hijriDate))
    .slice(0, limit);
}

/**
 * حفظ تعديل فرق اليوم الهجري
 */
const HIJRI_OFFSET_KEY = "noor-hijri-offset";

export function saveHijriOffset(offset: number): void {
  try {
    localStorage.setItem(HIJRI_OFFSET_KEY, String(offset));
  } catch (e) {
    console.error("فشل حفظ فرق اليوم:", e);
  }
}

export function getHijriOffset(): number {
  try {
    const stored = localStorage.getItem(HIJRI_OFFSET_KEY);
    return stored ? parseInt(stored, 10) : 0;
  } catch (e) {
    console.error("فشل تحميل فرق اليوم:", e);
    return 0;
  }
}

/**
 * جلب التاريخ الهجري مع التعديل
 */
export function getAdjustedHijriDate(date: Date = new Date()): HijriDate {
  const offset = getHijriOffset();
  const adjustedDate = new Date(date);
  adjustedDate.setDate(adjustedDate.getDate() + offset);
  
  return gregorianToHijri(adjustedDate);
}
