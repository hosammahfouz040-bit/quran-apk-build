/**
 * خدمة جلب مواقيت الصلاة من AlAdhan API.
 *
 * المصدر: https://aladhan.com/prayer-times-api
 * API مجاني ومفتوح بدون مفتاح.
 * يوفر مواقيت دقيقة لجميع أنحاء العالم.
 */

export interface PrayerTimesData {
  timings: {
    Fajr: string;
    Sunrise: string;
    Dhuhr: string;
    Asr: string;
    Maghrib: string;
    Isha: string;
    Midnight?: string;
  };
  date: {
    readable: string;
    hijri: {
      date: string;
      day: string;
      month: { number: number; en: string; ar: string };
      year: string;
    };
    gregorian: {
      date: string;
      day: string;
      month: { number: number; en: string; ar: string };
      year: string;
    };
  };
  meta: {
    timezone: string;
    method: { id: number; name: string };
  };
}

export interface LocationInfo {
  city: string;
  country: string;
  latitude: number;
  longitude: number;
}

/**
 * طرق حساب المواقيت المتاحة.
 */
export const CALCULATION_METHODS = [
  { id: 0, name: "الشيعة الإثنا عشرية - لواء", region: "العراق" },
  { id: 1, name: "جامعة العلوم الإسلامية - كراتشي", region: "باكستان والهند" },
  { id: 2, name: "الجمعية الإسلامية لأمريكا الشمالية (ISNA)", region: "أمريكا الشمالية" },
  { id: 3, name: "رابطة العالم الإسلامي", region: "أوروبا وأمريكا" },
  { id: 4, name: "أم القرى - مكة المكرمة", region: "السعودية" },
  { id: 5, name: "الهيئة المصرية العامة للمساحة", region: "مصر وأفريقيا" },
  { id: 6, name: "معهد الأبحاث الفلكية - مصر", region: "مصر" },
  { id: 7, name: "خليج (90 دقيقة بعد الغروب)", region: "الخليج" },
  { id: 8, name: "خليج (120 دقيقة بعد الغروب)", region: "الخليج" },
  { id: 9, name: "الكويت", region: "الكويت" },
  { id: 10, name: "قطر", region: "قطر" },
  { id: 11, name: "سنغافورة", region: "سنغافورة" },
  { id: 12, name: "فرنسا (UOIF)", region: "فرنسا" },
  { id: 13, name: "تركيا - رئاسة الشؤون الدينية", region: "تركيا" },
  { id: 14, name: "روسيا", region: "روسيا" },
  { id: 15, name: "دبي", region: "الإمارات" },
];

/**
 * أسماء الصلوات بالعربية.
 */
export const PRAYER_NAMES: Record<string, string> = {
  Fajr: "الفجر",
  Sunrise: "الشروق",
  Dhuhr: "الظهر",
  Asr: "العصر",
  Maghrib: "المغرب",
  Isha: "العشاء",
  Midnight: "منتصف الليل",
};

/**
 * المدن الرئيسية في العالم العربي مع إحداثياتها.
 */
export const POPULAR_CITIES: LocationInfo[] = [
  { city: "مكة المكرمة", country: "السعودية", latitude: 21.4225, longitude: 39.8262 },
  { city: "المدينة المنورة", country: "السعودية", latitude: 24.4672, longitude: 39.6112 },
  { city: "الرياض", country: "السعودية", latitude: 24.7136, longitude: 46.6753 },
  { city: "جدة", country: "السعودية", latitude: 21.5433, longitude: 39.1728 },
  { city: "القاهرة", country: "مصر", latitude: 30.0444, longitude: 31.2357 },
  { city: "الإسكندرية", country: "مصر", latitude: 31.2001, longitude: 29.9187 },
  { city: "دبي", country: "الإمارات", latitude: 25.2048, longitude: 55.2708 },
  { city: "أبو ظبي", country: "الإمارات", latitude: 24.4539, longitude: 54.3773 },
  { city: "الكويت", country: "الكويت", latitude: 29.3759, longitude: 47.9774 },
  { city: "الدوحة", country: "قطر", latitude: 25.2854, longitude: 51.5310 },
  { city: "المنامة", country: "البحرين", latitude: 26.2285, longitude: 50.5860 },
  { city: "مسقط", country: "عُمان", latitude: 23.5880, longitude: 58.3829 },
  { city: "عمّان", country: "الأردن", latitude: 31.9454, longitude: 35.9284 },
  { city: "بيروت", country: "لبنان", latitude: 33.8938, longitude: 35.5018 },
  { city: "دمشق", country: "سوريا", latitude: 33.5138, longitude: 36.2765 },
  { city: "بغداد", country: "العراق", latitude: 33.3128, longitude: 44.3615 },
  { city: "القدس", country: "فلسطين", latitude: 31.7683, longitude: 35.2137 },
  { city: "الخرطوم", country: "السودان", latitude: 15.5007, longitude: 32.5599 },
  { city: "الجزائر", country: "الجزائر", latitude: 36.7538, longitude: 3.0588 },
  { city: "الرباط", country: "المغرب", latitude: 33.9716, longitude: -6.8498 },
  { city: "تونس", country: "تونس", latitude: 36.8065, longitude: 10.1815 },
  { city: "طرابلس", country: "ليبيا", latitude: 32.9017, longitude: 13.1800 },
  { city: "صنعاء", country: "اليمن", latitude: 15.3694, longitude: 44.1910 },
];

/**
 * جلب مواقيت الصلاة حسب المدينة.
 */
export async function getPrayerTimesByCity(
  city: string,
  country: string,
  method: number = 5
): Promise<PrayerTimesData> {
  const date = new Date();
  const dateStr = `${date.getDate()}-${date.getMonth() + 1}-${date.getFullYear()}`;
  const url = `https://api.aladhan.com/v1/timingsByCity/${dateStr}?city=${encodeURIComponent(city)}&country=${encodeURIComponent(country)}&method=${method}`;

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`فشل في جلب مواقيت الصلاة (HTTP ${response.status})`);
  }

  const data = await response.json();
  if (data.code !== 200 || !data.data) {
    throw new Error("استجابة غير صالحة من خادم المواقيت");
  }

  return data.data;
}

/**
 * جلب مواقيت الصلاة حسب الإحداثيات.
 */
export async function getPrayerTimesByCoordinates(
  latitude: number,
  longitude: number,
  method: number = 5
): Promise<PrayerTimesData> {
  const date = new Date();
  const dateStr = `${date.getDate()}-${date.getMonth() + 1}-${date.getFullYear()}`;
  const url = `https://api.aladhan.com/v1/timings/${dateStr}?latitude=${latitude}&longitude=${longitude}&method=${method}`;

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`فشل في جلب مواقيت الصلاة (HTTP ${response.status})`);
  }

  const data = await response.json();
  if (data.code !== 200 || !data.data) {
    throw new Error("استجابة غير صالحة من خادم المواقيت");
  }

  return data.data;
}

/**
 * الحصول على الموقع الحالي من المتصفح.
 */
export function getCurrentLocation(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("الموقع الجغرافي غير مدعوم في هذا المتصفح"));
      return;
    }
    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 600000,
    });
  });
}

/**
 * حفظ الموقع المفضل في localStorage.
 */
const PRAYER_LOCATION_KEY = "noor-prayer-location";
const PRAYER_METHOD_KEY = "noor-prayer-method";

export function savePreferredLocation(location: LocationInfo): void {
  try {
    localStorage.setItem(PRAYER_LOCATION_KEY, JSON.stringify(location));
  } catch (e) {
    console.warn("فشل حفظ الموقع:", e);
  }
}

export function getPreferredLocation(): LocationInfo | null {
  try {
    const stored = localStorage.getItem(PRAYER_LOCATION_KEY);
    return stored ? JSON.parse(stored) : null;
  } catch {
    return null;
  }
}

export function savePreferredMethod(method: number): void {
  try {
    localStorage.setItem(PRAYER_METHOD_KEY, String(method));
  } catch (e) {
    console.warn("فشل حفظ طريقة الحساب:", e);
  }
}

export function getPreferredMethod(): number {
  try {
    const stored = localStorage.getItem(PRAYER_METHOD_KEY);
    return stored ? parseInt(stored, 10) : 5;
  } catch {
    return 5;
  }
}

/**
 * حساب الصلاة التالية.
 */
export function getNextPrayer(timings: PrayerTimesData["timings"]): {
  name: string;
  time: string;
  nameAr: string;
} | null {
  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  const prayers = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"] as const;

  for (const prayer of prayers) {
    const time = timings[prayer];
    if (!time) continue;
    const [hours, minutes] = time.split(":").map((n) => parseInt(n, 10));
    const prayerMinutes = hours * 60 + minutes;

    if (prayerMinutes > currentMinutes) {
      return {
        name: prayer,
        time,
        nameAr: PRAYER_NAMES[prayer],
      };
    }
  }

  // إذا فاتت جميع الصلوات، الصلاة التالية هي فجر اليوم التالي
  return {
    name: "Fajr",
    time: timings.Fajr,
    nameAr: PRAYER_NAMES["Fajr"],
  };
}

/**
 * حساب الوقت المتبقي للصلاة التالية.
 */
export function getTimeUntilPrayer(prayerTime: string): string {
  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const [hours, minutes] = prayerTime.split(":").map((n) => parseInt(n, 10));
  let prayerMinutes = hours * 60 + minutes;

  // إذا كانت الصلاة في اليوم التالي
  if (prayerMinutes <= currentMinutes) {
    prayerMinutes += 24 * 60;
  }

  const diff = prayerMinutes - currentMinutes;
  const h = Math.floor(diff / 60);
  const m = diff % 60;

  if (h > 0) {
    return `${h} ساعة و ${m} دقيقة`;
  }
  return `${m} دقيقة`;
}
