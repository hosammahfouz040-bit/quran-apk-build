/**
 * خدمة القبلة
 * 
 * تحسب اتجاه القبلة بناءً على الموقع الجغرافي
 */

export interface QiblaResult {
  direction: number; // درجة من الشمال (0-360)
  distance: number; // المسافة بالكيلومتر
  locationName: string;
  latitude: number;
  longitude: number;
}

// إحداثيات الكعبة المشرفة
const KAABA_LATITUDE = 21.4225;
const KAABA_LONGITUDE = 39.8262;

/**
 * حساب اتجاه القبلة من موقع معين
 */
export function calculateQiblaDirection(
  latitude: number,
  longitude: number
): QiblaResult {
  // تحويل الدرجات إلى راديان
  const lat1 = toRadians(latitude);
  const lon1 = toRadians(longitude);
  const lat2 = toRadians(KAABA_LATITUDE);
  const lon2 = toRadians(KAABA_LONGITUDE);

  // حساب الفرق في الطول
  const dLon = lon2 - lon1;

  // حساب اتجاه القبلة باستخدام صيغة المجال العظيم
  const y = Math.sin(dLon) * Math.cos(lat2);
  const x =
    Math.cos(lat1) * Math.sin(lat2) -
    Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);

  let direction = Math.atan2(y, x);
  direction = toDegrees(direction);

  // تحويل إلى 0-360
  direction = (direction + 360) % 360;

  // حساب المسافة
  const R = 6371; // نصف قطر الأرض بالكيلومتر
  const dLat = lat2 - lat1;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;

  return {
    direction,
    distance,
    locationName: "موقعك الحالي",
    latitude,
    longitude,
  };
}

/**
 * تحويل الدرجات إلى راديان
 */
function toRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}

/**
 * تحويل الراديان إلى درجات
 */
function toDegrees(radians: number): number {
  return radians * (180 / Math.PI);
}

/**
 * الحصول على الموقع الحالي
 */
export function getCurrentLocation(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("الموقع الجغرافي غير مدعوم في هذا المتصفح"));
      return;
    }

    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 600000, // 10 دقائق
    });
  });
}

/**
 * حفظ الموقع المفضل
 */
const QIBLA_LOCATION_KEY = "noor-qibla-location";

export interface SavedLocation {
  latitude: number;
  longitude: number;
  name: string;
}

export function saveQiblaLocation(location: SavedLocation): void {
  try {
    localStorage.setItem(QIBLA_LOCATION_KEY, JSON.stringify(location));
  } catch (e) {
    console.error("فشل حفظ الموقع:", e);
  }
}

export function getSavedQiblaLocation(): SavedLocation | null {
  try {
    const stored = localStorage.getItem(QIBLA_LOCATION_KEY);
    return stored ? JSON.parse(stored) : null;
  } catch (e) {
    console.error("فشل تحميل الموقع:", e);
    return null;
  }
}

/**
 * المدن الرئيسية مع إحداثياتها
 */
export const POPULAR_CITIES: SavedLocation[] = [
  { name: "مكة المكرمة", latitude: 21.4225, longitude: 39.8262 },
  { name: "المدينة المنورة", latitude: 24.4672, longitude: 39.6112 },
  { name: "القاهرة", latitude: 30.0444, longitude: 31.2357 },
  { name: "الرياض", latitude: 24.7136, longitude: 46.6753 },
  { name: "دبي", latitude: 25.2048, longitude: 55.2708 },
  { name: "الكويت", latitude: 29.3759, longitude: 47.9774 },
  { name: "الدوحة", latitude: 25.2854, longitude: 51.5310 },
  { name: "المنامة", latitude: 26.2285, longitude: 50.5860 },
  { name: "مسقط", latitude: 23.5880, longitude: 58.3829 },
  { name: "عمّان", latitude: 31.9454, longitude: 35.9284 },
  { name: "بيروت", latitude: 33.8938, longitude: 35.5018 },
  { name: "دمشق", latitude: 33.5138, longitude: 36.2765 },
  { name: "بغداد", latitude: 33.3128, longitude: 44.3615 },
  { name: "القدس", latitude: 31.7683, longitude: 35.2137 },
  { name: "الخرطوم", latitude: 15.5007, longitude: 32.5599 },
  { name: "الجزائر", latitude: 36.7538, longitude: 3.0588 },
  { name: "الرباط", latitude: 33.9716, longitude: -6.8498 },
  { name: "تونس", latitude: 36.8065, longitude: 10.1815 },
  { name: "طرابلس", latitude: 32.9017, longitude: 13.1800 },
  { name: "صنعاء", latitude: 15.3694, longitude: 44.1910 },
  { name: "إسطنبول", latitude: 41.0082, longitude: 28.9784 },
  { name: "جاكرتا", latitude: -6.2088, longitude: 106.8456 },
  { name: "كوالالمبور", latitude: 3.1390, longitude: 101.6869 },
  { name: "لندن", latitude: 51.5074, longitude: -0.1278 },
  { name: "باريس", latitude: 48.8566, longitude: 2.3522 },
  { name: "نيويورك", latitude: 40.7128, longitude: -74.0060 },
  { name: "لوس أنجلوس", latitude: 34.0522, longitude: -118.2437 },
];

/**
 * الحصول على اسم الاتجاه بالبوصلة
 */
export function getCompassDirection(degrees: number): string {
  const directions = [
    "شمال",
    "شمال شرق",
    "شرق",
    "جنوب شرق",
    "جنوب",
    "جنوب غرب",
    "غرب",
    "شمال غرب",
  ];
  const index = Math.round(degrees / 45) % 8;
  return directions[index];
}
