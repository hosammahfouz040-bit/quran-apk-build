/**
 * خدمة تنزيل التلاوات وإدارة الملفات الصوتية
 * 
 * تدير تنزيل وحذف الملفات الصوتية للاستخدام دون إنترنت
 */

export interface DownloadedFile {
  id: string;
  reciterId: string;
  reciterName: string;
  surahNumber: number;
  surahName: string;
  url: string;
  localPath: string;
  size: number; // بالبايت
  downloadedAt: string;
  status: "completed" | "failed" | "downloading";
}

export interface DownloadProgress {
  reciterId: string;
  surahNumber: number;
  progress: number; // 0-100
  status: "downloading" | "completed" | "failed";
}

const DOWNLOADED_FILES_KEY = "noor-downloaded-files";

/**
 * جلب جميع الملفات المحملة
 */
export function getDownloadedFiles(): DownloadedFile[] {
  try {
    const stored = localStorage.getItem(DOWNLOADED_FILES_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    console.error("فشل تحميل قائمة الملفات:", e);
    return [];
  }
}

/**
 * حفظ ملف محمل
 */
export function saveDownloadedFile(file: DownloadedFile): void {
  try {
    const files = getDownloadedFiles();
    const index = files.findIndex(
      (f) =>
        f.reciterId === file.reciterId && f.surahNumber === file.surahNumber
    );

    if (index >= 0) {
      files[index] = file;
    } else {
      files.push(file);
    }

    localStorage.setItem(DOWNLOADED_FILES_KEY, JSON.stringify(files));
  } catch (e) {
    console.error("فشل حفظ الملف:", e);
  }
}

/**
 * حذف ملف محمل
 */
export function deleteDownloadedFile(
  reciterId: string,
  surahNumber: number
): void {
  try {
    const files = getDownloadedFiles().filter(
      (f) =>
        !(f.reciterId === reciterId && f.surahNumber === surahNumber)
    );
    localStorage.setItem(DOWNLOADED_FILES_KEY, JSON.stringify(files));
  } catch (e) {
    console.error("فشل حذف الملف:", e);
  }
}

/**
 * التحقق من وجود ملف محمل
 */
export function isFileDownloaded(
  reciterId: string,
  surahNumber: number
): boolean {
  const files = getDownloadedFiles();
  return files.some(
    (f) =>
      f.reciterId === reciterId &&
      f.surahNumber === surahNumber &&
      f.status === "completed"
  );
}

/**
 * جلب ملف محمل
 */
export function getDownloadedFile(
  reciterId: string,
  surahNumber: number
): DownloadedFile | null {
  const files = getDownloadedFiles();
  return (
    files.find(
      (f) =>
        f.reciterId === reciterId &&
        f.surahNumber === surahNumber &&
        f.status === "completed"
    ) || null
  );
}

/**
 * حساب الحجم الإجمالي للملفات المحملة
 */
export function getTotalDownloadedSize(): number {
  const files = getDownloadedFiles();
  return files.reduce((total, file) => total + file.size, 0);
}

/**
 * جلب الملفات المحملة لقارئ معين
 */
export function getDownloadedFilesByReciter(
  reciterId: string
): DownloadedFile[] {
  return getDownloadedFiles().filter((f) => f.reciterId === reciterId);
}

/**
 * جلب الملفات المحملة لسورة معينة
 */
export function getDownloadedFilesBySurah(
  surahNumber: number
): DownloadedFile[] {
  return getDownloadedFiles().filter((f) => f.surahNumber === surahNumber);
}

/**
 * حذف جميع الملفات المحملة
 */
export function deleteAllDownloadedFiles(): void {
  try {
    localStorage.removeItem(DOWNLOADED_FILES_KEY);
  } catch (e) {
    console.error("فشل حذف جميع الملفات:", e);
  }
}

/**
 * تنزيل ملف (محاكاة - في الواقع يحتاج Service Worker)
 * 
 * ملاحظة: التنزيل الفعلي للملفات الصوتية يتطلب:
 * 1. Service Worker للعمل في الخلفية
 * 2. Cache API أو IndexedDB للتخزين
 * 3. إذن التخزين من المستخدم
 * 
 * هذه الدالة هي نموذج أولي وتحتاج تطوير إضافي
 */
export async function downloadFile(
  url: string,
  reciterId: string,
  reciterName: string,
  surahNumber: number,
  surahName: string
): Promise<DownloadedFile> {
  // محاكاة التنزيل
  // في الواقع يجب استخدام fetch مع ReadableStream
  const response = await fetch(url);
  
  if (!response.ok) {
    throw new Error(`فشل التنزيل: ${response.status}`);
  }

  const blob = await response.blob();
  const size = blob.size;

  // حفظ في IndexedDB (مبسط)
  // في الواقع يجب استخدام IndexedDB بدلاً من localStorage للملفات الكبيرة
  const localPath = `blob:${url}`;

  const file: DownloadedFile = {
    id: `${reciterId}-${surahNumber}`,
    reciterId,
    reciterName,
    surahNumber,
    surahName,
    url,
    localPath,
    size,
    downloadedAt: new Date().toISOString(),
    status: "completed",
  };

  saveDownloadedFile(file);

  return file;
}

/**
 * جلب URL محلي لملف محمل
 */
export function getLocalAudioUrl(
  reciterId: string,
  surahNumber: number
): string | null {
  const file = getDownloadedFile(reciterId, surahNumber);
  return file ? file.localPath : null;
}

/**
 * تنسيق الحجم (بايت إلى MB/GB)
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 B";
  
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
}
