import { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { icons, sections } from "@/data/sections";

export default function Header() {
  const location = useLocation();

  // تمرير الصفحة لأعلى عند تغيير المسار لتحسين تجربة المستخدم
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, [location.pathname]);

  const current = sections.find((s) => location.pathname.startsWith(s.path));
  const isHome = location.pathname === "/";
  const showBack = !isHome && location.pathname !== "/menu";

  return (
    <header className="sticky top-0 z-30 border-b border-brand-900/20 bg-brand-900/95 text-white backdrop-blur-md">
      <div className="mx-auto flex max-w-md items-center justify-between gap-3 px-4 py-3">
        {/* الجهة اليمنى: زر الرجوع أو الشعار */}
        <div className="flex items-center gap-2 min-w-0">
          {showBack ? (
            <Link
              to="/"
              className="tap-highlight flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-gold-300 hover:bg-white/20"
              aria-label="الرجوع للرئيسية"
            >
              {icons.back}
            </Link>
          ) : (
            <Link
              to="/"
              className="tap-highlight flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-gold-400 to-gold-600 text-brand-900 shadow-md shadow-black/20"
              aria-label="نور القرآن"
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2 L14 8.5 L21 9.3 L15.8 13.8 L17.4 20.7 L12 17.2 L6.6 20.7 L8.2 13.8 L3 9.3 L10 8.5 Z" />
              </svg>
            </Link>
          )}
          <div className="min-w-0">
            <h1 className="truncate text-base font-extrabold leading-tight tracking-tight">
              {isHome ? "نور القرآن" : current?.title ?? "نور القرآن"}
            </h1>
            <p className="truncate text-[11px] font-medium text-gold-300/90">
              {isHome ? "تطبيقك الإسلامي الشامل" : current?.subtitle ?? ""}
            </p>
          </div>
        </div>

        {/* الجهة اليسرى: شعار زخرفي */}
        <div className="flex shrink-0 items-center" aria-hidden>
          <svg width="36" height="36" viewBox="0 0 40 40" fill="none">
            <circle cx="20" cy="20" r="18" stroke="#d4af37" strokeOpacity="0.35" strokeWidth="1" />
            <path
              d="M20 6 L23 17 L34 20 L23 23 L20 34 L17 23 L6 20 L17 17 Z"
              fill="#d4af37"
              fillOpacity="0.18"
              stroke="#d4af37"
              strokeOpacity="0.5"
              strokeWidth="0.8"
            />
          </svg>
        </div>
      </div>
    </header>
  );
}
