import type { ReactNode } from "react";
import Header from "./Header";
import BottomNav from "./BottomNav";

type Props = {
  children: ReactNode;
  variant?: "home" | "inner";
};

export default function Layout({ children, variant = "inner" }: Props) {
  return (
    <div
      className={`flex min-h-screen flex-col ${
        variant === "home" ? "bg-islamic-pattern" : "bg-paper-soft"
      }`}
    >
      <Header />
      <main className="flex-1 pb-24">
        <div className="mx-auto w-full max-w-md">{children}</div>
      </main>
      <BottomNav />
    </div>
  );
}
