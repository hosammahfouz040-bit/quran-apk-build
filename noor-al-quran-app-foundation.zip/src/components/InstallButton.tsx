import { useInstallPrompt } from "@/hooks/useInstallPrompt";

export default function InstallButton() {
  const { isInstallable, isInstalled, promptInstall } = useInstallPrompt();

  // لا تظهر الزر إذا كان التطبيق مثبتاً أو غير قابل للتثبيت
  if (!isInstallable || isInstalled) {
    return null;
  }

  const handleInstall = async () => {
    const success = await promptInstall();
    if (success) {
      alert("تم تثبيت التطبيق بنجاح! يمكنك الآن فتحه من الشاشة الرئيسية.");
    }
  };

  return (
    <button
      onClick={handleInstall}
      className="tap-highlight w-full mb-4 p-4 bg-gradient-to-l from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white rounded-2xl shadow-lg transition-all flex items-center gap-3"
    >
      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/20 backdrop-blur-sm">
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <polyline points="7 10 12 15 17 10" />
          <line x1="12" y1="15" x2="12" y2="3" />
        </svg>
      </div>
      <div className="flex-1 text-right">
        <p className="text-base font-bold">تثبيت التطبيق</p>
        <p className="text-xs opacity-90">أضف نور القرآن للشاشة الرئيسية</p>
      </div>
    </button>
  );
}
