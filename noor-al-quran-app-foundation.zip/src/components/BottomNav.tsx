import type { ReactNode } from "react";
import { Link, useLocation } from "react-router-dom";
import { icons, sections } from "@/data/sections";

type NavItem = {
  label: string;
  path: string;
  icon: ReactNode;
};

const navItems: NavItem[] = [
  { label: "الرئيسية", path: "/", icon: icons.home },
  { label: "القرآن", path: "/quran", icon: icons.quran },
  { label: "الصلاة", path: "/prayer", icon: icons.prayer },
  { label: "الأذكار", path: "/azkar", icon: icons.azkar },
  { label: "المزيد", path: "/menu", icon: icons.menu },
];

export default function BottomNav() {
  const location = useLocation();

  const isActive = (path: string) => {
    if (path === "/") return location.pathname === "/";
    // "المزيد" ينشط إذا كنا في صفحة ليست في القائمة الرئيسية
    if (path === "/menu") {
      const knownPaths = ["/", ...sections.map((s) => s.path)];
      return !knownPaths.includes(location.pathname);
    }
    return location.pathname === path || location.pathname.startsWith(path + "/");
  };

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-brand-100 bg-white/95 backdrop-blur-md"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      aria-label="شريط التنقل الرئيسي"
    >
      <ul className="mx-auto flex max-w-md items-stretch justify-around px-2 py-1.5">
        {navItems.map((item) => {
          const active = isActive(item.path);
          return (
            <li key={item.path} className="flex-1">
              <Link
                to={item.path}
                className={`tap-highlight flex flex-col items-center justify-center gap-0.5 rounded-xl px-1 py-2 text-[11px] font-semibold transition-colors ${
                  active
                    ? "text-brand-800"
                    : "text-slate-500 hover:text-brand-700"
                }`}
                aria-current={active ? "page" : undefined}
              >
                <span
                  className={`flex h-9 w-9 items-center justify-center rounded-full transition-colors ${
                    active
                      ? "bg-brand-900 text-gold-300 shadow-md shadow-brand-900/20"
                      : "bg-transparent text-slate-500"
                  }`}
                >
                  {item.icon}
                </span>
                <span className={active ? "font-bold" : "font-medium"}>
                  {item.label}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
