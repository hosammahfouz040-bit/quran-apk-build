import type { JSX } from "react";

export type SectionId =
  | "quran"
  | "reciters"
  | "tafsir"
  | "azkar"
  | "prayer"
  | "tasbih"
  | "memorization"
  | "completion"
  | "qibla"
  | "calendar"
  | "downloads";

export type Section = {
  id: SectionId;
  title: string;
  subtitle: string;
  path: string;
  accent: string;
  iconBg: string;
  icon: JSX.Element;
};

const iconProps = {
  width: 32,
  height: 32,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.6,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

export const icons = {
  quran: (
    <svg {...iconProps}>
      <path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H19v17H6.5A2.5 2.5 0 0 0 4 21.5v-17Z" />
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H19v2.5A2.5 2.5 0 0 1 16.5 22H6.5A2.5 2.5 0 0 1 4 19.5Z" />
      <path d="M9 7h7M9 11h5" />
    </svg>
  ),
  reciters: (
    <svg {...iconProps}>
      <path d="M12 2a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
      <path d="M19 10v1a7 7 0 0 1-14 0v-1M12 18v4M8 22h8" />
    </svg>
  ),
  tafsir: (
    <svg {...iconProps}>
      <path d="M3 5a2 2 0 0 1 2-2h6v18H5a2 2 0 0 1-2-2V5Z" />
      <path d="M21 5a2 2 0 0 0-2-2h-6v18h6a2 2 0 0 0 2-2V5Z" />
      <path d="M7 7h2M7 11h2M15 7h2M15 11h2" />
    </svg>
  ),
  azkar: (
    <svg {...iconProps}>
      <circle cx="12" cy="12" r="2" />
      <circle cx="12" cy="5" r="1.6" />
      <circle cx="12" cy="19" r="1.6" />
      <circle cx="5" cy="12" r="1.6" />
      <circle cx="19" cy="12" r="1.6" />
      <circle cx="7" cy="7" r="1.4" />
      <circle cx="17" cy="7" r="1.4" />
      <circle cx="7" cy="17" r="1.4" />
      <circle cx="17" cy="17" r="1.4" />
    </svg>
  ),
  prayer: (
    <svg {...iconProps}>
      <path d="M3 21h18" />
      <path d="M5 21V10l7-6 7 6v11" />
      <path d="M10 21v-6a2 2 0 0 1 4 0v6" />
      <path d="M12 4V2" />
    </svg>
  ),
  tasbih: (
    <svg {...iconProps}>
      <circle cx="12" cy="12" r="7" />
      <circle cx="12" cy="5" r="1.2" fill="currentColor" />
      <circle cx="19" cy="12" r="1.2" fill="currentColor" />
      <circle cx="12" cy="19" r="1.2" fill="currentColor" />
      <circle cx="5" cy="12" r="1.2" fill="currentColor" />
      <circle cx="17" cy="7" r="1.2" fill="currentColor" />
      <circle cx="17" cy="17" r="1.2" fill="currentColor" />
      <circle cx="7" cy="17" r="1.2" fill="currentColor" />
      <circle cx="7" cy="7" r="1.2" fill="currentColor" />
      <path d="M12 5V2M11 2h2" />
    </svg>
  ),
  memorization: (
    <svg {...iconProps}>
      <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20" />
      <path d="M8 7h6M8 11h8" />
    </svg>
  ),
  completion: (
    <svg {...iconProps}>
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  ),
  qibla: (
    <svg {...iconProps}>
      <circle cx="12" cy="12" r="10" />
      <path d="M12 2 L12 12 L18 18" />
      <circle cx="12" cy="12" r="3" fill="currentColor" />
    </svg>
  ),
  calendar: (
    <svg {...iconProps}>
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  ),
  download: (
    <svg {...iconProps}>
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="7 10 12 15 17 10" />
      <line x1="12" y1="15" x2="12" y2="3" />
    </svg>
  ),
  home: (
    <svg {...iconProps} width={24} height={24}>
      <path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1v-9.5Z" />
    </svg>
  ),
  menu: (
    <svg {...iconProps} width={24} height={24}>
      <circle cx="6" cy="6" r="1.5" fill="currentColor" />
      <circle cx="12" cy="6" r="1.5" fill="currentColor" />
      <circle cx="18" cy="6" r="1.5" fill="currentColor" />
      <circle cx="6" cy="12" r="1.5" fill="currentColor" />
      <circle cx="12" cy="12" r="1.5" fill="currentColor" />
      <circle cx="18" cy="12" r="1.5" fill="currentColor" />
      <circle cx="6" cy="18" r="1.5" fill="currentColor" />
      <circle cx="12" cy="18" r="1.5" fill="currentColor" />
      <circle cx="18" cy="18" r="1.5" fill="currentColor" />
    </svg>
  ),
  back: (
    <svg {...iconProps} width={22} height={22}>
      <path d="M15 6l-6 6 6 6" />
    </svg>
  ),
  star: (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2 L14 8.5 L21 9.3 L15.8 13.8 L17.4 20.7 L12 17.2 L6.6 20.7 L8.2 13.8 L3 9.3 L10 8.5 Z" />
    </svg>
  ),
};

export const sections: Section[] = [
  {
    id: "quran",
    title: "القرآن الكريم",
    subtitle: "قراءة المصحف الشريف",
    path: "/quran",
    accent: "from-brand-700 to-brand-900",
    iconBg: "bg-brand-50 text-brand-700",
    icon: icons.quran,
  },
  {
    id: "reciters",
    title: "القراء والتلاوات",
    subtitle: "أصوات مختارة بعناية",
    path: "/reciters",
    accent: "from-emerald-600 to-brand-800",
    iconBg: "bg-emerald-50 text-emerald-700",
    icon: icons.reciters,
  },
  {
    id: "tafsir",
    title: "تفسير القرآن",
    subtitle: "فهم معاني الآيات",
    path: "/tafsir",
    accent: "from-brand-600 to-emerald-800",
    iconBg: "bg-amber-50 text-amber-700",
    icon: icons.tafsir,
  },
  {
    id: "azkar",
    title: "الأذكار",
    subtitle: "أذكار الصباح والمساء",
    path: "/azkar",
    accent: "from-brand-700 to-brand-950",
    iconBg: "bg-brand-50 text-brand-700",
    icon: icons.azkar,
  },
  {
    id: "prayer",
    title: "مواقيت الصلاة",
    subtitle: "أوقات الصلوات الخمس",
    path: "/prayer",
    accent: "from-gold-600 to-gold-800",
    iconBg: "bg-gold-50 text-gold-700",
    icon: icons.prayer,
  },
  {
    id: "tasbih",
    title: "المسبحة الإلكترونية",
    subtitle: "سبّح واذكر الله",
    path: "/tasbih",
    accent: "from-gold-500 to-brand-800",
    iconBg: "bg-gold-50 text-gold-700",
    icon: icons.tasbih,
  },
  {
    id: "memorization",
    title: "حفظ القرآن",
    subtitle: "خطط للحفظ والمراجعة",
    path: "/memorization",
    accent: "from-emerald-600 to-emerald-800",
    iconBg: "bg-emerald-50 text-emerald-700",
    icon: icons.memorization,
  },
  {
    id: "completion",
    title: "خطة الختمة",
    subtitle: "اختم القرآن في وقت محدد",
    path: "/completion",
    accent: "from-purple-600 to-purple-800",
    iconBg: "bg-purple-50 text-purple-700",
    icon: icons.completion,
  },
  {
    id: "qibla",
    title: "اتجاه القبلة",
    subtitle: "حدد اتجاه القبلة",
    path: "/qibla",
    accent: "from-teal-600 to-teal-800",
    iconBg: "bg-teal-50 text-teal-700",
    icon: icons.qibla,
  },
  {
    id: "calendar",
    title: "التقويم الهجري",
    subtitle: "التاريخ والمناسبات الإسلامية",
    path: "/calendar",
    accent: "from-indigo-600 to-indigo-800",
    iconBg: "bg-indigo-50 text-indigo-700",
    icon: icons.calendar,
  },
  {
    id: "downloads",
    title: "إدارة التنزيلات",
    subtitle: "ملفات صوتية دون إنترنت",
    path: "/downloads",
    accent: "from-orange-600 to-orange-800",
    iconBg: "bg-orange-50 text-orange-700",
    icon: icons.download,
  },
];
