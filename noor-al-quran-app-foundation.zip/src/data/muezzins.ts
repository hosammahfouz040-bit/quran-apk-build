/**
 * مكتبة المؤذنين - تسجيلات أذان حقيقية من مصادر موثوقة.
 * 
 * المصادر:
 * - Internet Archive (archive.org) - ملفات مجانية
 * - Assabile.com - 259 تسجيل أذان
 * - AlAdhan.com - أذانات من الحرمين
 */

export interface Muezzin {
  id: string;
  name: string;
  nameAr: string;
  country: string;
  countryAr: string;
  mosque?: string;
  mosqueAr?: string;
  adhanUrl: string;
  fajrAdhanUrl?: string; // أذان الفجر المختلف
  duration: number; // بالدقائق
  source: string;
  verified: boolean; // تم التحقق من الرابط
  description?: string;
  descriptionAr?: string;
}

/**
 * قائمة المؤذنين المعتمدين - جميع الروابط تم اختبارها.
 */
export const MUEZZINS: Muezzin[] = [
  // === الحرمين الشريفين ===
  {
    id: "ali_ahmed_mulla",
    name: "Ali Ahmed Mulla",
    nameAr: "علي أحمد ملا",
    country: "Saudi Arabia",
    countryAr: "السعودية",
    mosque: "Masjid al-Haram, Makkah",
    mosqueAr: "المسجد الحرام، مكة المكرمة",
    adhanUrl: "https://archive.org/download/adhans_sunnah/adhan_makkah.mp3",
    duration: 4,
    source: "Internet Archive",
    verified: true,
    description: "Chief Muezzin of Masjid al-Haram",
    descriptionAr: "مؤذن المسجد الحرام",
  },
  {
    id: "makkah_2",
    name: "Makkah Muezzin",
    nameAr: "مؤذن مكة المكرمة",
    country: "Saudi Arabia",
    countryAr: "السعودية",
    mosque: "Masjid al-Haram, Makkah",
    mosqueAr: "المسجد الحرام، مكة المكرمة",
    adhanUrl: "https://archive.org/download/AdzanMakkah/Adzan_Makkah.mp3",
    duration: 3.5,
    source: "Internet Archive",
    verified: true,
    description: "Traditional Makkah Adhan",
    descriptionAr: "أذان مكة التقليدي",
  },
  {
    id: "madinah_1952",
    name: "Madinah Muezzin (1952)",
    nameAr: "مؤذن المدينة المنورة (1952)",
    country: "Saudi Arabia",
    countryAr: "السعودية",
    mosque: "Masjid an-Nabawi, Madinah",
    mosqueAr: "المسجد النبوي، المدينة المنورة",
    adhanUrl: "https://archive.org/download/adhans_sunnah/adhan_madina_1952.mp3",
    duration: 4,
    source: "Internet Archive",
    verified: true,
    description: "Historical recording from 1952",
    descriptionAr: "تسجيل تاريخي من عام 1952",
  },
  {
    id: "madinah_modern",
    name: "Madinah Muezzin",
    nameAr: "مؤذن المدينة المنورة",
    country: "Saudi Arabia",
    countryAr: "السعودية",
    mosque: "Masjid an-Nabawi, Madinah",
    mosqueAr: "المسجد النبوي، المدينة المنورة",
    adhanUrl: "https://archive.org/download/adhan_madina/adhan_madina.mp3",
    duration: 3.5,
    source: "Internet Archive",
    verified: true,
    description: "Modern Madinah Adhan",
    descriptionAr: "أذان المدينة الحديث",
  },

  // === الكويت ===
  {
    id: "mishary_alafasy",
    name: "Mishary Rashid Alafasy",
    nameAr: "مشاري راشد العفاسي",
    country: "Kuwait",
    countryAr: "الكويت",
    adhanUrl: "https://archive.org/download/adhans_sunnah/adhan_mishari.mp3",
    duration: 4,
    source: "Internet Archive",
    verified: true,
    description: "Famous Qari and Muezzin",
    descriptionAr: "قارئ ومؤذن مشهور",
  },
  {
    id: "alafasy_nice",
    name: "Mishary Alafasy - Beautiful Version",
    nameAr: "مشاري العفاسي - نسخة جميلة",
    country: "Kuwait",
    countryAr: "الكويت",
    adhanUrl: "https://archive.org/download/adhans_sunnah/Athan_alafasi_nice.mp3",
    duration: 3.5,
    source: "Internet Archive",
    verified: true,
    description: "Beautiful recitation style",
    descriptionAr: "أسلوب تلاوة جميل",
  },

  // === مصر ===
  {
    id: "abdul_baset",
    name: "Abdul Basit Abdul Samad",
    nameAr: "عبد الباسط عبد الصمد",
    country: "Egypt",
    countryAr: "مصر",
    adhanUrl: "https://archive.org/download/adhans_sunnah/adhan_abdul_baset.mp3",
    duration: 4,
    source: "Internet Archive",
    verified: true,
    description: "Legendary Egyptian Qari",
    descriptionAr: "قارئ مصري أسطوري",
  },
  {
    id: "egypt_traditional",
    name: "Egypt - Traditional",
    nameAr: "مصر - التقليدي",
    country: "Egypt",
    countryAr: "مصر",
    adhanUrl: "https://archive.org/download/adhans_sunnah/adhan_egypt.mp3",
    duration: 3.5,
    source: "Internet Archive",
    verified: true,
    description: "Traditional Egyptian style",
    descriptionAr: "الأسلوب المصري التقليدي",
  },
  {
    id: "islam_sobhi",
    name: "Islam Sobhi",
    nameAr: "إسلام صبحي",
    country: "Egypt",
    countryAr: "مصر",
    adhanUrl: "https://archive.org/download/adhans_sunnah/islam_sobhi.mp3",
    duration: 3.5,
    source: "Internet Archive",
    verified: true,
    description: "Modern Egyptian Muezzin",
    descriptionAr: "مؤذن مصري معاصر",
  },

  // === السعودية (قراء آخرون) ===
  {
    id: "nasser_al_qatami",
    name: "Nasser Al Qatami",
    nameAr: "ناصر القطامي",
    country: "Saudi Arabia",
    countryAr: "السعودية",
    adhanUrl: "https://archive.org/download/adhans_sunnah/adhan_nasser_al_qatami.mp3",
    duration: 3.5,
    source: "Internet Archive",
    verified: true,
    description: "Saudi Qari and Muezzin",
    descriptionAr: "قارئ ومؤذن سعودي",
  },
  {
    id: "salman_utaybi",
    name: "Salman Utaybi",
    nameAr: "سلمان العتيبي",
    country: "Saudi Arabia",
    countryAr: "السعودية",
    adhanUrl: "https://archive.org/download/adhans_sunnah/salman_utaybi.mp3",
    duration: 3.5,
    source: "Internet Archive",
    verified: true,
    description: "Saudi Muezzin",
    descriptionAr: "مؤذن سعودي",
  },

  // === دول أخرى ===
  {
    id: "majid_pashaii",
    name: "Majid Pashaii",
    nameAr: "ماجد باشائي",
    country: "Albania",
    countryAr: "ألبانيا",
    adhanUrl: "https://archive.org/download/adhans_sunnah/Athan_Majid_Pashaii.mp3",
    duration: 3,
    source: "Internet Archive",
    verified: true,
    description: "Albanian Muezzin",
    descriptionAr: "مؤذن ألباني",
  },
  {
    id: "tareq_mohammad",
    name: "Tareq Mohammad",
    nameAr: "طارق محمد",
    country: "Bangladesh",
    countryAr: "بنغلاديش",
    adhanUrl: "https://archive.org/download/adhans_sunnah/Azan_Tareq_Mohammad.mp3",
    duration: 4,
    source: "Internet Archive",
    verified: true,
    description: "Bangladeshi Muezzin",
    descriptionAr: "مؤذن بنغلاديشي",
  },
  {
    id: "molana_kurtish",
    name: "Molana Kurtish",
    nameAr: "مولانا كورتش",
    country: "Unknown",
    countryAr: "غير معروف",
    adhanUrl: "https://archive.org/download/adhans_sunnah/athan_molana_kurtish.mp3",
    duration: 3,
    source: "Internet Archive",
    verified: true,
    description: "Beautiful recitation",
    descriptionAr: "تلاوة جميلة",
  },
];

/**
 * الحصول على مؤذن حسب المعرف.
 */
export function getMuezzinById(id: string): Muezzin | null {
  return MUEZZINS.find((m) => m.id === id) || null;
}

/**
 * البحث عن مؤذنين.
 */
export function searchMuezzins(query: string): Muezzin[] {
  const lowerQuery = query.toLowerCase();
  return MUEZZINS.filter(
    (m) =>
      m.name.toLowerCase().includes(lowerQuery) ||
      m.nameAr.includes(query) ||
      m.country.toLowerCase().includes(lowerQuery) ||
      m.countryAr.includes(query) ||
      m.mosque?.toLowerCase().includes(lowerQuery) ||
      m.mosqueAr?.includes(query)
  );
}

/**
 * الحصول على المؤذنين حسب البلد.
 */
export function getMuezzinsByCountry(country: string): Muezzin[] {
  return MUEZZINS.filter(
    (m) => m.country === country || m.countryAr === country
  );
}

/**
 * الحصول على قائمة البلدان المتاحة.
 */
export function getAvailableCountries(): string[] {
  const countries = new Set(MUEZZINS.map((m) => m.countryAr));
  return Array.from(countries).sort();
}

/**
 * التحقق من صلاحية رابط الأذان.
 */
export async function verifyAdhanUrl(url: string): Promise<boolean> {
  try {
    const response = await fetch(url, { method: "HEAD" });
    return response.ok;
  } catch {
    return false;
  }
}
