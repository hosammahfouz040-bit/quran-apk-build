/**
 * Hook لإدارة إعدادات المستخدم (حجم الخط، الوضع الليلي، آخر قراءة).
 * يحفظ الإعدادات في localStorage (بيانات صغيرة).
 */

import { useCallback, useEffect, useState } from "react";
import { DEFAULT_SETTINGS, type QuranSettings } from "@/types/quran";

const STORAGE_KEY = "noor-quran-settings";

function loadFromStorage(): QuranSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<QuranSettings>;
    return { ...DEFAULT_SETTINGS, ...parsed };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function saveToStorage(settings: QuranSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch {
    // تجاهل الأخطاء في حال امتلاء التخزين
  }
}

export function useSettings() {
  const [settings, setSettings] = useState<QuranSettings>(() => loadFromStorage());

  useEffect(() => {
    saveToStorage(settings);
  }, [settings]);

  const setFontSize = useCallback((fontSize: number) => {
    setSettings((prev) => ({ ...prev, fontSize: Math.max(18, Math.min(48, fontSize)) }));
  }, []);

  const toggleDarkMode = useCallback(() => {
    setSettings((prev) => ({ ...prev, darkMode: !prev.darkMode }));
  }, []);

  const saveLastRead = useCallback((surah: number, ayah: number) => {
    setSettings((prev) => ({ ...prev, lastSurah: surah, lastAyah: ayah }));
  }, []);

  const resetSettings = useCallback(() => {
    setSettings(DEFAULT_SETTINGS);
  }, []);

  return { settings, setFontSize, toggleDarkMode, saveLastRead, resetSettings };
}
