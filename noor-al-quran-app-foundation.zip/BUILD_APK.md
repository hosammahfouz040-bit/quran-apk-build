# 📦 دليل بناء ملف APK لتطبيق نور القرآن

## 🎯 نظرة عامة

هذا الدليل يشرح كيفية بناء ملف **APK** حقيقي يمكن تنزيله وتثبيته على أجهزة Android.

---

## 📋 المتطلبات

### 1. نظام التشغيل
- **Windows 10/11** أو **macOS** أو **Linux**

### 2. البرامج المطلوبة

#### أ. Node.js (v18 أو أحدث)
- التحميل: https://nodejs.org/
- تحقق من التثبيت:
```bash
node --version
npm --version
```

#### ب. Java JDK 17 أو أحدث
- التحميل: https://adoptium.net/
- أو Oracle JDK: https://www.oracle.com/java/technologies/downloads/
- تحقق من التثبيت:
```bash
java --version
```

#### ج. Android Studio
- التحميل: https://developer.android.com/studio
- **مهم**: اختر "Standard" installation
- بعد التثبيت، افتح Android Studio واتبع معالج الإعداد

#### د. Android SDK
- يتم تثبيته تلقائياً مع Android Studio
- تأكد من تثبيت:
  - Android SDK Platform (API 33 أو أحدث)
  - Android SDK Build-Tools
  - Android SDK Platform-Tools

---

## 🚀 خطوات بناء APK

### الخطوة 1: تثبيت المكتبات

```bash
# في مجلد المشروع
npm install
```

### الخطوة 2: بناء تطبيق الويب

```bash
npm run build
```

هذا سينشئ مجلد `dist` يحتوي على تطبيق الويب الجاهز.

### الخطوة 3: مزامنة الملفات مع Android

```bash
npx cap sync android
```

هذا سينسخ ملفات الويب إلى مشروع Android.

### الخطوة 4: فتح المشروع في Android Studio

```bash
npx cap open android
```

سيتم فتح Android Studio تلقائياً.

### الخطوة 5: بناء APK في Android Studio

1. **انتظر حتى ينتهي Gradle من المزامنة** (قد يستغرق 2-5 دقائق)

2. **من قائمة Build**:
   - اختر: `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`

3. **انتظر حتى ينتهي البناء** (قد يستغرق 3-10 دقائق)

4. **ابحث عن رسالة**:
   ```
   APK(s) generated successfully
   ```

5. **اضغط على "locate"** في الرسالة

6. **ستجد ملف APK في**:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

### الخطوة 6: نقل APK إلى هاتفك

1. **انسخ ملف `app-debug.apk`** إلى هاتفك
2. **على هاتفك**:
   - اذهب إلى: الإعدادات → الأمان
   - فعّل: "تثبيت من مصادر غير معروفة"
   - أو: "السماح من هذا المصدر"
3. **افتح ملف APK** واضغط على "تثبيت"
4. ✅ **تم!** التطبيق الآن على هاتفك

---

## 🎨 تخصيص الأيقونة

### إنشاء أيقونة مخصصة

1. **حضّر صورة الأيقونة**:
   - الحجم: 1024×1024 بكسل
   - الصيغة: PNG
   - الخلفية: شفافة أو لون واحد

2. **استخدم أداة Capacitor Assets Generator**:
```bash
npm install --save-dev @capacitor/assets
npx capacitor-assets generate --android
```

3. **أو استخدم أداة يدوية**:
   - https://icon.kitchen/
   - https://romannurik.github.io/AndroidAssetStudio/

---

## 🔧 بناء APK بدون Android Studio (متقدم)

إذا كنت تفضل سطر الأوامر:

### Windows:
```bash
cd android
.\gradlew assembleDebug
```

### macOS/Linux:
```bash
cd android
./gradlew assembleDebug
```

**موقع APK**:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 📱 بناء APK مُوقّع (للنشر)

إذا كنت تريد نشر التطبيق على Google Play:

### 1. إنشاء Keystore

```bash
keytool -genkey -v -keystore my-release-key.keystore -alias alias_name -keyalg RSA -keysize 2048 -validity 10000
```

### 2. بناء APK مُوقّع

في Android Studio:
1. `Build` → `Generate Signed Bundle / APK`
2. اختر `APK`
3. اختر Keystore الخاص بك
4. أدخل كلمة المرور
5. اختر `release`
6. اضغط `Finish`

**موقع APK**:
```
android/app/build/outputs/apk/release/app-release.apk
```

---

## ⚠️ استكشاف الأخطاء

### المشكلة: "SDK location not found"

**الحل**:
1. افتح `android/local.properties`
2. أضف:
```properties
sdk.dir=C:\\Users\\YOUR_USERNAME\\AppData\\Local\\Android\\Sdk
```

أو على macOS/Linux:
```properties
sdk.dir=/Users/YOUR_USERNAME/Library/Android/sdk
```

### المشكلة: "Could not find or load main class"

**الحل**:
- تأكد من تثبيت Java JDK 17 أو أحدث
- تحقق من JAVA_HOME:
```bash
echo %JAVA_HOME%  # Windows
echo $JAVA_HOME   # macOS/Linux
```

### المشكلة: "Gradle build failed"

**الحل**:
1. افتح Android Studio
2. `File` → `Invalidate Caches / Restart`
3. `Build` → `Clean Project`
4. `Build` → `Rebuild Project`

### المشكلة: "App not installed"

**الحل على الهاتف**:
1. احذف الإصدار القديم (إذا كان موجوداً)
2. فعّل "تثبيت من مصادر غير معروفة"
3. تأكد من وجود مساحة كافية
4. جرب إعادة تشغيل الهاتف

---

## 📊 معلومات APK

| المعلومة | القيمة |
|----------|--------|
| **حجم APK المتوقع** | 15-25 MB |
| **الحد الأدنى لـ Android** | Android 5.0 (API 21) |
| **الهدف** | Android 13 (API 33) |
| **المعمارية** | ARM, ARM64, x86, x86_64 |

---

## 🎯 نصائح مهمة

### قبل البناء:
1. ✅ تأكد من تثبيت جميع المتطلبات
2. ✅ تأكد من وجود اتصال بالإنترنت
3. ✅ تأكد من وجود مساحة كافية (2 GB على الأقل)

### أثناء البناء:
1. ⏳ كن صبوراً (البناء الأول قد يستغرق 10-20 دقيقة)
2. 📱 لا تغلق Android Studio
3. 🔌 تأكد من استقرار الكهرباء

### بعد البناء:
1. 🧪 اختبر APK على جهازك
2. 📸 التقط screenshots للتطبيق
3. 📝 اكتب وصفاً للتطبيق

---

## 🚀 نشر التطبيق

### على Google Play Store:
1. أنشئ حساب مطور ($25 لمرة واحدة)
2. حضّر:
   - APK مُوقّع
   - screenshots
   - وصف التطبيق
   - أيقونة عالية الدقة
3. ارفع التطبيق على Google Play Console

### بدائل مجانية:
- **GitHub Releases**: https://github.com/
- **APKPure**: https://apkpure.com/
- **Uptodown**: https://uptodown.com/

---

## 📞 الدعم

إذا واجهت أي مشكلة:

1. تحقق من هذا الدليل أولاً
2. ابحث في: https://capacitorjs.com/docs
3. اسأل في: https://github.com/ionic-team/capacitor/discussions

---

## 🎉 النتيجة النهائية

بعد اتباع هذه الخطوات، ستحصل على:

✅ ملف **APK** حقيقي يمكن تنزيله
✅ تطبيق **أصلي** يعمل على Android
✅ **أيقونة** مخصصة على الشاشة الرئيسية
✅ **شاشة بداية** احترافية
✅ **أداء** ممتاز مثل التطبيقات الأصلية

---

## 📄 ملخص الأوامر

```bash
# 1. تثبيت المكتبات
npm install

# 2. بناء تطبيق الويب
npm run build

# 3. مزامنة مع Android
npx cap sync android

# 4. فتح Android Studio
npx cap open android

# 5. بناء APK (في Android Studio)
# Build → Build Bundle(s) / APK(s) → Build APK(s)

# 6. موقع APK
# android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 💡 نصيحة أخيرة

إذا كنت تريد طريقة أسرع:

1. **استخدم جهاز حقيقي** بدلاً من المحاكي
2. **استخدم SSD** بدلاً من HDD
3. **أغلق البرامج الأخرى** أثناء البناء
4. **زد ذاكرة RAM** المخصصة لـ Android Studio

---

**حظاً موفقاً! 🚀**

إذا نجحت في بناء APK، شاركنا تجربتك! 🎉
