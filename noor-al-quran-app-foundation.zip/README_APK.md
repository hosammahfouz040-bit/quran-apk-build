# 📱 دليل تنزيل وتثبيت تطبيق نور القرآن (APK)

## 🎯 ملخص سريع

تريد **ملف APK** لتطبيق نور القرآن؟ اتبع هذه الخطوات البسيطة:

### الطريقة الأسرع (5 دقائق) ⚡

```bash
# 1. ثبّت المكتبات
npm install

# 2. ابنِ التطبيق
npm run build

# 3. حضّر Android
npx cap sync android

# 4. افتح Android Studio
npx cap open android

# 5. في Android Studio: Build → Build APK
# ✅ ستجد APK في: android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 📋 ما ستحتاجه

### البرامج المطلوبة (مجانية):

1. **Node.js** (v18 أو أحدث)
   - التحميل: https://nodejs.org/
   - للتحقق: `node --version`

2. **Java JDK 17** أو أحدث
   - التحميل: https://adoptium.net/
   - للتحقق: `java --version`

3. **Android Studio**
   - التحميل: https://developer.android.com/studio
   - **مهم**: اختر "Standard" installation

---

## 🚀 الخطوات التفصيلية

### الخطوة 1: التحضير

```bash
# افتح Terminal في مجلد المشروع
cd path/to/noor-quran

# ثبّت المكتبات
npm install
```

⏱️ الوقت المتوقع: 1-2 دقيقة

---

### الخطوة 2: بناء تطبيق الويب

```bash
npm run build
```

⏱️ الوقت المتوقع: 30 ثانية

**النتيجة**: مجلد `dist` يحتوي على تطبيق الويب الجاهز

---

### الخطوة 3: إعداد Android

```bash
# مزامنة الملفات مع Android
npx cap sync android

# فتح Android Studio
npx cap open android
```

⏱️ الوقت المتوقع: 1-2 دقيقة

**النتيجة**: Android Studio يفتح تلقائياً

---

### الخطوة 4: بناء APK في Android Studio

1. **انتظر حتى ينتهي Gradle من المزامنة**
   - ستشاهد شريط تقدم في الأسفل
   - قد يستغرق 2-5 دقائق (أول مرة)

2. **ابنِ APK**:
   - من القائمة: `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
   - أو استخدم الاختصار: `Ctrl+F9` (Windows/Linux) أو `Cmd+F9` (macOS)

3. **انتظر حتى ينتهي البناء**
   - قد يستغرق 3-10 دقائق (أول مرة)
   - ستشاهد رسالة: `APK(s) generated successfully`

4. **احصل على APK**:
   - اضغط على `locate` في الرسالة
   - أو اذهب يدوياً إلى:
     ```
     android/app/build/outputs/apk/debug/app-debug.apk
     ```

⏱️ الوقت المتوقع: 5-10 دقائق (أول مرة)

---

### الخطوة 5: تثبيت APK على هاتفك

#### على الكمبيوتر:
1. انسخ ملف `app-debug.apk`
2. أرسله إلى هاتفك (USB, Bluetooth, Email, أو أي طريقة)

#### على الهاتف:
1. **فعّل التثبيت من مصادر غير معروفة**:
   - Android 8+: الإعدادات → الأمان → مصادر غير معروفة → اختر المتصفح
   - Android 7 أو أقل: الإعدادات → الأمان → مصادر غير معروفة (تفعيل)

2. **افتح ملف APK**:
   - استخدم مدير الملفات
   - اضغط على `app-debug.apk`
   - اضغط على `تثبيت`

3. **افتح التطبيق**:
   - اضغط على `فتح`
   - أو ابحث عن "نور القرآن" في قائمة التطبيقات

✅ **تهانينا!** التطبيق الآن على هاتفك!

---

## 📊 معلومات APK

| المعلومة | القيمة |
|----------|--------|
| **حجم APK** | ~15-25 MB |
| **الحد الأدنى لـ Android** | Android 5.0 (API 21) |
| **الهدف** | Android 13 (API 33) |
| **المعمارية** | ARM, ARM64, x86, x86_64 |
| **الاسم** | نور القرآن |
| **الحزمة** | com.nooquran.app |

---

## 🎨 الأيقونة

التطبيق يأتي مع أيقونة احترافية:

- **الحجم**: 512×512 بكسل
- **التصميم**: خلفية خضراء زمردي مع زخارف ذهبية
- **الموقع**: `public/icons/icon-512x512.png`

لتغيير الأيقونة:
1. استبدل ملفات الأيقونة في `public/icons/`
2. نفّذ: `npx cap sync android`
3. أعد بناء APK

---

## ⚠️ استكشاف الأخطاء

### ❌ "SDK location not found"

**الحل**:
```bash
# أنشئ ملف android/local.properties
# وأضف مسار SDK:

# Windows:
sdk.dir=C:\\Users\\YOUR_USERNAME\\AppData\\Local\\Android\\Sdk

# macOS:
sdk.dir=/Users/YOUR_USERNAME/Library/Android/sdk

# Linux:
sdk.dir=/home/YOUR_USERNAME/Android/Sdk
```

---

### ❌ "Could not find or load main class"

**الحل**:
```bash
# تأكد من تثبيت Java JDK 17 أو أحدث
java --version

# إذا لم يكن مثبتاً، ثبّته من:
# https://adoptium.net/
```

---

### ❌ "App not installed" على الهاتف

**الحل**:
1. احذف الإصدار القديم (إذا كان موجوداً)
2. فعّل "مصادر غير معروفة"
3. تأكد من وجود مساحة كافية (50 MB على الأقل)
4. جرب إعادة تشغيل الهاتف

---

### ❌ "Gradle build failed"

**الحل**:
```bash
# في Android Studio:
# 1. File → Invalidate Caches / Restart
# 2. Build → Clean Project
# 3. Build → Rebuild Project
```

---

## 💡 نصائح مهمة

### قبل البناء:
- ✅ تأكد من تثبيت جميع البرامج المطلوبة
- ✅ تأكد من وجود اتصال بالإنترنت (أول مرة)
- ✅ تأكد من وجود مساحة كافية (2 GB على الأقل)

### أثناء البناء:
- ⏳ كن صبوراً (البناء الأول يستغرق وقتاً)
- 📱 لا تغلق Android Studio
- 🔌 تأكد من استقرار الكهرباء

### بعد البناء:
- 🧪 اختبر APK على جهازك
- 📸 التقط screenshots للتطبيق
- 📝 اكتب وصفاً للتطبيق

---

## 🚀 نصائح متقدمة

### بناء APK مُوقّع (للنشر):

```bash
# 1. أنشئ Keystore
keytool -genkey -v -keystore my-release-key.keystore -alias noor-quran -keyalg RSA -keysize 2048 -validity 10000

# 2. في Android Studio:
# Build → Generate Signed Bundle / APK → APK
# اختر Keystore الخاص بك
# اختر release
# اضغط Finish
```

**موقع APK المُوقّع**:
```
android/app/build/outputs/apk/release/app-release.apk
```

---

### بناء APK بسرعة (سطر الأوامر):

```bash
cd android

# Windows:
.\gradlew assembleDebug

# macOS/Linux:
./gradlew assembleDebug
```

**موقع APK**:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 📞 الدعم

إذا واجهت أي مشكلة:

1. **اقرأ هذا الدليل** بالكامل
2. **اقرأ ملف BUILD_APK.md** للتفاصيل
3. **ابحث في الإنترنت** عن رسالة الخطأ
4. **اسأل في مجتمعات المطورين**

---

## 🎉 النتيجة النهائية

بعد اتباع هذه الخطوات، ستحصل على:

✅ ملف **APK** حقيقي يمكن تنزيله
✅ تطبيق **أصلي** يعمل على Android
✅ **أيقونة** مخصصة على الشاشة الرئيسية
✅ **شاشة بداية** احترافية
✅ **أداء** ممتاز مثل التطبيقات الأصلية
✅ **عمل دون إنترنت** بعد التحميل الأول

---

## 📄 الملفات المهمة

| الملف | الوصف |
|-------|--------|
| `README_APK.md` | هذا الملف (دليل سريع) |
| `BUILD_APK.md` | دليل تفصيلي لبناء APK |
| `INSTALL.md` | دليل تثبيت PWA |
| `capacitor.config.ts` | إعدادات Capacitor |
| `android/` | مشروع Android |

---

## 🎯 ملخص الأوامر (نسخ ولصق)

```bash
# === بناء APK ===

# 1. تثبيت المكتبات
npm install

# 2. بناء تطبيق الويب
npm run build

# 3. إعداد Android
npx cap sync android

# 4. فتح Android Studio
npx cap open android

# 5. في Android Studio:
# Build → Build Bundle(s) / APK(s) → Build APK(s)

# 6. موقع APK:
# android/app/build/outputs/apk/debug/app-debug.apk

# === أوامر إضافية ===

# تنظيف المشروع
cd android && ./gradlew clean

# بناء APK من سطر الأوامر
cd android && ./gradlew assembleDebug

# بناء APK مُوقّع
cd android && ./gradlew assembleRelease
```

---

## 💰 التكلفة

**كل شيء مجاني 100%!**

- ✅ Node.js: مجاني
- ✅ Java JDK: مجاني
- ✅ Android Studio: مجاني
- ✅ Capacitor: مجاني
- ✅ التطبيق: مجاني

**لا تحتاج لدفع أي شيء!** 🎉

---

## 📱 اختبار التطبيق

بعد تثبيت APK، اختبر:

- ✅ فتح التطبيق
- ✅ التنقل بين الصفحات
- ✅ قراءة القرآن
- ✅ الاستماع للتلاوات
- ✅ الأذكار
- ✅ مواقيت الصلاة
- ✅ المسبحة
- ✅ القبلة
- ✅ الحفظ والمراجعة
- ✅ خطة الختمة
- ✅ التقويم الهجري

---

## 🎓 تعلم المزيد

- **Capacitor Docs**: https://capacitorjs.com/docs
- **Android Studio**: https://developer.android.com/studio/intro
- **Gradle**: https://gradle.org/guides/

---

## 🤝 المساهمة

إذا واجهت مشكلة أو لديك اقتراح:

1. افتح issue في المشروع
2. اكتب وصفاً واضحاً للمشكلة
3. أرفق screenshots إذا أمكن
4. اذكر نظام التشغيل والإصدارات

---

## 📜 الترخيص

هذا التطبيق مفتوح المصدر ومتاح للاستخدام المجاني.

**المصادر**:
- القرآن الكريم: AlQuran.cloud
- التلاوات: MP3Quran.net
- مواقيت الصلاة: AlAdhan.com
- الأذكار: HisnAlMuslim

---

## 🎊 تهانينا!

لقد نجحت في بناء ملف APK لتطبيق نور القرآن!

**شاركنا تجربتك!** 🎉

إذا نجحت في بناء APK وتثبيته، أخبرنا:
- هل كانت الخطوات واضحة؟
- هل واجهت أي مشاكل؟
- ما الذي أعجبك في التطبيق؟

---

**آخر تحديث**: 2026
**الإصدار**: 2.0 (APK)

---

## 📞 اتصال سريع

| الموضوع | الرابط |
|---------|--------|
| **دليل سريع** | `README_APK.md` (هذا الملف) |
| **دليل تفصيلي** | `BUILD_APK.md` |
| **Capacitor** | https://capacitorjs.com/docs |
| **Android Studio** | https://developer.android.com/studio |

---

**حظاً موفقاً! 🚀**

**بارك الله فيك! 🤲**
