import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nooquran.app',
  appName: 'نور القرآن',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#0f3d2e',
      showSpinner: true,
      spinnerColor: '#d4af37',
    },
    StatusBar: {
      style: 'DARK',
      backgroundColor: '#0f3d2e',
    },
  },
};

export default config;
